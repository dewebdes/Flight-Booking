<?php

use App\FlightSelect;
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

header('Access-Control-Allow-Origin: *');
header( 'Access-Control-Allow-Headers: Authorization, Content-Type' );

ini_set('memory_limit', '-1');
ini_set('max_execution_time', 700);


Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});


Route::any('/showme/{slug}', function (Request $request, $slug = null){
    echo $slug;
    return $request;
});


Route::middleware('auth:api')->post('/getcities', 'CitiesController@all');
Route::middleware('auth:api')->post('/flight/search', 'FlightsSearchController@show');
Route::middleware('auth:api')->post('/flight/select', 'FlightSelectController@show');
Route::middleware('auth:api')->post('/flight/select/check/', 'FlightSelectController@check');
Route::middleware('auth:api')->post('/flight/book', 'FlightReserveController@show');
Route::middleware('auth:api')->post('/flight/check/book', 'FlightBookingController@show');
Route::middleware('auth:api')->get('/get/cities/{slug}', 'AirportsFullController@show');




//Route::middleware('auth:api')->post('/payment/check/{id}', 'PaymentsController@check');
Route::get('/payment/check/{id}', 'PaymentsController@check');


Route::any('/payment/return/success', 'PaymentsController@success');
Route::any('/payment/return/failure', 'PaymentsController@failure');
Route::any('/payment/return/cancel', 'PaymentsController@cancel');
Route::any('/payment/return/service', 'PaymentsController@service');




Route::middleware('auth:api')->post('/flight/booking', 'FlightBookingController@show');


// Discount
Route::post('/discount-code', 'PaymentsController@getDiscountCode');

// IATA to City
Route::get('/iata-to-city/{iata}', 'ToolsController@iataToCity');

// Get Total Price & Round Trip Status
Route::get('/total-price/{uniId}', 'FlightReserveController@roundTripKnow');
Route::get('/find/{uniId}', function ($uniId){
    $roundTrip = false;
    $totalPrice = 0;
    $flights = FlightSelect::latest()->where('uniId', $uniId)->get();
    $count = FlightSelect::latest()->where('uniId', $uniId)->count();
    if($count > 1){
        $roundTrip = true;
        $totalPrice = $flights[0]['euro_amount'] + $flights[1]['euro_amount'];
    } elseif($count == 0){
        return [
            'roundTrip'  => 'No',
            'totalPrice' => '0',
            'depPrice'   => $flights[1]['euro_amount'],
            'retPrice'   => $flights[0]['euro_amount'],
            'message'    => 'unique id is wrong'
        ];
    } else{
        $totalPrice = $flights[0]['euro_amount'];
    }

    return [
        'roundTrip'  => $roundTrip,
        'totalPrice' => $totalPrice,
        'depPrice'   => $flights[1],
        'retPrice'   => $flights[0],
        'message'    => 'success'
    ];
});

// Calculate Round Trip Cart & Iata
//Route::middleware('auth:api')->post('/roundtrip/cart', 'FlightReserveController@cartCalculate');
//Route::middleware('auth:api')->post('/roundtrip/price', 'FlightReserveController@cartPrice');
//Route::middleware('auth:api')->post('/roundtrip/calc', 'FlightReserveController@roundTripKnow');

Route::middleware('auth:api')->post('/roundtrip/cart', 'FlightReserveController@cartCalculate');
Route::middleware('auth:api')->post('/roundtrip/price', 'FlightReserveController@cartPrice');
Route::middleware('auth:api')->post('/roundtrip/calc', 'FlightReserveController@roundTripKnow');

Route::middleware('auth:api')->post('/company-info', 'CompanyController@show');


Route::get('/test-vuetify', function (){
    return 'All of things will be correct!';
});

