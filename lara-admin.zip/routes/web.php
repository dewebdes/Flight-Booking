<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

header('Access-Control-Allow-Origin: *');
header( 'Access-Control-Allow-Headers: Authorization, Content-Type' );

ini_set('memory_limit', '-1');
ini_set('max_execution_time', 700);


Auth::routes();

use App\Http\ExtraClasses\Booking\BookingMain as BookingMain;
use App\Http\ExtraClasses\Booking\BookingHandler;// as BookingMain;
use App\Http\ExtraClasses\Payments\PaymentHandler as PaymentHandler;


use App\FlightReserve;
use App\FlightSelect;
use App\Http\ExtraClasses\General\AlibabaGeneral;
use App\Http\ExtraClasses\Reserve\AlibabaReserve;
use App\Http\ExtraClasses\Search\MarkUp;
use App\Http\ExtraClasses\Select\AlibabSelect;
use App\Http\ExtraClasses\Select\SelectMain;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\ExtraClasses\Reserve\ReserveMain;
//use App\Http\ExtraClasses\Search\SearchMain;
use App\Http\ExtraClasses\General\CommonGenerals as CommonThings;

use App\FlightBooking;
//use App\Events\Ticket;
//use App\FlightReserve;
//use App\FlightSelect;
use App\Http\Controllers\Admin\CompleteController;
use App\Mail\ReceiptMail;
//use App\Payments;
//use Illuminate\Http\Request;
//use App\Http\ExtraClasses\Booking\BookingHandler;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

//use App\FlightSelect;
//use App\Http\ExtraClasses\Select\AlibabSelect;
//use App\Http\ExtraClasses\General\CommonGenerals as CommonThings;
//use App\Http\ExtraClasses\Search\MarkUp as Markup;
//use App\Http\ExtraClasses\Select\SelectMain as SelectMain;
//use Illuminate\Support\Facades\DB;



Route::get('/cronjobtaskforqueudjobs', function(){


    $manualy_queued = \App\FlightReserve::where('reserve_status', 'QUEUED')->pluck('uniId')->toArray();

    if(!empty($manualy_queued)){
        foreach ($manualy_queued as $queued){

            $new_booking = new BookingMain();
            $new_booking = $new_booking->makeBooking($queued);

            if($new_booking['success'] == true){
                $booking = $new_booking['booking'];
                $flights = \App\FlightReserve::where('uniId', $queued)->orderBy('id', 'asc')->get();
                PaymentHandler::createTicket($flights,$booking);
            }


        }
    }



});

//$this->get('/ticket-send/{uniId}', 'CompleteController@resendTicket')->name('ticket.send');

Route::get('/finishreserv2', function(){

   
$uniId = $_REQUEST["unid"];
$cmd = $_REQUEST["act"];
//http://apochi.ipozal.com/finishreserv2?unid=4c44bX&act=rebuy
$runact1 = false;
switch ($cmd) {
    case 'rebuy':
        $runact1 = true;
        $flightReserved = FlightReserve::where('uniId', $uniId)->orderBy('id', 'desc')->get();

        $flightReserved[0]->update([
           'reserve_status' => 'QUEUED'
        ]);

       
        break;
    case 'qbuy':
            $niud =  $_REQUEST["niud"];

            $runact1 = true;
            $flightReserved_OLD = FlightReserve::where('uniId', $uniId)->orderBy('id', 'desc')->get();//->first();
            $flightReserved_NEW = FlightReserve::where('uniId', $niud)->orderBy('id', 'desc')->get();//->first();

          //  $dmob = $flightReserved[0]->email;
            //$lastReservedUID0 = FlightReserve::where('email', $dmob)->orderBy('id', 'desc')->get();//->uniId;
            //$lastReservedUID = $lastReservedUID0[0]->uniId;

            $newunid = $uniId . "-" . $niud;
            $flightReserved_OLD[0]->update([
               //'reserve_status' => 'QUEUED',
               'uniId' => $newunid
            ]);




        $flightReserved_NEW[0]->update([
           'reserve_status' => 'QUEUED'
        ]);




        break;
    case 'resendtik':
        //event(new Ticket($uniId));
    //resendTicket
    //$this->get('/ticket-send/{uniId}', 'CompleteController@resendTicket')->name('ticket.send');
    //http://apochi.ipozal.com/ticket-send/4c44bX
        break;
    case 'resendrecipt':
        //Route::get('/mail2/'+$uniId, 'FlightBookingController@sendReceiptMail');
    //http://apochi.ipozal.com/mail2/4c44bX
        break;
    
    default:
        # code...
        break;
}

if($runact1 == true){


//flights_searches
$isDomestic = \App\FlightsSearch::where('uniId', $uniId)->orderBy('id', 'desc')->first()->isDomestic;
if(((int)$isDomestic) != 1){

}
    
    //$flightReserved->save();

    $manualy_queued = \App\FlightReserve::where('reserve_status', 'QUEUED')->pluck('uniId')->toArray();

    if(!empty($manualy_queued)){
        foreach ($manualy_queued as $queued){

            $new_booking = new BookingMain();
            $new_booking = $new_booking->makeBooking($queued);

            if($new_booking['success'] == true){
                $booking = $new_booking['booking'];
                $flights = \App\FlightReserve::where('uniId', $queued)->orderBy('id', 'asc')->get();
                PaymentHandler::createTicket($flights,$booking);
            }


        }
    }           


//echo $newunid . " - " . $isDomestic;

}

echo "<script>function calloperator(){  if(window.parent != window){      window.parent.postMessage('actionfinish();', '*');    }}calloperator();</script><h1>FINISH ....</h1>";

});



Route::get('/rebuy', function(){

    //return "ok";

$uniId = $_REQUEST["unid"];

$outp = "";

$disresv = FlightReserve::where([['uniId', $uniId]])->orderBy('id', 'desc')->first();

$disresv2 = $disresv->replicate();
$disresv->uniId = 'old' . $uniId; // the new project_id
$disresv->save();
$disresv2->save();




$returnFlight = FlightSelect::where([['uniId', $uniId], ['way', 'dep']])->orderBy('id', 'desc')->first();
//return "hi = " . $returnFlight->get_rph_load;// . " - " . $returnFlight->airItineraryRph ;
//return "hi3 = " . $returnFlight->airItineraryRph ;
$drph = $returnFlight->airItineraryRph;
$isok = false;
$outp .= $drph . "<br>";
 try{
$outp .= "try 1" . "<br>";

            $alibabaToken = AlibabaGeneral::getToken();
            $alibaba_api_address = env("Alibaba_Base_Url");
            $uri = '/api/v1/Available/GetPricedItineraryByRph';

$outp .= "try 2" . "<br>";

            $request_body =[
                'Rph' => $drph
            ];

            $request_body = json_encode($request_body, true);
$outp .= "try 3" . "<br>";
            $client = new \GuzzleHttp\Client([
                'headers' => [
                    'cache-control' => 'no-cache',
                    'content-type' => 'application/json',
                    'x-zumo-auth' => $alibabaToken,
                ]
            ]);
$outp .= "try 4" . "<br>";
            $response = $client->post($alibaba_api_address.$uri,
                ['body' => $request_body]
            );
            $outp .= "try 5" . "<br>";
            $response = $response->getBody()->getContents();
            $outp .= $response . "<br>";
            $response = json_decode($response, true);
            
$outp .= "try 6" . "<br>";

$isok = true;

        }catch (\Exception $e){

           /* return [
                'success' => false,
                'message' => 'NOT_AVAILABLE (Alibaba Select)'
            ];*/
            $outp .= "NOT_AVAILABLE (Alibaba Select)" . "<br>";
            $isok = false;

        }


     //   return $response;
//return $isok;

if($isok == true){


$manualy_queued = \App\FlightReserve::where('reserve_status', 'QUEUED')->pluck('uniId')->toArray();

    if(!empty($manualy_queued)){
        foreach ($manualy_queued as $queued){

            $new_booking = new BookingMain();
            $new_booking = $new_booking->makeBooking($queued);

            if($new_booking['success'] == true){
                $booking = $new_booking['booking'];
                $flights = \App\FlightReserve::where('uniId', $queued)->orderBy('id', 'asc')->get();
                PaymentHandler::createTicket($flights,$booking);
                $outp .= "book done" . "<br>";
            }


        }
    }


//$outp = "books done ";
//return redirect( $_SERVER['HTTP_REFERER']);

}else{
$outp .= "bug :(<br>";
}



$outp .= "<a href='" . $_SERVER['HTTP_REFERER'] . "'>BACK TO ADMIN ....</a>";

return $outp;

});




Route::get('logout', function(){
    Auth::logout();
    return redirect('/login');
});


Route::get('/main-admin-stuff-for-api', 'HomeController@show');

/*Route::get('/test-shit', function(){
    $the_id='5c19eae7b80a7';

//    $count = \App\FlightReserve::where('uniId', $the_id)->where('reserve_status', 'RESERVED_IN_ALIBABA')->Where('reserve_status', 'SUCCESS_ISSUED')->get();
//    $count = \App\FlightReserve::where(['uniId'=>$the_id])->get();



    $count = \App\FlightReserve::where('uniId', '=', $the_id)
        ->where(function ($query) {
            $query->where('reserve_status', '=', 'RESERVED_IN_ALIBABA')
                ->orWhere('reserve_status', '=', 'SUCCESS_ISSUED');
        })
        ->get();

    dd($count);

});


Route::get('/testphp', function (){
    phpinfo();
});
use Carbon\Carbon;

use \App\Mail\flightTicket;
use App\Mail\ReceiptMail;
Route::get('/test/tkt', function(){





    $unique_id = '5c10c227e1bd8';
//    $unique_id = $uniId;

    $reserves = \App\FlightReserve::where('uniId', $unique_id)->orderBy('id', 'asc')->get();
    $booking = \App\FlightBooking::where('uniId', $unique_id)->first();

    $dep_flight = null;
    $ret_flight = null;
    $bounded = false;

    $dep_flight = $reserves[0];

    if(isset($reserves[1])){
        if(!empty($reserves[1])){
            $ret_flight = $reserves[1];


            if ($ret_flight->airItineraryRph == $dep_flight->airItineraryRph){
                $bounded = true;
            }
        }
    }




    $company = $dep_flight->company;


    $travelers = $dep_flight->traveler_info;
    $travelers = json_decode($travelers);
    $travelers = $travelers->AirTravelers;

    $items = [];
    $i=0;
    foreach ($travelers as $traveler){

        $name = $traveler->PersonName;
        $name = $name->GivenName.' '.$name->Surname;
        $items[$i]['name'] = $name;


        $items[$i]['passport_no'] = $traveler->Document->DocId;

        $items[$i]['from_city'] = $dep_flight->fromcity->city;
        $items[$i]['to_city'] = $dep_flight->tocity->city;
        $items[$i]['from_iata'] = $dep_flight->fromcity->IATA;
        $items[$i]['from_iata'] = $dep_flight->fromcity->IATA;
        $items[$i]['to_iata'] = $dep_flight->tocity->IATA;

        $departureDate = new Carbon($dep_flight->departureDate);
        $arrivalDate = new Carbon($dep_flight->arrivalDate);

        $items[$i]['departure'] = $departureDate->format('H:i A');
        $items[$i]['boarding'] = $departureDate->subHours(1)->format('H:i A');
        $items[$i]['date'] = $departureDate->format('d M Y');
        $items[$i]['arrival'] = $arrivalDate->format('H:i A');
        $items[$i]['class'] = json_decode($dep_flight->AirItinerary)->airItinerary->leaveOptions[0]->flightSegments[0]->bookingClassAvail->cabinType;
        $items[$i]['operated_by'] = $dep_flight->Airline->name.' '.$dep_flight->flightNumber;

        $items[$i]['airline'] = json_decode($dep_flight->AirItinerary)->isDomestic ? 'https://cdn.alibaba.ir/static/img/airlines/Domestic/'.$dep_flight->operatingAirLine.'.png' : 'https://www.gstatic.com/flights/airline_logos/70px/'.$dep_flight->operatingAirLine.'.png';


        $passengers = json_decode($dep_flight->sent_request)->TravelerInfo->AirTravelers;

        foreach ($passengers as $passneger){



            if(($passneger->PersonName->GivenName == $traveler->PersonName->GivenName) && ($passneger->PersonName->Surname == $traveler->PersonName->Surname)){
                $tkt_ref = $passneger->TravelerRefNumber;
            }
        }

        $bkb = $booking->Alibaba_book_response;
        $bkb = json_decode($bkb);
        $bkb = $bkb->data->airBookRs;

        foreach ($bkb as $bp){

            foreach ($bp->ticketing as $b){

                if($b->travelerRefNumber == $tkt_ref){

                    $items[$i]['tkt_no'] = $b->ticketDocumentNbr;

                }
            };
        }

        $i++;
    }





    if($ret_flight){

        $dep_flight = $ret_flight;

        $company = $dep_flight->company;


        $travelers = $dep_flight->traveler_info;
        $travelers = json_decode($travelers);
        $travelers = $travelers->AirTravelers;

        $i=sizeof($items);
        foreach ($travelers as $traveler){

            $name = $traveler->PersonName;
            $name = $name->GivenName.' '.$name->Surname;
            $items[$i]['name'] = $name;


            $items[$i]['passport_no'] = $traveler->Document->DocId;

            $items[$i]['from_city'] = $dep_flight->fromcity->city;
            $items[$i]['to_city'] = $dep_flight->tocity->city;
            $items[$i]['from_iata'] = $dep_flight->fromcity->IATA;
            $items[$i]['from_iata'] = $dep_flight->fromcity->IATA;
            $items[$i]['to_iata'] = $dep_flight->tocity->IATA;

            $departureDate = new Carbon($dep_flight->departureDate);
            $arrivalDate = new Carbon($dep_flight->arrivalDate);

            $items[$i]['departure'] = $departureDate->format('H:i A');
            $items[$i]['boarding'] = $departureDate->subHours(1)->format('H:i A');
            $items[$i]['date'] = $departureDate->format('d M Y');
            $items[$i]['arrival'] = $arrivalDate->format('H:i A');
            $items[$i]['class'] = json_decode($dep_flight->AirItinerary)->airItinerary->leaveOptions[0]->flightSegments[0]->bookingClassAvail->cabinType;
            $items[$i]['operated_by'] = $dep_flight->Airline->name.' '.$dep_flight->flightNumber;

            $items[$i]['airline'] = json_decode($dep_flight->AirItinerary)->isDomestic ? 'https://cdn.alibaba.ir/static/img/airlines/Domestic/'.$dep_flight->operatingAirLine.'.png' : 'https://www.gstatic.com/flights/airline_logos/70px/'.$dep_flight->operatingAirLine.'.png';


            $passengers = json_decode($dep_flight->sent_request)->TravelerInfo->AirTravelers;

            foreach ($passengers as $passneger){



                if(($passneger->PersonName->GivenName == $traveler->PersonName->GivenName) && ($passneger->PersonName->Surname == $traveler->PersonName->Surname)){
                    $tkt_ref = $passneger->TravelerRefNumber;
                }
            }

            $bkb = $booking->Alibaba_book_response;
            $bkb = json_decode($bkb);
            $bkb = $bkb->data->airBookRs;

            foreach ($bkb as $bp){

                foreach ($bp->ticketing as $b){

                    if($b->travelerRefNumber == $tkt_ref){

                        $items[$i]['tkt_no'] = $b->ticketDocumentNbr;

                    }
                };
            }

            $i++;
        }


    }









    $data=[

        'logo' => $company->logo_address,
        'add'  => $company->tkt_ad_address,
        'items' => $items
    ];





    $pdfFilePath = 'pdfs/tickets/'.$unique_id.'.pdf';
    $pdf = LPDF::loadView('mail.ticketforpdf', compact(['data']), [], ['format' => 'A4-P'])->save($pdfFilePath);
//    return $pdf->stream('document.pdf');

    $bcc1 = env('Email_BCC_One');
    $bcc2 = env('Email_BCC_Two');


    $to = $dep_flight->email;
    $bcc = [
        "$bcc1","$bcc2"
    ];

    $company = $dep_flight->company;
    $emails = $company->emails;

    if(!empty($emails)){
        $emails = explode(',',$emails);
        foreach ($emails as $email){
            $bcc[]=$email;
        }
    }



    $subject = $company->name.' Your flight - '.$unique_id;
    \Mail::to($to)->bcc($bcc)->send(new flightTicket($subject,$data));





});


Route::get('/getisdomestic', function(){

    $departure_details_ass =  App\FlightSelect::where('uniId', '5c1f601812e19')->where('way','dep')->orderBy('id', 'desc')->first();
    $departure_details_ass = $departure_details_ass->get_rph_load;
    $departure_details_ass = json_decode($departure_details_ass, true);
    $departure_details_ass = $departure_details_ass['data']['isDomestic'];

    dd($departure_details_ass);

});


Route::get('/test/tkt', function(){




        $unique_id = '52efcK';
//        $unique_id = $uniId;

        $reserves = \App\FlightReserve::where('uniId', $unique_id)->orderBy('id', 'asc')->get();
        $booking = \App\FlightBooking::where('uniId', $unique_id)->first();

    $unique_id = $booking->uniId;


    $dep_flight = null;
    $ret_flight = null;
    $bounded = false;

    $dep_flight = $reserves[0];

    if(isset($reserves[1])){
        if(!empty($reserves[1])){
            $ret_flight = $reserves[1];

            if ($ret_flight->airItineraryRph == $dep_flight->airItineraryRph){
                $bounded = true;
            }
        }
    }




    $company = $dep_flight->company;


    $travelers = $dep_flight->traveler_info;
    $travelers = json_decode($travelers);
    $travelers = $travelers->AirTravelers;

    $items = [];
    $i=0;
    foreach ($travelers as $traveler){

        $name = $traveler->PersonName;
        $name = $name->GivenName.' '.$name->Surname;
        $items[$i]['name'] = $name;


        $items[$i]['passport_no'] = $traveler->Document->DocId;

        $items[$i]['from_city'] = $dep_flight->fromcity->city;
        $items[$i]['to_city'] = $dep_flight->tocity->city;
        $items[$i]['from_iata'] = $dep_flight->fromcity->iata;
        $items[$i]['from_iata'] = $dep_flight->fromcity->iata;
        $items[$i]['to_iata'] = $dep_flight->tocity->iata;

        $departureDate = new Carbon($dep_flight->departureDate);
        $arrivalDate = new Carbon($dep_flight->arrivalDate);

        $items[$i]['departure'] = $departureDate->format('H:i A');
        $items[$i]['boarding'] = $departureDate->subHours(1)->format('H:i A');
        $items[$i]['date'] = $departureDate->format('d M Y');
        $items[$i]['arrival'] = $arrivalDate->format('H:i A');
        $items[$i]['class'] = json_decode($dep_flight->AirItinerary)->airItinerary->leaveOptions[0]->flightSegments[0]->bookingClassAvail->cabinType;
        $items[$i]['operated_by'] = $dep_flight->Airline->name.' '.$dep_flight->flightNumber;

        $items[$i]['airline'] = json_decode($dep_flight->AirItinerary)->isDomestic ? 'https://cdn.alibaba.ir/static/img/airlines/Domestic/'.$dep_flight->operatingAirLine.'.png' : 'https://www.gstatic.com/flights/airline_logos/70px/'.$dep_flight->operatingAirLine.'.png';


        $passengers = json_decode($dep_flight->sent_request)->TravelerInfo->AirTravelers;

        foreach ($passengers as $passneger){



            if(($passneger->PersonName->GivenName == $traveler->PersonName->GivenName) && ($passneger->PersonName->Surname == $traveler->PersonName->Surname)){
                $tkt_ref = $passneger->TravelerRefNumber;
            }
        }

        $bkb = $booking->Alibaba_book_response;
        $bkb = json_decode($bkb);
        $bkb = $bkb->data->airBookRs;

        foreach ($bkb as $bp){

            foreach ($bp->ticketing as $b){

                if($b->travelerRefNumber == $tkt_ref){

                    $items[$i]['tkt_no'] = $b->ticketDocumentNbr;

                }
            };
        }

        $i++;
    }




    if(!$bounded){
        if($ret_flight){

            $dep_flight = $ret_flight;

            $company = $dep_flight->company;


            $travelers = $dep_flight->traveler_info;
            $travelers = json_decode($travelers);
            $travelers = $travelers->AirTravelers;

            $i=sizeof($items);
            foreach ($travelers as $traveler){

                $name = $traveler->PersonName;
                $name = $name->GivenName.' '.$name->Surname;
                $items[$i]['name'] = $name;


                $items[$i]['passport_no'] = $traveler->Document->DocId;

                $items[$i]['from_city'] = $dep_flight->fromcity->city;
                $items[$i]['to_city'] = $dep_flight->tocity->city;
                $items[$i]['from_iata'] = $dep_flight->fromcity->IATA;
                $items[$i]['from_iata'] = $dep_flight->fromcity->IATA;
                $items[$i]['to_iata'] = $dep_flight->tocity->IATA;

                $departureDate = new Carbon($dep_flight->departureDate);
                $arrivalDate = new Carbon($dep_flight->arrivalDate);

                $items[$i]['departure'] = $departureDate->format('H:i A');
                $items[$i]['boarding'] = $departureDate->subHours(1)->format('H:i A');
                $items[$i]['date'] = $departureDate->format('d M Y');
                $items[$i]['arrival'] = $arrivalDate->format('H:i A');
                $items[$i]['class'] = json_decode($dep_flight->AirItinerary)->airItinerary->leaveOptions[0]->flightSegments[0]->bookingClassAvail->cabinType;
                $items[$i]['operated_by'] = $dep_flight->Airline->name.' '.$dep_flight->flightNumber;

                $items[$i]['airline'] = json_decode($dep_flight->AirItinerary)->isDomestic ? 'https://cdn.alibaba.ir/static/img/airlines/Domestic/'.$dep_flight->operatingAirLine.'.png' : 'https://www.gstatic.com/flights/airline_logos/70px/'.$dep_flight->operatingAirLine.'.png';


                $passengers = json_decode($dep_flight->sent_request)->TravelerInfo->AirTravelers;

                foreach ($passengers as $passneger){



                    if(($passneger->PersonName->GivenName == $traveler->PersonName->GivenName) && ($passneger->PersonName->Surname == $traveler->PersonName->Surname)){
                        $tkt_ref = $passneger->TravelerRefNumber;
                    }
                }

                $bkb = $booking->Alibaba_book_response;
                $bkb = json_decode($bkb);
                $bkb = $bkb->data->airBookRs;

                foreach ($bkb as $bp){

                    foreach ($bp->ticketing as $b){

                        if($b->travelerRefNumber == $tkt_ref){

                            $items[$i]['tkt_no'] = $b->ticketDocumentNbr;

                        }
                    };
                }

                $i++;
            }


        }
    }else{


        $dep_flight = $ret_flight;

        $company = $dep_flight->company;


        $travelers = $dep_flight->traveler_info;
        $travelers = json_decode($travelers);
        $travelers = $travelers->AirTravelers;

        $i=sizeof($items);
        foreach ($travelers as $traveler){

            $name = $traveler->PersonName;
            $name = $name->GivenName.' '.$name->Surname;
            $items[$i]['name'] = $name;


            $items[$i]['passport_no'] = $traveler->Document->DocId;

            $items[$i]['from_city'] = $dep_flight->fromcity->city;
            $items[$i]['to_city'] = $dep_flight->tocity->city;
            $items[$i]['from_iata'] = $dep_flight->fromcity->iata;
            $items[$i]['from_iata'] = $dep_flight->fromcity->iata;
            $items[$i]['to_iata'] = $dep_flight->tocity->iata;

            $departureDate = new Carbon($dep_flight->departureDate);
            $arrivalDate = new Carbon($dep_flight->arrivalDate);

            $items[$i]['departure'] = $departureDate->format('H:i A');
            $items[$i]['boarding'] = $departureDate->subHours(1)->format('H:i A');
            $items[$i]['date'] = $departureDate->format('d M Y');
            $items[$i]['arrival'] = $arrivalDate->format('H:i A');
            $items[$i]['class'] = json_decode($dep_flight->AirItinerary)->airItinerary->leaveOptions[0]->flightSegments[0]->bookingClassAvail->cabinType;
            $items[$i]['operated_by'] = $dep_flight->Airline->name.' '.$dep_flight->flightNumber;

            $items[$i]['airline'] = json_decode($dep_flight->AirItinerary)->isDomestic ? 'https://cdn.alibaba.ir/static/img/airlines/Domestic/'.$dep_flight->operatingAirLine.'.png' : 'https://www.gstatic.com/flights/airline_logos/70px/'.$dep_flight->operatingAirLine.'.png';


            $passengers = json_decode($dep_flight->sent_request)->TravelerInfo->AirTravelers;

            foreach ($items as $it){
                if($traveler->Document->DocId == $it['passport_no']){
                    if(isset($it['tkt_no'])){
                        $items[$i]['tkt_no'] = $it['tkt_no'];
                    }
                }
            }

//            dd($items);

            $i++;
        }


    }











    $data=[
        'logo' => $company->logo_address,
        'add'  => $company->tkt_ad_address,
        'items' => $items
    ];





    $pdfFilePath = 'pdfs/tickets/'.$unique_id.'.pdf';
    LPDF::loadView('mail.ticketforpdf', compact(['data']), [], ['format' => 'A4-P'])->save($pdfFilePath);


    $bcc1 = env('Email_BCC_One');
    $bcc2 = env('Email_BCC_Two');

    $to = $dep_flight->email;
    $bcc = [
        "$bcc1","$bcc2"
    ];

    $company = $dep_flight->company;
    $emails = $company->emails;

    if(!empty($emails)){
        $emails = explode(',',$emails);
        foreach ($emails as $email){
            $bcc[]=$email;
        }
    }

    $subject = $company->name.' Your flight - '.$unique_id;
    \Mail::to($to)->bcc($bcc)->send(new flightTicket($subject, $data));




});

use App\Http\ExtraClasses\Select\SelectMain;
use App\Http\ExtraClasses\Search\MarkUp as Markup;


Route::get('/test/reciept', function (){




    $uniId = '97016Q';
    $payment = \App\Payments::where('uniId', $uniId)->first();








    $flights = \App\FlightReserve::where('uniId', $uniId)->orderBy('id', 'asc')->get();
    $dep_flight = null;
    $ret_flight = null;
    $bounded = false;




    if (isset($flights[0])){
        $dep_flight = $flights[0];
    }
    if (isset($flights[1])){
        $ret_flight = $flights[1];
    }
    if(!empty($ret_flight)){
        if($ret_flight->airItineraryRph == $dep_flight->airItineraryRph){
            $bounded = true;
        }
    }

    $company = $dep_flight->company;




    $paaayment_data = $payment->created_at;
    $paaayment_data = $paaayment_data->format('F d, Y');




    $general_info = [

        'logo' => $company->invoice_logo,
        'bill_to' => $payment->cardholder,
        'bill_to_sub' => $payment->maskedPan,
        'email' => $dep_flight->email,
        'invc_number' => $uniId,
        'invc_date' => $paaayment_data,
        'card_type' => $payment->paymentType,


        'total' => '',
        'discount_value' => '',
        'total_after_discount' => '',


    ];

    if(!$bounded){
        if(!empty($ret_flight)){

            $general_info['total']= $dep_flight->total_euro_amount + $ret_flight->total_euro_amount;
            $general_info['discount_value']=$dep_flight->discount_value + $ret_flight->discount_value;
            $general_info['total_after_discount']=$dep_flight->real_paid_amount + $ret_flight->real_paid_amount;

        }else{

            $general_info['total']= $dep_flight->total_euro_amount;
            $general_info['discount_value']=$dep_flight->discount_value;
            $general_info['total_after_discount']=$dep_flight->real_paid_amount;

        }
        $insurance_price = env('Medical_insurance');
        $pickup_price = env('AirportPickup');
        $city_tour_price = env('City_tour');
        $education_price = env('Education_donate_fee');
        $total_passengers = (intval($dep_flight->adult)+intval($dep_flight->child));
        $cars = ceil(($total_passengers / 3));
        $pickup_price =  $cars * $pickup_price;
        $ret_info     = [
            'from' => $dep_flight->fromCity->city,
            'to' => $dep_flight->toCity->city,
            'adult_number' => $dep_flight->adult,
            'child_number' => $dep_flight->child,
            'infant_number' => $dep_flight->infant,
            'adult_price' => '',
            'child_price' => '',
            'infant_price' => '',
            'from_services' => [
                'Medical Insurance' => '',
                'Airport Pickup' => '',
                'City Tour' => '',
                'Education donation'=>'',
                'Education qty' =>''
            ],
            'to_services' => [
                'Medical Insurance' => '',
                'Airport Pickup' => '',
                'City Tour' => '',
            ],
        ];
        $value = $dep_flight->supplements;
        $value = json_decode($value, true);
        if(isset($value['education_donation'])){

            if($value['education_donation'] == true){
                $ret_info['from_services']['Education donation'] = $education_price * $value['education_donation_unit'];
                $ret_info['from_services']['Education qty'] = $value['education_donation_unit'];
            }

        }
        if(isset($value['departure_from_health'])){

            if($value['departure_from_health'] == true){
                $ret_info['from_services']['Medical Insurance'] = $insurance_price;
            }

        }
        if(isset($value['departure_to_health'])){

            if($value['departure_to_health'] == true){
                $ret_info['to_services']['Medical Insurance'] = $insurance_price;
            }

        }
        if(isset($value['departure_from_pickup'])){

            if($value['departure_from_pickup'] == true){
                $ret_info['from_services']['Airport Pickup'] = $pickup_price;
            }

        }
        if(isset($value['departure_to_pickup'])){

            if($value['departure_to_pickup'] == true){
                $ret_info['to_services']['Airport Pickup'] = $pickup_price;
            }

        }
        if(isset($value['departure_from_tour'])){

            if($value['departure_from_tour'] == true){
                $ret_info['from_services']['City Tour'] = $city_tour_price;
            }

        }


        if(isset($value['departure_to_tour'])){

            if($value['departure_to_tour'] == true){
                $ret_info['to_services']['City Tour'] = $city_tour_price;
            }

        }





        $price = $dep_flight->AirItinerary;
        $price = json_decode($price, true);
        $price = $price['airItineraryPricingInfo']['ptcFareBreakdowns'];
        $new = new SelectMain;
        $new = $new->breakPriceCalculator($price);
        $ret_info['adult_price'] = Markup::totalPriceExchange($new['adult_Pack']);
        $ret_info['child_price'] = Markup::totalPriceExchange($new['child_pack']);
        $ret_info['infant_price'] = Markup::totalPriceExchange($new['infant_pack']);
        $services = [];
        $adult = [
            'title' => 'Flight - Adult Passenger',
            'sub_title'=>$ret_info['from'].' to '.$ret_info['to'].', '.$dep_flight->departureDate,
            'qty'=>$ret_info['adult_number'],
            'price'=>$ret_info['adult_price'],
            'amount'=>$ret_info['adult_price'] * $ret_info['adult_number'],

        ];
        $services[]=$adult;
        if($ret_info['child_number'] > 0){
            $child = [
                'title' => 'Flight - Child Passenger',
                'sub_title'=>$ret_info['from'].' to '.$ret_info['to'].', '.$dep_flight->departureDate,
                'qty'=>$ret_info['child_number'],
                'price'=>$ret_info['child_price'],
                'amount'=>$ret_info['child_price'] * $ret_info['child_number'],

            ];
            $services[]=$child;
        }
        if($ret_info['infant_number'] > 0){
            $infant = [
                'title' => 'Flight - Infant Passenger',
                'sub_title'=>$ret_info['from'].' to '.$ret_info['to'].', '.$dep_flight->departureDate,
                'qty'=>$ret_info['infant_number'],
                'price'=>$ret_info['infant_price'],
                'amount'=>$ret_info['infant_price'] * $ret_info['infant_number'],

            ];
            $services[]=$infant;
        }
        if(!empty($ret_info['from_services']['Education donation'])){
            $insurance = [
                'title' => 'Give every child chance to succeed in life',
                'sub_title'=>'Education donation',
                'qty'=>$ret_info['from_services']['Education qty'],
                'price'=>$education_price,
                'amount'=>$ret_info['from_services']['Education donation'],

            ];
            $services[]=$insurance;
        }
        if(!empty($ret_info['from_services']['Medical Insurance'])){
            $insurance = [
                'title' => 'Medical Insurance',
                'sub_title'=>'',
                'qty'=>$ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number'],
                'price'=>$ret_info['from_services']['Medical Insurance'],
                'amount'=>($ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number'])*$ret_info['from_services']['Medical Insurance'],

            ];
            $services[]=$insurance;
        }
        if(!empty($ret_info['from_services']['Airport Pickup'])){

            $dropoff = new Carbon($dep_flight->departureDate);
            $dropoff = $dropoff->format('D d M Y');

            $pickup = [
                'title' => 'Airport Drop off',
                'sub_title'=>$ret_info['from'].', '.$dropoff,
                'qty'=>$cars,
                'price'=>$ret_info['from_services']['Airport Pickup'],
                'amount'=>intval($cars)*intval($ret_info['from_services']['Airport Pickup']),
            ];

            $services[]=$pickup;
        }


        if(!empty($ret_info['from_services']['City Tour'])){

            $city_tour = [
                'title' => 'City Tour'.' - '.$ret_info['from'].' to '.$ret_info['to'],
                'sub_title'=>$ret_info['from'],
                'qty'=>$ret_info['child_number']+$ret_info['adult_number'],
                'price'=>$ret_info['from_services']['City Tour'],
                'amount'=>(intval($ret_info['child_number'])+intval($ret_info['adult_number']))*intval($ret_info['from_services']['City Tour']),
            ];

            $services[]=$city_tour;

        }
        if(!empty($ret_info['to_services']['Airport Pickup'])){

            $pick = new Carbon($dep_flight->arrivalDate);
            $pick = $pick->format('D d M Y');

            $pickup = [
                'title' => 'Airport Pick up',
                'sub_title'=>$ret_info['to'].', '.$pick,
                'qty'=>$cars,
                'price'=>$ret_info['to_services']['Airport Pickup'],
                'amount'=>$cars * intval($ret_info['to_services']['Airport Pickup']),
            ];

            $services[]=$pickup;
        }
        if(!empty($ret_info['to_services']['City Tour'])){

            $city_tour = [
                'title' => 'City Tour'.' - '.$ret_info['from'].' to '.$ret_info['to'],
                'sub_title'=>$ret_info['to'],
                'qty'=>$ret_info['child_number']+$ret_info['adult_number'],
                'price'=>$ret_info['to_services']['City Tour'],
                'amount'=>(intval($ret_info['child_number'])+intval($ret_info['adult_number']))*intval($ret_info['to_services']['City Tour']),
            ];

            $services[]=$city_tour;

        }

//        dd($services);



        $booking_fee = [
            'title' => 'Booking Fee',
            'sub_title'=>$ret_info['from'].' to '.$ret_info['to'].', '.$dep_flight->departureDate,
            'qty'=> $ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number'],
            'price'=>env('Booking_fee'),
            'amount'=>($ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number']) * env('Booking_fee'),
        ];
        $services[]=$booking_fee;
        $ret_info = null;
        if(!empty($ret_flight)){
            $ret_info     = [
                'from' => $ret_flight->fromCity->city,
                'to' => $ret_flight->toCity->city,
                'adult_number' => $ret_flight->adult,
                'child_number' => $ret_flight->child,
                'infant_number' => $ret_flight->infant,
                'adult_price' => '',
                'child_price' => '',
                'infant_price' => '',
                'from_services' => [
                    'Medical Insurance' => '',
                    'Airport Pickup' => '',
                    'City Tour' => '',
                ],
                'to_services' => [
                    'Medical Insurance' => '',
                    'Airport Pickup' => '',
                    'City Tour' => '',
                ],
            ];


            $value = $ret_flight->supplements;
            $value = json_decode($value, true);

            if(isset($value['returning_from_health'])){

                if($value['returning_from_health'] == true){
                    $ret_info['from_services']['Medical Insurance'] = $insurance_price;
                }

            }
            if(isset($value['returning_to_health'])){

                if($value['returning_to_health'] == true){
                    $ret_info['to_services']['Medical Insurance'] = $insurance_price;
                }

            }
            if(isset($value['returning_from_pickup'])){

                if($value['returning_from_pickup'] == true){
                    $ret_info['from_services']['Airport Pickup'] = $pickup_price;
                }

            }
            if(isset($value['returning_to_pickup'])){

                if($value['returning_to_pickup'] == true){
                    $ret_info['to_services']['Airport Pickup'] = $pickup_price;
                }

            }
            if(isset($value['returning_from_tour'])){

                if($value['returning_from_tour'] == true){
                    $ret_info['from_services']['City Tour'] = $city_tour_price;
                }

            }

            if(isset($value['returning_to_tour'])){

                if($value['returning_to_tour'] == true){
                    $ret_info['to_services']['City Tour'] = $city_tour_price;
                }

            }




            $price = $ret_flight->AirItinerary;
            $price = json_decode($price, true);
            $price = $price['airItineraryPricingInfo']['ptcFareBreakdowns'];
            $new = new SelectMain;
            $new = $new->breakPriceCalculator($price);

            $ret_info['adult_price'] = Markup::totalPriceExchange($new['adult_Pack']);
            $ret_info['child_price'] = Markup::totalPriceExchange($new['child_pack']);
            $ret_info['infant_price'] = Markup::totalPriceExchange($new['infant_pack']);




            $adult = [
                'title' => 'Flight - Adult Passenger',
                'sub_title'=>$ret_info['from'].' to '.$ret_info['to'].', '.$ret_flight->departureDate,
                'qty'=>$ret_info['adult_number'],
                'price'=>$ret_info['adult_price'],
                'amount'=>$ret_info['adult_price'] * $ret_info['adult_number'],

            ];
            $services[]=$adult;

            if($ret_info['child_number'] > 0){
                $child = [
                    'title' => 'Flight - Child Passenger',
                    'sub_title'=>$ret_info['from'].' to '.$ret_info['to'].', '.$ret_flight->departureDate,
                    'qty'=>$ret_info['child_number'],
                    'price'=>$ret_info['child_price'],
                    'amount'=>$ret_info['child_price'] * $ret_info['child_number'],

                ];
                $services[]=$child;
            }
            if($ret_info['infant_number'] > 0){
                $infant = [
                    'title' => 'Flight - Infant Passenger',
                    'sub_title'=>$ret_info['from'].' to '.$ret_info['to'].', '.$ret_flight->departureDate,
                    'qty'=>$ret_info['infant_number'],
                    'price'=>$ret_info['infant_price'],
                    'amount'=>$ret_info['infant_price'] * $ret_info['infant_number'],

                ];
                $services[]=$infant;
            }




            if(!empty($ret_info['from_services']['Airport Pickup'])){

                $dropoff = new Carbon($ret_flight->departureDate);
                $dropoff = $dropoff->format('D d M Y');

                $pickup = [
                    'title' => 'Airport Drop off',
                    'sub_title'=>$ret_info['from'].', '.$dropoff,
                    'qty'=>$cars,
                    'price'=>$ret_info['from_services']['Airport Pickup'],
                    'amount'=>intval($cars)*intval($ret_info['from_services']['Airport Pickup']),
                ];

                $services[]=$pickup;
            }

            if(!empty($ret_info['from_services']['City Tour'])){

                $city_tour = [
                    'title' => 'City Tour - '.$ret_info['from'].' to '.$ret_info['to'],
                    'sub_title'=>$ret_info['from'],
                    'qty'=>$ret_info['child_number']+$ret_info['adult_number'],
                    'price'=>$ret_info['from_services']['City Tour'],
                    'amount'=>(intval($ret_info['child_number'])+intval($ret_info['adult_number']))*intval($ret_info['from_services']['City Tour']),
                ];

                $services[]=$city_tour;

            }


            if(!empty($ret_info['to_services']['Airport Pickup'])){

                $pick = new Carbon($ret_flight->arrivalDate);
                $pick = $pick->format('D d M Y');

                $pickup = [
                    'title' => 'Airport Pick up',
                    'sub_title'=>$ret_info['to'].', '.$pick,
                    'qty'=>$cars,
                    'price'=>$ret_info['to_services']['Airport Pickup'],
                    'amount'=>intval($cars)*intval($ret_info['to_services']['Airport Pickup']),
                ];

                $services[]=$pickup;
            }


            if(!empty($ret_info['to_services']['City Tour'])){

                $city_tour = [
                    'title' => 'City Tour - '.$ret_info['from'].' to '.$ret_info['to'],
                    'sub_title'=>$ret_info['to'],
                    'qty'=>$ret_info['child_number']+$ret_info['adult_number'],
                    'price'=>$ret_info['to_services']['City Tour'],
                    'amount'=>(intval($ret_info['child_number'])+intval($ret_info['adult_number']))*intval($ret_info['to_services']['City Tour']),
                ];

                $services[]=$city_tour;

            }



            $booking_fee = [
                'title' => 'Booking Fee',
                'sub_title'=>$ret_info['from'].' to '.$ret_info['to'].', '.$ret_flight->departureDate,
                'qty'=> $ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number'],
                'price'=>env('Booking_fee'),
                'amount'=>($ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number']) * env('Booking_fee'),
            ];

            $services[]=$booking_fee;




        }
    }else{


        $general_info['total']= $dep_flight->total_euro_amount + $ret_flight->total_euro_amount;
        $general_info['discount_value']=$dep_flight->discount_value + $ret_flight->discount_value;
        $general_info['total_after_discount']=$dep_flight->real_paid_amount + $ret_flight->real_paid_amount;


        $insurance_price = env('Medical_insurance');
        $pickup_price = env('AirportPickup');
        $city_tour_price = env('City_tour');
        $education_price = env('Education_donate_fee');
        $total_passengers = (intval($dep_flight->adult)+intval($dep_flight->child));
        $cars = ceil(($total_passengers / 3));

//            $pickup_price =  $cars * $pickup_price;

        $ret_info     = [
            'from' => $dep_flight->fromCity->city,
            'to' => $dep_flight->toCity->city,
            'adult_number' => $dep_flight->adult,
            'child_number' => $dep_flight->child,
            'infant_number' => $dep_flight->infant,
            'adult_price' => '',
            'child_price' => '',
            'infant_price' => '',
            'from_services' => [
                'Medical Insurance' => '',
                'Airport Pickup' => '',
                'City Tour' => '',
                'Education donation'=>'',
                'Education qty' =>''
            ],
            'to_services' => [
                'Medical Insurance' => '',
                'Airport Pickup' => '',
                'City Tour' => '',
            ],
        ];
        $value = $dep_flight->supplements;
        $value = json_decode($value, true);
        if(isset($value['education_donation'])){

            if($value['education_donation'] == true){
                $ret_info['from_services']['Education donation'] = $education_price * $value['education_donation_unit'];
                $ret_info['from_services']['Education qty'] = $value['education_donation_unit'];
            }

        }
        if(isset($value['departure_from_health'])){

            if($value['departure_from_health'] == true){
                $ret_info['from_services']['Medical Insurance'] = $insurance_price;
            }

        }
        if(isset($value['departure_from_pickup'])){

            if($value['departure_from_pickup'] == true){
                $ret_info['from_services']['Airport Pickup'] = $pickup_price;
            }

        }
        if(isset($value['departure_to_pickup'])){

            if($value['departure_to_pickup'] == true){
                $ret_info['to_services']['Airport Pickup'] = $pickup_price;
            }

        }
        if(isset($value['departure_from_tour'])){

            if($value['departure_from_tour'] == true){
                $ret_info['from_services']['City Tour'] = $city_tour_price;
            }

        }
        if(isset($value['departure_to_tour'])){

            if($value['departure_to_tour'] == true){
                $ret_info['to_services']['City Tour'] = $city_tour_price;
            }

        }
        $price = $dep_flight->AirItinerary;
        $price = json_decode($price, true);
        $price = $price['airItineraryPricingInfo']['ptcFareBreakdowns'];
        $new = new SelectMain;
        $new = $new->breakPriceCalculator($price);
        $ret_info['adult_price'] = Markup::totalPriceExchange($new['adult_Pack']);
        $ret_info['child_price'] = Markup::totalPriceExchange($new['child_pack']);
        $ret_info['infant_price'] = Markup::totalPriceExchange($new['infant_pack']);
        $services = [];
        $adult = [
            'title' => 'Flight - Adult Passenger',
            'sub_title'=> $ret_info['from'].' to '.$ret_info['to'].', '.$dep_flight->departureDate.' <br> '.$ret_info['to'].' to '.$ret_info['from'].', '.$ret_flight->departureDate,
            'qty'=>$ret_info['adult_number'],
            'price'=>$ret_info['adult_price'],
            'amount'=>$ret_info['adult_price'] * $ret_info['adult_number'],

        ];
        $services[]=$adult;
        if($ret_info['child_number'] > 0){
            $child = [
                'title' => 'Flight - Child Passenger',
                'sub_title'=> $ret_info['from'].' to '.$ret_info['to'].', '.$dep_flight->departureDate.' <br> '.$ret_info['to'].' to '.$ret_info['from'].', '.$ret_flight->departureDate,
                'qty'=>$ret_info['child_number'],
                'price'=>$ret_info['child_price'],
                'amount'=>$ret_info['child_price'] * $ret_info['child_number'],

            ];
            $services[]=$child;
        }
        if($ret_info['infant_number'] > 0){
            $infant = [
                'title' => 'Flight - Infant Passenger',
                'sub_title'=> $ret_info['from'].' to '.$ret_info['to'].', '.$dep_flight->departureDate.' <br> '.$ret_info['to'].' to '.$ret_info['from'].', '.$ret_flight->departureDate,
                'qty'=>$ret_info['infant_number'],
                'price'=>$ret_info['infant_price'],
                'amount'=>$ret_info['infant_price'] * $ret_info['infant_number'],

            ];
            $services[]=$infant;
        }
        if(!empty($ret_info['from_services']['Education donation'])){
            $insurance = [
                'title' => 'Give every child chance to succeed in life',
                'sub_title'=>'Education donation',
                'qty'=>$ret_info['from_services']['Education qty'],
                'price'=>$education_price,
                'amount'=>$ret_info['from_services']['Education donation'],

            ];
            $services[]=$insurance;
        }
        if(!empty($ret_info['from_services']['Medical Insurance'])){
            $insurance = [
                'title' => 'Medical Insurance',
                'sub_title'=>'',
                'qty'=>$ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number'],
                'price'=>$ret_info['from_services']['Medical Insurance'],
                'amount'=>($ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number'])*$ret_info['from_services']['Medical Insurance'],

            ];
            $services[]=$insurance;
        }
        if(!empty($ret_info['from_services']['Airport Pickup'])){

            $dropoff = new Carbon($dep_flight->departureDate);
            $dropoff = $dropoff->format('D d M Y');

            $pickup = [
                'title' => 'Airport Drop off',
                'sub_title'=>$ret_info['from'].', '.$dropoff,
                'qty'=>$cars,
                'price'=>$ret_info['from_services']['Airport Pickup'],
                'amount'=>intval($cars)*intval($ret_info['from_services']['Airport Pickup']),
            ];

            $services[]=$pickup;
        }
        if(!empty($ret_info['from_services']['City Tour'])){

            $city_tour = [
                'title' => 'City Tour'.' - '.$ret_info['from'].' to '.$ret_info['to'],
                'sub_title'=>$ret_info['from'],
                'qty'=>$ret_info['child_number']+$ret_info['adult_number'],
                'price'=>$ret_info['from_services']['City Tour'],
                'amount'=>(intval($ret_info['child_number'])+intval($ret_info['adult_number']))*intval($ret_info['from_services']['City Tour']),
            ];

            $services[]=$city_tour;

        }
        if(!empty($ret_info['to_services']['Airport Pickup'])){

            $pick = new Carbon($dep_flight->arrivalDate);
            $pick = $pick->format('D d M Y');

            $pickup = [
                'title' => 'Airport Pick up',
                'sub_title'=>$ret_info['to'].', '.$pick,
                'qty'=>$cars,
                'price'=>$ret_info['to_services']['Airport Pickup'],
                'amount'=>$cars * intval($ret_info['to_services']['Airport Pickup']),
            ];

            $services[]=$pickup;
        }
        if(!empty($ret_info['to_services']['City Tour'])){

            $city_tour = [
                'title' => 'City Tour'.' - '.$ret_info['from'].' to '.$ret_info['to'],
                'sub_title'=>$ret_info['to'],
                'qty'=>$ret_info['child_number']+$ret_info['adult_number'],
                'price'=>$ret_info['to_services']['City Tour'],
                'amount'=>(intval($ret_info['child_number'])+intval($ret_info['adult_number']))*intval($ret_info['to_services']['City Tour']),
            ];

            $services[]=$city_tour;

        }
        $booking_fee = [
            'title' => 'Booking Fee',
            'sub_title'=>$ret_info['from'].' to '.$ret_info['to'].', '.$dep_flight->departureDate,
            'qty'=> $ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number'],
            'price'=>env('Booking_fee'),
            'amount'=>($ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number']) * env('Booking_fee'),
        ];
        $services[]=$booking_fee;
        $ret_info = null;


        $ret_info     = [
            'from' => $ret_flight->fromCity->city,
            'to' => $ret_flight->toCity->city,
            'adult_number' => $ret_flight->adult,
            'child_number' => $ret_flight->child,
            'infant_number' => $ret_flight->infant,
            'adult_price' => '',
            'child_price' => '',
            'infant_price' => '',
            'from_services' => [
                'Medical Insurance' => '',
                'Airport Pickup' => '',
                'City Tour' => '',
            ],
            'to_services' => [
                'Medical Insurance' => '',
                'Airport Pickup' => '',
                'City Tour' => '',
            ],
        ];


        $value = $ret_flight->supplements;
        $value = json_decode($value, true);

        if(isset($value['returning_from_pickup'])){

            if($value['returning_from_pickup'] == true){
                $ret_info['from_services']['Airport Pickup'] = $pickup_price;
            }

        }
        if(isset($value['returning_to_pickup'])){

            if($value['returning_to_pickup'] == true){
                $ret_info['to_services']['Airport Pickup'] = $pickup_price;
            }

        }
        if(isset($value['returning_from_tour'])){

            if($value['returning_from_tour'] == true){
                $ret_info['from_services']['City Tour'] = $city_tour_price;
            }

        }
        if(isset($value['returning_to_tour'])){

            if($value['returning_to_tour'] == true){
                $ret_info['to_services']['City Tour'] = $city_tour_price;
            }

        }





        if(!empty($ret_info['from_services']['Airport Pickup'])){

            $dropoff = new Carbon($ret_flight->departureDate);
            $dropoff = $dropoff->format('D d M Y');

            $pickup = [
                'title' => 'Airport Drop off',
                'sub_title'=>$ret_info['from'].', '.$dropoff,
                'qty'=>$cars,
                'price'=>$ret_info['from_services']['Airport Pickup'],
                'amount'=>intval($cars)*intval($ret_info['from_services']['Airport Pickup']),
            ];

            $services[]=$pickup;
        }

        if(!empty($ret_info['from_services']['City Tour'])){

            $city_tour = [
                'title' => 'City Tour - '.$ret_info['from'].' to '.$ret_info['to'],
                'sub_title'=>$ret_info['from'],
                'qty'=>$ret_info['child_number']+$ret_info['adult_number'],
                'price'=>$ret_info['from_services']['City Tour'],
                'amount'=>(intval($ret_info['child_number'])+intval($ret_info['adult_number']))*intval($ret_info['from_services']['City Tour']),
            ];

            $services[]=$city_tour;

        }


        if(!empty($ret_info['to_services']['Airport Pickup'])){

            $pick = new Carbon($ret_flight->arrivalDate);
            $pick = $pick->format('D d M Y');

            $pickup = [
                'title' => 'Airport Pick up',
                'sub_title'=>$ret_info['to'].', '.$pick,
                'qty'=>$cars,
                'price'=>$ret_info['to_services']['Airport Pickup'],
                'amount'=>intval($cars)*intval($ret_info['to_services']['Airport Pickup']),
            ];

            $services[]=$pickup;
        }


        if(!empty($ret_info['to_services']['City Tour'])){

            $city_tour = [
                'title' => 'City Tour - '.$ret_info['from'].' to '.$ret_info['to'],
                'sub_title'=>$ret_info['to'],
                'qty'=>$ret_info['child_number']+$ret_info['adult_number'],
                'price'=>$ret_info['to_services']['City Tour'],
                'amount'=>(intval($ret_info['child_number'])+intval($ret_info['adult_number']))*intval($ret_info['to_services']['City Tour']),

            ];

            $services[]=$city_tour;

        }




        $booking_fee = [
            'title' => 'Booking Fee',
            'sub_title'=>$ret_info['from'].' to '.$ret_info['to'].', '.$ret_flight->departureDate,
            'qty'=> $ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number'],
            'price'=>env('Booking_fee'),
            'amount'=>($ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number']) * env('Booking_fee'),
        ];

        $services[]=$booking_fee;





    }




    $bcc1 = env('Email_BCC_One');
    $bcc2 = env('Email_BCC_Two');

    $data = [
        'general_info' => $general_info,
        'services' => $services,
    ];

    $to = $dep_flight->email;
    $bcc = [
        "$bcc1","$bcc2"
    ];

    $company = $dep_flight->company;
    $emails = $company->emails;

    if(!empty($emails)){
        $emails = explode(',',$emails);
        foreach ($emails as $email){
            $bcc[]=$email;
        }
    }

    $subject = $company->name.' Payment Receipt - '.$uniId;
    \Mail::to($to)->bcc($bcc)->send(new ReceiptMail($subject, $data));

    $response = [
        'flights'=>$flights
    ];

    return view('mail.receipt', compact('data'));

});

Route::get('/testuniquw', function(){

    $final_rand = '';
    do {
        $rand = substr(md5(microtime()),rand(0,26),5);
        $rand = $rand.time();
        $rand = substr(md5($rand),rand(0,26),5);
        $rand = $rand.uniqid();
        $rand1 = substr(md5($rand),rand(0,26),5);
        $str = "";
        $characters = array_merge(range('A','Z'));
        $max = count($characters) - 1;
        for ($i = 0; $i < 1; $i++) {
            $rand = mt_rand(0, $max);
            $str .= $characters[$rand];
        }
        $final_rand = $rand1.$str;
        $if_count = \App\FlightsSearch::where('uniId', $final_rand)->count();
    }while($if_count > 0);

    $uniId = $final_rand;

    dd($uniId);


    dd(microtime());
    dd(time());
    dd(uniqid());
});


Route::get('/bringoutiatas', function(){

    $the_rph = '{"data":{"isDomestic":false,"airItinerary":{"leaveOptions":[{"flightSegments":[{"departureAirport":{"code":"DXB","name":null,"terminal":null,"cityName":null},"arrivalAirport":{"code":"BEY","name":null,"terminal":null,"cityName":null},"arrivalDate":"23 Jan 2019 04:45:00","departureDate":"23 Jan 2019 03:10:00","operatingAirLine":{"airlineId":0,"code":"ME","name":null,"countryCode":null},"marketingAirLine":{"airlineId":0,"code":"ME","name":null,"countryCode":null},"bookingClassAvail":{"resBookDesigCode":"V","cabinType":"Economy"},"equipment":{"airEquipType":"320","name":null},"flightNumber":"431","stopDuration":"0:00:00:00.0000000","flightDuration":"0:03:35:00.0000000","baggages":[{"ageType":"Adult","allowanceAmount":30,"unit":"Piece","pieceAmount":0,"baggageTextDisplay":"30 \u06a9\u06cc\u0644\u0648\u06af\u0631\u0645"}]},{"departureAirport":{"code":"BEY","name":null,"terminal":null,"cityName":null},"arrivalAirport":{"code":"CDG","name":null,"terminal":null,"cityName":null},"arrivalDate":"23 Jan 2019 19:40:00","departureDate":"23 Jan 2019 15:55:00","operatingAirLine":{"airlineId":0,"code":"AF","name":null,"countryCode":null},"marketingAirLine":{"airlineId":0,"code":"ME","name":null,"countryCode":null},"bookingClassAvail":{"resBookDesigCode":"V","cabinType":"Economy"},"equipment":{"airEquipType":"77W","name":null},"flightNumber":"205","stopDuration":"0:11:10:00.0000000","flightDuration":"0:04:45:00.0000000","baggages":[{"ageType":"Adult","allowanceAmount":30,"unit":"Piece","pieceAmount":0,"baggageTextDisplay":"30 \u06a9\u06cc\u0644\u0648\u06af\u0631\u0645"}]}],"providerMetaData":null,"isChartered":false,"flightAgencyId":null,"isRefundable":false,"resBookDesigQuantity":9,"totalStopDuration":"0:11:10:00.0000000","totalFlightDuration":"0:19:30:00.0000000","hasStop":true,"flightAgencyTitle":null}],"returnOptions":[{"flightSegments":[{"departureAirport":{"code":"CDG","name":null,"terminal":null,"cityName":null},"arrivalAirport":{"code":"BEY","name":null,"terminal":null,"cityName":null},"arrivalDate":"29 Jan 2019 14:15:00","departureDate":"29 Jan 2019 09:00:00","operatingAirLine":{"airlineId":0,"code":"AF","name":null,"countryCode":null},"marketingAirLine":{"airlineId":0,"code":"ME","name":null,"countryCode":null},"bookingClassAvail":{"resBookDesigCode":"V","cabinType":"Economy"},"equipment":{"airEquipType":"77W","name":null},"flightNumber":"206","stopDuration":"0:00:00:00.0000000","flightDuration":"0:04:15:00.0000000","baggages":[{"ageType":"Adult","allowanceAmount":30,"unit":"Piece","pieceAmount":0,"baggageTextDisplay":"30 \u06a9\u06cc\u0644\u0648\u06af\u0631\u0645"}]},{"departureAirport":{"code":"BEY","name":null,"terminal":null,"cityName":null},"arrivalAirport":{"code":"DXB","name":null,"terminal":null,"cityName":null},"arrivalDate":"29 Jan 2019 21:25:00","departureDate":"29 Jan 2019 16:15:00","operatingAirLine":{"airlineId":0,"code":"ME","name":null,"countryCode":null},"marketingAirLine":{"airlineId":0,"code":"ME","name":null,"countryCode":null},"bookingClassAvail":{"resBookDesigCode":"N","cabinType":"Economy"},"equipment":{"airEquipType":"320","name":null},"flightNumber":"428","stopDuration":"0:02:00:00.0000000","flightDuration":"0:03:10:00.0000000","baggages":[{"ageType":"Adult","allowanceAmount":30,"unit":"Piece","pieceAmount":0,"baggageTextDisplay":"30 \u06a9\u06cc\u0644\u0648\u06af\u0631\u0645"}]}],"providerMetaData":null,"isChartered":false,"flightAgencyId":null,"isRefundable":false,"resBookDesigQuantity":9,"totalStopDuration":"0:02:00:00.0000000","totalFlightDuration":"0:09:25:00.0000000","hasStop":true,"flightAgencyTitle":null}],"airItineraryRph":"4#4348157493#95dcdb2b-3954-48ad-a86d-194e1bb6c528"},"airItineraryPricingInfo":{"itinTotalFare":{"baseFare":{"amount":16326530,"currencyCode":"IRR","decimalPlaces":0},"totalFare":{"amount":52203030,"currencyCode":"IRR","decimalPlaces":0},"totalCommsionValue":{"amount":0,"currencyCode":"IRR","decimalPlaces":0}},"ptcFareBreakdowns":[{"passengerFares":[{"passengerTypeQuantity":{"quantity":1,"passengerType":"Adult"},"baseFare":{"amount":16326530,"currencyCode":"IRR","decimalPlaces":0},"totalFare":{"amount":52203030,"currencyCode":"IRR","decimalPlaces":0},"taxes":[{"taxCode":null,"taxName":null,"amount":35876500,"currencyCode":"IRR","decimalPlaces":0}],"commsionValue":{"amount":97959.18,"currencyCode":"IRR","decimalPlaces":0},"originalFare":{"amount":52203030,"currencyCode":"IRR","decimalPlaces":0}}]}]},"moduleId":"4","isRequiredPassportIssueDate":false,"provider":"Parto"},"response":{"successful":true,"errors":[]}}';

    $new_the_rph = json_decode($the_rph, true);
    $new_the_rph = json_encode($new_the_rph, true);
    $new_the_rph = json_decode($new_the_rph);

    $new_the_rph = $new_the_rph->data;

    dd($new_the_rph);

    //deparure flight
    //alway departure airport
    $dep_dep_airport = $new_the_rph->airItinerary->leaveOptions[0]->flightSegments[0]->departureAirport->code;

    //alway arival airport
    $dep_ret_airport = $new_the_rph->airItinerary->leaveOptions[0]->flightSegments;
    $dep_ret_airport = end($dep_ret_airport);
    $dep_ret_airport = $dep_ret_airport->arrivalAirport->code;


    //if returning flight
    $has_returning = false;
    if(isset($new_the_rph->airItinerary->returnOptions[0])){
         $has_returning = true;
         $ret_dep_airpot = $new_the_rph->airItinerary->returnOptions[0]->flightSegments[0]->departureAirport->code;

         $ret_ret_airpot = $new_the_rph->airItinerary->returnOptions[0]->flightSegments;
         $ret_ret_airpot = end($ret_ret_airpot);
         $ret_ret_airpot = $ret_ret_airpot->arrivalAirport->code;
    }


    dd($ret_ret_airpot);




//    dd($dep_ret_airport);


    dd($the_rph);


});

Route::get('/checkchangerate', function(){

    $uniId = '2614fY';







//    dd($euro_exchange_rate_is);



});

Route::get('/somethingwenwrong', function (){

    $id= '845860986';
    return view('something', compact('id'));

});




Route::get('/removespaces', function(){


    $all_airports = \App\airports_full::all();
    foreach ($all_airports as $airport){
        $name = preg_replace('/\s+/', ' ', $airport->name);
        $city = preg_replace('/\s+/', ' ', $airport->city);
        $country = preg_replace('/\s+/', ' ', $airport->country);
        $airport->update([
            "name"=>$name,
            "city"=>$city,
            "country"=>$country,
        ]);
    }


});

Route::get('/tetsiatashiiiiiiit', function(){

    $search_obj = \App\FlightsSearch::find();

    $mythe_country = $search_obj->fromCity;
    $mythe_other_country = $search_obj->toCity;
    $first_country = $mythe_country->country;
    $second_country = $mythe_other_country->country;

    if($first_country == 'Iran' && $second_country =='Iran'){
        if($search_obj->from == 'IKA'){
            $search_obj->from = 'THR';
        }
        if($search_obj->to == 'IKA'){
            $search_obj->to = 'THR';
        }
    }

});



*/



Route::get('/test/iquery', function(){
//    return 'URL: ' . url()->full();
    return request()->all();
});