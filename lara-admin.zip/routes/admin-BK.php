<?php

// Flights Reports

Route::group(['namespace' => 'App\Http\Controllers\Admin'], function () {


    Route::group(['prefix' => 'flights-reports'], function (){
        $this->get('/booking/{company?}', 'ReportsController@bookingReports')->name('reports.flights.booking');
        $this->get('/approved/booking/{company?}', 'ReportsController@bookingReports')->name('reports.flights.booking.approved');
        $this->get('/unapproved/booking/{company?}', 'ReportsController@bookingReports')->name('reports.flights.booking.unapproved');
        $this->get('/booking/{from}/{to}/{company?}', 'ReportsController@bookingReportsBetween')->name('reports.flights.booking.between');
        $this->get('/approved/booking/{from}/{to}/{company?}', 'ReportsController@bookingReportsBetween')->name('reports.flights.booking.between.approved');
        $this->get('/unapproved/booking/{from}/{to}/{company?}', 'ReportsController@bookingReportsBetween')->name('reports.flights.booking.between.unapproved');
        $this->get('/reserved/{company?}', 'ReportsController@reservedReports')->name('reports.flights.reserved');
        $this->get('/reserved/{from}/{to}/{company?}', 'ReportsController@reservedReportsBetween')->name('reports.flights.reserved.between');
        $this->get('/searched/{company?}', 'ReportsController@searchedReports')->name('reports.flights.searched');
        $this->get('/searched/{from}/{to}/{company?}', 'ReportsController@searchedReportsBetween')->name('reports.flights.searched.between');
        $this->get('/stats/overview/{from}/{to}/{company?}', 'ReportsController@statsOverview');
        $this->get('/stats/finance/{from}/{to}/{company?}', 'ReportsController@financeOverview');
        $this->get('/selected/{company?}', 'ReportsController@selectReports')->name('reports.flights.select');
        $this->get('/selected/{from}/{to}/{company?}', 'ReportsController@selectReportsBetween')->name('reports.flights.select.between');

        // Show Traveler Information
        $this->get('/traveler-info/{uniId}', 'ReportsController@travelerInfo')->name('reports.traveler');

        // Resend Ticket
        $this->get('/ticket-send/{uniId}', 'CompleteController@resendTicket')->name('ticket.send');

        // Put Reserve on Queue
        $this->get('/queued/{uniId}', 'CompleteController@putReserveOnQueue')->name('reserve.queue');

    });

    Route::group(['prefix' => 'excel'], function (){
        $this->get('/booking', 'ExcelController@create')->name('excel.booking');
        $this->get('/searched', 'ExcelController@create')->name('excel.searched');
        $this->get('/reserved', 'ExcelController@create')->name('excel.reserved');
        $this->get('/select', 'ExcelController@create')->name('excel.select');
    });

// Stats
    Route::get('/stats/users', 'ReportsController@usersOverview');
    Route::get('/complete/pay', 'CompleteController@completePay')->name('complete.pay');
    Route::get('/rebook/{uniId}', 'CompleteController@rebook')->name('complete.rebook');
    Route::get('/chart/overview', 'ChartController@chartData')->name('chart.overview');
    Route::get('/rdate', function (){})->name('rdate');
    Route::post('/date-picker', 'ReportsController@datePicker')->name('admin.date-picker');
});


Route::group(['namespace' => 'App\Http\Controllers'], function () {

Route::get('/agents', 'CompanyController@index')->name('agents');
Route::post('/edit/company/{id}', 'CompanyController@edit');


});

// Complete The Defects
