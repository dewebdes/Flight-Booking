<?php

use App\FlightSelect;
use App\Http\ExtraClasses\General\AlibabaGeneral;

Route::get('/', function (){
    DB::table('user_discount')
        ->insert(['uni_id' => '1234abc', 'discount_id' => 1, 'status' => 'success', 'created_at' => \Carbon\Carbon::now()]);
    return 'Done';
});

Route::get('/hi', function (){
    $alibabaToken = AlibabaGeneral::getToken();
    $alibaba_api_address = env("Alibaba_Base_Url");
    $uri = '/api/v1/Available/GetPricedItineraryByRph';

    $request_body = [
        'rph' => '18#f83e1c59-eb9f-4c65-b240-eb3d90fd3f34'
    ];

    $request_body = json_encode($request_body, true);

    $client = new \GuzzleHttp\Client([
        'headers' => [
            'cache-control' => 'no-cache',
            'content-type' => 'application/json',
            'x-zumo-auth' => $alibabaToken,
        ]
    ]);

    $response = $client->post($alibaba_api_address.$uri,
        ['body' => $request_body]
    );
    $response = $response->getBody()->getContents();
    $response = json_decode($response, true);

    $response = json_encode($response['data'], true);
    return $response;
});

Route::get('/find/{uniId}', function ($uniId){
    $roundTrip = false;
    $totalPrice = 0;
    $flights = FlightSelect::latest()->where('uniId', $uniId)->get();
    $count = FlightSelect::latest()->where('uniId', $uniId)->count();
    if($count > 1){
        $roundTrip = true;
        $totalPrice = $flights[0]['euro_amount'] + $flights[1]['euro_amount'];
    } elseif($count == 0){
        return [
            'roundTrip'  => 'No',
            'totalPrice' => '0',
            'message'    => 'unique id is wrong'
        ];
    } else{
        $totalPrice = $flights[0]['euro_amount'];
    }

    return [
        'roundTrip'  => $roundTrip,
        'totalPrice' => $totalPrice,
        'message'    => 'success'
    ];
});

Route::get('/concat', function (){
    $arr1 = array('one', 'two');
    $arr2 = array('three', 'four');
    $arr3 = array_merge($arr1, $arr2);
    return $arr3;
});

Route::get('/return', function (){
    $uniId = 'e5d2411513dbe9c99caccfa9ee4bdd7d';
    $flights = \App\FlightReserve::where('uniId', $uniId)->orderBy('id', 'desc')->get();
    return $flights;
});

Route::get('/gateway', function (){
    return view('test.gateway');
});

Route::get('/mail', function (){
    $data = [
        'uniId' => '5bc31978b7ddc',
        'totalPrice' => '112',
        'paymentMethod' => 'Credit Card',
        'cardNumber' => '940000******0003',
        'cardType' => 'Visa',
        'cardHolder' => 'Hassan',
        'name' => 'MohammadReza'
    ];
    \Illuminate\Support\Facades\Mail::to('mrh_haghighi@yahoo.com')->send(new \App\Mail\ReceiptMail($data));
    return 'Done';
});

Route::get('/mail2/{uniId}', 'FlightBookingController@sendReceiptMail');

Route::get('/post-pay-load/{uniId}', 'FlightBookingController@sendReceiptMail');

Route::get('/total-price/{uniId}', 'FlightReserveController@roundTripKnow');

Route::get('/ru', function (){
    $dat = getrusage();
    ini_set('max_execution_time', 1000);
    echo "MAX EXECUTION TIME OUT: " . ini_get('max_execution_time');

    echo "<hr>";

    echo "number of block output operations: " . $dat["ru_oublock"] . "<br>";       // number of block output operations
    echo "number of block input operations: " . $dat["ru_inblock"] . "<br>";       // number of block input operations
    echo "number of IPC messages sent: " . $dat["ru_msgsnd"] . "<br>";        // number of IPC messages sent
    echo "number of IPC messages received: " . $dat["ru_msgrcv"] . "<br>";        // number of IPC messages received
    echo "maximum resident set size: " . $dat["ru_maxrss"] . "<br>";        // maximum resident set size
    echo "integral shared memory size: " . $dat["ru_ixrss"] . "<br>";         // integral shared memory size
    echo "integral unshared data size: " . $dat["ru_idrss"] . "<br>";         // integral unshared data size
    echo "number of page reclaims (soft page faults): " . $dat["ru_minflt"] . "<br>";        // number of page reclaims (soft page faults)
    echo "number of page faults (hard page faults): " . $dat["ru_majflt"] . "<br>";        // number of page faults (hard page faults)
    echo "number of signals received: " . $dat["ru_nsignals"] . "<br>";      // number of signals received
    echo "number of voluntary context switches: " . $dat["ru_nvcsw"] . "<br>";         // number of voluntary context switches
    echo "number of involuntary context switches: " . $dat["ru_nivcsw"] . "<br>";        // number of involuntary context switches
    echo "number of swaps: " . $dat["ru_nswap"] . "<br>";         // number of swaps
    echo "user time used (microseconds): " . $dat["ru_utime.tv_usec"] . "<br>"; // user time used (microseconds)
    echo "user time used (seconds): " . $dat["ru_utime.tv_sec"] . "<br>";  // user time used (seconds)
    echo "system time used (microseconds): " . $dat["ru_stime.tv_usec"] . "<br>"; // system time used (microseconds)
});



Route::get('/checkifitworks', function(){


    $ui="4c44bX";
    $flightReserved = \App\FlightReserve::where('uniId', $ui)->orderBy('id', 'desc')->first();
    
    $flightReserved->update([
       'reserve_status' => 'QUEUED22'
       
    ]);
    dd($flightReserved);
    $flightReserved->save();

    $manualy_queued = \App\FlightReserve::where('reserve_status', 'QUEUED')->pluck('uniId')->toArray();

    if(!empty($manualy_queued)){
        foreach ($manualy_queued as $queued){

            $new_booking = new BookingMain();
            $new_booking = $new_booking->makeBooking($queued);

            if($new_booking['success'] == true){
                $booking = $new_booking['booking'];
                $flights = \App\FlightReserve::where('uniId', $queued)->orderBy('id', 'asc')->get();
                PaymentHandler::createTicket($flights,$booking);
            }


        }
    }    



});



use App\Http\ExtraClasses\Select\SelectMain;
use App\Http\ExtraClasses\Search\MarkUp as Markup;
use Carbon\Carbon;
use App\Mail\ReceiptMail;
use App\Mail\flightTicket;
use App\Mail\Remain;


Route::get('/sendmailtocustomer/{slug}', function ($uniId){


//        $uniId = '24963Y';

        $payment = \App\Payments::where('uniId', $uniId)->first();


        $flights = \App\FlightReserve::where('uniId', $uniId)->orderBy('id', 'asc')->get();
        $dep_flight = null;
        $ret_flight = null;
        $bounded = false;




    $rial_amount = 0;




    if (isset($flights[0])){
        $dep_flight = $flights[0];
        $rial_amount = $dep_flight->alibaba_amount;
    }
    if (isset($flights[1])){
        $ret_flight = $flights[1];
        $rial_amount = $rial_amount + $ret_flight->alibaba_amount;
    }
    if(!empty($ret_flight)){
        if($ret_flight->airItineraryRph == $dep_flight->airItineraryRph){
            $bounded = true;
            $rial_amount = $dep_flight->alibaba_amount;
        }
    }



    $company = $dep_flight->company;




    $paaayment_data = $payment->created_at;
    $paaayment_data = $paaayment_data->format('F d, Y');




    $general_info = [

        'logo' => $company->invoice_logo,
        'bill_to' => $payment->cardholder,
        'bill_to_sub' => $payment->maskedPan,
        'email' => $dep_flight->email,
        'invc_number' => $uniId,
        'invc_date' => $paaayment_data,
        'card_type' => $payment->paymentType,


        'total' => '',
        'discount_value' => '',
        'total_after_discount' => '',
        'rial_amount' => (substr($rial_amount, 0, -4) !== null && (substr($rial_amount, 0, -4) !== false)) ? substr($rial_amount, 0, -4) : ""


    ];

    if(!$bounded){
        if(!empty($ret_flight)){

            $general_info['total']= $dep_flight->total_euro_amount + $ret_flight->total_euro_amount;
            $general_info['discount_value']=$dep_flight->discount_value + $ret_flight->discount_value;
            $general_info['total_after_discount']=$dep_flight->real_paid_amount + $ret_flight->real_paid_amount;

        }else{

            $general_info['total']= $dep_flight->total_euro_amount;
            $general_info['discount_value']=$dep_flight->discount_value;
            $general_info['total_after_discount']=$dep_flight->real_paid_amount;

        }
        $insurance_price = env('Medical_insurance');
        $pickup_price = env('AirportPickup');
        $city_tour_price = env('City_tour');
        $education_price = env('Education_donate_fee');
        $total_passengers = (intval($dep_flight->adult)+intval($dep_flight->child));
        $cars = ceil(($total_passengers / 3));
        $pickup_price =  $cars * $pickup_price;
        $ret_info     = [
            'from' => $dep_flight->fromCity->city,
            'to' => $dep_flight->toCity->city,
            'adult_number' => $dep_flight->adult,
            'child_number' => $dep_flight->child,
            'infant_number' => $dep_flight->infant,
            'adult_price' => '',
            'child_price' => '',
            'infant_price' => '',
            'from_services' => [
                'Medical Insurance' => '',
                'Airport Pickup' => '',
                'City Tour' => '',
                'Education donation'=>'',
                'Education qty' =>''
            ],
            'to_services' => [
                'Medical Insurance' => '',
                'Airport Pickup' => '',
                'City Tour' => '',
            ],
        ];
        $value = $dep_flight->supplements;
        $value = json_decode($value, true);
        if(isset($value['education_donation'])){

            if($value['education_donation'] == true){
                $ret_info['from_services']['Education donation'] = $education_price * $value['education_donation_unit'];
                $ret_info['from_services']['Education qty'] = $value['education_donation_unit'];
            }

        }
        if(isset($value['departure_from_health'])){

            if($value['departure_from_health'] == true){
                $ret_info['from_services']['Medical Insurance'] = $insurance_price;
            }

        }
        if(isset($value['departure_to_health'])){

            if($value['departure_to_health'] == true){
                $ret_info['to_services']['Medical Insurance'] = $insurance_price;
            }

        }
        if(isset($value['departure_from_pickup'])){

            if($value['departure_from_pickup'] == true){
                $ret_info['from_services']['Airport Pickup'] = $pickup_price;
            }

        }
        if(isset($value['departure_to_pickup'])){

            if($value['departure_to_pickup'] == true){
                $ret_info['to_services']['Airport Pickup'] = $pickup_price;
            }

        }
        if(isset($value['departure_from_tour'])){

            if($value['departure_from_tour'] == true){
                $ret_info['from_services']['City Tour'] = $city_tour_price;
            }

        }


        if(isset($value['departure_to_tour'])){

            if($value['departure_to_tour'] == true){
                $ret_info['to_services']['City Tour'] = $city_tour_price;
            }

        }





        $price = $dep_flight->AirItinerary;
        $price = json_decode($price, true);
        $price = $price['airItineraryPricingInfo']['ptcFareBreakdowns'];
        $new = new SelectMain;
        $new = $new->breakPriceCalculator($price);
        $ret_info['adult_price'] = Markup::totalPriceExchange($new['adult_Pack'], $uniId);
        $ret_info['child_price'] = Markup::totalPriceExchange($new['child_pack'], $uniId);
        $ret_info['infant_price'] = Markup::totalPriceExchange($new['infant_pack'], $uniId);
        $services = [];
        $adult = [
            'title' => 'Flight - Adult Passenger',
            'sub_title'=>$ret_info['from'].' to '.$ret_info['to'].', '.$dep_flight->departureDate,
            'qty'=>$ret_info['adult_number'],
            'price'=>$ret_info['adult_price'],
            'amount'=>$ret_info['adult_price'] * $ret_info['adult_number'],

        ];
        $services[]=$adult;
        if($ret_info['child_number'] > 0){
            $child = [
                'title' => 'Flight - Child Passenger',
                'sub_title'=>$ret_info['from'].' to '.$ret_info['to'].', '.$dep_flight->departureDate,
                'qty'=>$ret_info['child_number'],
                'price'=>$ret_info['child_price'],
                'amount'=>$ret_info['child_price'] * $ret_info['child_number'],

            ];
            $services[]=$child;
        }
        if($ret_info['infant_number'] > 0){
            $infant = [
                'title' => 'Flight - Infant Passenger',
                'sub_title'=>$ret_info['from'].' to '.$ret_info['to'].', '.$dep_flight->departureDate,
                'qty'=>$ret_info['infant_number'],
                'price'=>$ret_info['infant_price'],
                'amount'=>$ret_info['infant_price'] * $ret_info['infant_number'],

            ];
            $services[]=$infant;
        }
        if(!empty($ret_info['from_services']['Education donation'])){
            $insurance = [
                'title' => 'Give every child chance to succeed in life',
                'sub_title'=>'Education donation',
                'qty'=>$ret_info['from_services']['Education qty'],
                'price'=>$education_price,
                'amount'=>$ret_info['from_services']['Education donation'],

            ];
            $services[]=$insurance;
        }
        if(!empty($ret_info['from_services']['Medical Insurance'])){
            $insurance = [
                'title' => 'Medical Insurance',
                'sub_title'=>'',
                'qty'=>$ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number'],
                'price'=>$ret_info['from_services']['Medical Insurance'],
                'amount'=>($ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number'])*$ret_info['from_services']['Medical Insurance'],

            ];
            $services[]=$insurance;
        }
        if(!empty($ret_info['from_services']['Airport Pickup'])){

            $dropoff = new Carbon($dep_flight->departureDate);
            $dropoff = $dropoff->format('D d M Y');

            $pickup = [
                'title' => 'Airport Drop off',
                'sub_title'=>$ret_info['from'].', '.$dropoff,
                'qty'=>$cars,
                'price'=>$ret_info['from_services']['Airport Pickup'],
                'amount'=>intval($cars)*intval($ret_info['from_services']['Airport Pickup']),
            ];

            $services[]=$pickup;
        }


        if(!empty($ret_info['from_services']['City Tour'])){

            $city_tour = [
                'title' => 'City Tour'.' - '.$ret_info['from'].' to '.$ret_info['to'],
                'sub_title'=>$ret_info['from'],
                'qty'=>$ret_info['child_number']+$ret_info['adult_number'],
                'price'=>$ret_info['from_services']['City Tour'],
                'amount'=>(intval($ret_info['child_number'])+intval($ret_info['adult_number']))*intval($ret_info['from_services']['City Tour']),
            ];

            $services[]=$city_tour;

        }
        if(!empty($ret_info['to_services']['Airport Pickup'])){

            $pick = new Carbon($dep_flight->arrivalDate);
            $pick = $pick->format('D d M Y');

            $pickup = [
                'title' => 'Airport Pick up',
                'sub_title'=>$ret_info['to'].', '.$pick,
                'qty'=>$cars,
                'price'=>$ret_info['to_services']['Airport Pickup'],
                'amount'=>$cars * intval($ret_info['to_services']['Airport Pickup']),
            ];

            $services[]=$pickup;
        }
        if(!empty($ret_info['to_services']['City Tour'])){

            $city_tour = [
                'title' => 'City Tour'.' - '.$ret_info['from'].' to '.$ret_info['to'],
                'sub_title'=>$ret_info['to'],
                'qty'=>$ret_info['child_number']+$ret_info['adult_number'],
                'price'=>$ret_info['to_services']['City Tour'],
                'amount'=>(intval($ret_info['child_number'])+intval($ret_info['adult_number']))*intval($ret_info['to_services']['City Tour']),
            ];

            $services[]=$city_tour;

        }

//        dd($services);



        $booking_fee = [
            'title' => 'Booking Fee',
            'sub_title'=>$ret_info['from'].' to '.$ret_info['to'].', '.$dep_flight->departureDate,
            'qty'=> $ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number'],
            'price'=>env('Booking_fee'),
            'amount'=>($ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number']) * env('Booking_fee'),
        ];
        $services[]=$booking_fee;
        $ret_info = null;
        if(!empty($ret_flight)){
            $ret_info     = [
                'from' => $ret_flight->fromCity->city,
                'to' => $ret_flight->toCity->city,
                'adult_number' => $ret_flight->adult,
                'child_number' => $ret_flight->child,
                'infant_number' => $ret_flight->infant,
                'adult_price' => '',
                'child_price' => '',
                'infant_price' => '',
                'from_services' => [
                    'Medical Insurance' => '',
                    'Airport Pickup' => '',
                    'City Tour' => '',
                ],
                'to_services' => [
                    'Medical Insurance' => '',
                    'Airport Pickup' => '',
                    'City Tour' => '',
                ],
            ];


            $value = $ret_flight->supplements;
            $value = json_decode($value, true);

            if(isset($value['returning_from_health'])){

                if($value['returning_from_health'] == true){
                    $ret_info['from_services']['Medical Insurance'] = $insurance_price;
                }

            }
            if(isset($value['returning_to_health'])){

                if($value['returning_to_health'] == true){
                    $ret_info['to_services']['Medical Insurance'] = $insurance_price;
                }

            }
            if(isset($value['returning_from_pickup'])){

                if($value['returning_from_pickup'] == true){
                    $ret_info['from_services']['Airport Pickup'] = $pickup_price;
                }

            }
            if(isset($value['returning_to_pickup'])){

                if($value['returning_to_pickup'] == true){
                    $ret_info['to_services']['Airport Pickup'] = $pickup_price;
                }

            }
            if(isset($value['returning_from_tour'])){

                if($value['returning_from_tour'] == true){
                    $ret_info['from_services']['City Tour'] = $city_tour_price;
                }

            }

            if(isset($value['returning_to_tour'])){

                if($value['returning_to_tour'] == true){
                    $ret_info['to_services']['City Tour'] = $city_tour_price;
                }

            }




            $price = $ret_flight->AirItinerary;
            $price = json_decode($price, true);
            $price = $price['airItineraryPricingInfo']['ptcFareBreakdowns'];
            $new = new SelectMain;
            $new = $new->breakPriceCalculator($price);

            $ret_info['adult_price'] = Markup::totalPriceExchange($new['adult_Pack'], $uniId);
            $ret_info['child_price'] = Markup::totalPriceExchange($new['child_pack'], $uniId);
            $ret_info['infant_price'] = Markup::totalPriceExchange($new['infant_pack'], $uniId);




            $adult = [
                'title' => 'Flight - Adult Passenger',
                'sub_title'=>$ret_info['from'].' to '.$ret_info['to'].', '.$ret_flight->departureDate,
                'qty'=>$ret_info['adult_number'],
                'price'=>$ret_info['adult_price'],
                'amount'=>$ret_info['adult_price'] * $ret_info['adult_number'],

            ];
            $services[]=$adult;

            if($ret_info['child_number'] > 0){
                $child = [
                    'title' => 'Flight - Child Passenger',
                    'sub_title'=>$ret_info['from'].' to '.$ret_info['to'].', '.$ret_flight->departureDate,
                    'qty'=>$ret_info['child_number'],
                    'price'=>$ret_info['child_price'],
                    'amount'=>$ret_info['child_price'] * $ret_info['child_number'],

                ];
                $services[]=$child;
            }
            if($ret_info['infant_number'] > 0){
                $infant = [
                    'title' => 'Flight - Infant Passenger',
                    'sub_title'=>$ret_info['from'].' to '.$ret_info['to'].', '.$ret_flight->departureDate,
                    'qty'=>$ret_info['infant_number'],
                    'price'=>$ret_info['infant_price'],
                    'amount'=>$ret_info['infant_price'] * $ret_info['infant_number'],

                ];
                $services[]=$infant;
            }




            if(!empty($ret_info['from_services']['Airport Pickup'])){

                $dropoff = new Carbon($ret_flight->departureDate);
                $dropoff = $dropoff->format('D d M Y');

                $pickup = [
                    'title' => 'Airport Drop off',
                    'sub_title'=>$ret_info['from'].', '.$dropoff,
                    'qty'=>$cars,
                    'price'=>$ret_info['from_services']['Airport Pickup'],
                    'amount'=>intval($cars)*intval($ret_info['from_services']['Airport Pickup']),
                ];

                $services[]=$pickup;
            }

            if(!empty($ret_info['from_services']['City Tour'])){

                $city_tour = [
                    'title' => 'City Tour - '.$ret_info['from'].' to '.$ret_info['to'],
                    'sub_title'=>$ret_info['from'],
                    'qty'=>$ret_info['child_number']+$ret_info['adult_number'],
                    'price'=>$ret_info['from_services']['City Tour'],
                    'amount'=>(intval($ret_info['child_number'])+intval($ret_info['adult_number']))*intval($ret_info['from_services']['City Tour']),
                ];

                $services[]=$city_tour;

            }


            if(!empty($ret_info['to_services']['Airport Pickup'])){

                $pick = new Carbon($ret_flight->arrivalDate);
                $pick = $pick->format('D d M Y');

                $pickup = [
                    'title' => 'Airport Pick up',
                    'sub_title'=>$ret_info['to'].', '.$pick,
                    'qty'=>$cars,
                    'price'=>$ret_info['to_services']['Airport Pickup'],
                    'amount'=>intval($cars)*intval($ret_info['to_services']['Airport Pickup']),
                ];

                $services[]=$pickup;
            }


            if(!empty($ret_info['to_services']['City Tour'])){

                $city_tour = [
                    'title' => 'City Tour - '.$ret_info['from'].' to '.$ret_info['to'],
                    'sub_title'=>$ret_info['to'],
                    'qty'=>$ret_info['child_number']+$ret_info['adult_number'],
                    'price'=>$ret_info['to_services']['City Tour'],
                    'amount'=>(intval($ret_info['child_number'])+intval($ret_info['adult_number']))*intval($ret_info['to_services']['City Tour']),
                ];

                $services[]=$city_tour;

            }



            $booking_fee = [
                'title' => 'Booking Fee',
                'sub_title'=>$ret_info['from'].' to '.$ret_info['to'].', '.$ret_flight->departureDate,
                'qty'=> $ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number'],
                'price'=>env('Booking_fee'),
                'amount'=>($ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number']) * env('Booking_fee'),
            ];

            $services[]=$booking_fee;




        }
    }else{


        $general_info['total']= $dep_flight->total_euro_amount + $ret_flight->total_euro_amount;
        $general_info['discount_value']=$dep_flight->discount_value + $ret_flight->discount_value;
        $general_info['total_after_discount']=$dep_flight->real_paid_amount + $ret_flight->real_paid_amount;


        $insurance_price = env('Medical_insurance');
        $pickup_price = env('AirportPickup');
        $city_tour_price = env('City_tour');
        $education_price = env('Education_donate_fee');
        $total_passengers = (intval($dep_flight->adult)+intval($dep_flight->child));
        $cars = ceil(($total_passengers / 3));

//            $pickup_price =  $cars * $pickup_price;

        $ret_info     = [
            'from' => $dep_flight->fromCity->city,
            'to' => $dep_flight->toCity->city,
            'adult_number' => $dep_flight->adult,
            'child_number' => $dep_flight->child,
            'infant_number' => $dep_flight->infant,
            'adult_price' => '',
            'child_price' => '',
            'infant_price' => '',
            'from_services' => [
                'Medical Insurance' => '',
                'Airport Pickup' => '',
                'City Tour' => '',
                'Education donation'=>'',
                'Education qty' =>''
            ],
            'to_services' => [
                'Medical Insurance' => '',
                'Airport Pickup' => '',
                'City Tour' => '',
            ],
        ];
        $value = $dep_flight->supplements;
        $value = json_decode($value, true);
        if(isset($value['education_donation'])){

            if($value['education_donation'] == true){
                $ret_info['from_services']['Education donation'] = $education_price * $value['education_donation_unit'];
                $ret_info['from_services']['Education qty'] = $value['education_donation_unit'];
            }

        }
        if(isset($value['departure_from_health'])){

            if($value['departure_from_health'] == true){
                $ret_info['from_services']['Medical Insurance'] = $insurance_price;
            }

        }
        if(isset($value['departure_from_pickup'])){

            if($value['departure_from_pickup'] == true){
                $ret_info['from_services']['Airport Pickup'] = $pickup_price;
            }

        }
        if(isset($value['departure_to_pickup'])){

            if($value['departure_to_pickup'] == true){
                $ret_info['to_services']['Airport Pickup'] = $pickup_price;
            }

        }
        if(isset($value['departure_from_tour'])){

            if($value['departure_from_tour'] == true){
                $ret_info['from_services']['City Tour'] = $city_tour_price;
            }

        }
        if(isset($value['departure_to_tour'])){

            if($value['departure_to_tour'] == true){
                $ret_info['to_services']['City Tour'] = $city_tour_price;
            }

        }
        $price = $dep_flight->AirItinerary;
        $price = json_decode($price, true);
        $price = $price['airItineraryPricingInfo']['ptcFareBreakdowns'];
        $new = new SelectMain;
        $new = $new->breakPriceCalculator($price);
        $ret_info['adult_price'] = Markup::totalPriceExchange($new['adult_Pack'], $uniId);
        $ret_info['child_price'] = Markup::totalPriceExchange($new['child_pack'], $uniId);
        $ret_info['infant_price'] = Markup::totalPriceExchange($new['infant_pack'], $uniId);
        $services = [];
        $adult = [
            'title' => 'Flight - Adult Passenger',
            'sub_title'=> $ret_info['from'].' to '.$ret_info['to'].', '.$dep_flight->departureDate.' <br> '.$ret_info['to'].' to '.$ret_info['from'].', '.$ret_flight->departureDate,
            'qty'=>$ret_info['adult_number'],
            'price'=>$ret_info['adult_price'],
            'amount'=>$ret_info['adult_price'] * $ret_info['adult_number'],

        ];
        $services[]=$adult;
        if($ret_info['child_number'] > 0){
            $child = [
                'title' => 'Flight - Child Passenger',
                'sub_title'=> $ret_info['from'].' to '.$ret_info['to'].', '.$dep_flight->departureDate.' <br> '.$ret_info['to'].' to '.$ret_info['from'].', '.$ret_flight->departureDate,
                'qty'=>$ret_info['child_number'],
                'price'=>$ret_info['child_price'],
                'amount'=>$ret_info['child_price'] * $ret_info['child_number'],

            ];
            $services[]=$child;
        }
        if($ret_info['infant_number'] > 0){
            $infant = [
                'title' => 'Flight - Infant Passenger',
                'sub_title'=> $ret_info['from'].' to '.$ret_info['to'].', '.$dep_flight->departureDate.' <br> '.$ret_info['to'].' to '.$ret_info['from'].', '.$ret_flight->departureDate,
                'qty'=>$ret_info['infant_number'],
                'price'=>$ret_info['infant_price'],
                'amount'=>$ret_info['infant_price'] * $ret_info['infant_number'],

            ];
            $services[]=$infant;
        }
        if(!empty($ret_info['from_services']['Education donation'])){
            $insurance = [
                'title' => 'Give every child chance to succeed in life',
                'sub_title'=>'Education donation',
                'qty'=>$ret_info['from_services']['Education qty'],
                'price'=>$education_price,
                'amount'=>$ret_info['from_services']['Education donation'],

            ];
            $services[]=$insurance;
        }
        if(!empty($ret_info['from_services']['Medical Insurance'])){
            $insurance = [
                'title' => 'Medical Insurance',
                'sub_title'=>'',
                'qty'=>$ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number'],
                'price'=>$ret_info['from_services']['Medical Insurance'],
                'amount'=>($ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number'])*$ret_info['from_services']['Medical Insurance'],

            ];
            $services[]=$insurance;
        }
        if(!empty($ret_info['from_services']['Airport Pickup'])){

            $dropoff = new Carbon($dep_flight->departureDate);
            $dropoff = $dropoff->format('D d M Y');

            $pickup = [
                'title' => 'Airport Drop off',
                'sub_title'=>$ret_info['from'].', '.$dropoff,
                'qty'=>$cars,
                'price'=>$ret_info['from_services']['Airport Pickup'],
                'amount'=>intval($cars)*intval($ret_info['from_services']['Airport Pickup']),
            ];

            $services[]=$pickup;
        }
        if(!empty($ret_info['from_services']['City Tour'])){

            $city_tour = [
                'title' => 'City Tour'.' - '.$ret_info['from'].' to '.$ret_info['to'],
                'sub_title'=>$ret_info['from'],
                'qty'=>$ret_info['child_number']+$ret_info['adult_number'],
                'price'=>$ret_info['from_services']['City Tour'],
                'amount'=>(intval($ret_info['child_number'])+intval($ret_info['adult_number']))*intval($ret_info['from_services']['City Tour']),
            ];

            $services[]=$city_tour;

        }
        if(!empty($ret_info['to_services']['Airport Pickup'])){

            $pick = new Carbon($dep_flight->arrivalDate);
            $pick = $pick->format('D d M Y');

            $pickup = [
                'title' => 'Airport Pick up',
                'sub_title'=>$ret_info['to'].', '.$pick,
                'qty'=>$cars,
                'price'=>$ret_info['to_services']['Airport Pickup'],
                'amount'=>$cars * intval($ret_info['to_services']['Airport Pickup']),
            ];

            $services[]=$pickup;
        }
        if(!empty($ret_info['to_services']['City Tour'])){

            $city_tour = [
                'title' => 'City Tour'.' - '.$ret_info['from'].' to '.$ret_info['to'],
                'sub_title'=>$ret_info['to'],
                'qty'=>$ret_info['child_number']+$ret_info['adult_number'],
                'price'=>$ret_info['to_services']['City Tour'],
                'amount'=>(intval($ret_info['child_number'])+intval($ret_info['adult_number']))*intval($ret_info['to_services']['City Tour']),
            ];

            $services[]=$city_tour;

        }
        $booking_fee = [
            'title' => 'Booking Fee',
            'sub_title'=>$ret_info['from'].' to '.$ret_info['to'].', '.$dep_flight->departureDate,
            'qty'=> $ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number'],
            'price'=>env('Booking_fee'),
            'amount'=>($ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number']) * env('Booking_fee'),
        ];
        $services[]=$booking_fee;
        $ret_info = null;


        $ret_info     = [
            'from' => $ret_flight->fromCity->city,
            'to' => $ret_flight->toCity->city,
            'adult_number' => $ret_flight->adult,
            'child_number' => $ret_flight->child,
            'infant_number' => $ret_flight->infant,
            'adult_price' => '',
            'child_price' => '',
            'infant_price' => '',
            'from_services' => [
                'Medical Insurance' => '',
                'Airport Pickup' => '',
                'City Tour' => '',
            ],
            'to_services' => [
                'Medical Insurance' => '',
                'Airport Pickup' => '',
                'City Tour' => '',
            ],
        ];


        $value = $ret_flight->supplements;
        $value = json_decode($value, true);

        if(isset($value['returning_from_pickup'])){

            if($value['returning_from_pickup'] == true){
                $ret_info['from_services']['Airport Pickup'] = $pickup_price;
            }

        }
        if(isset($value['returning_to_pickup'])){

            if($value['returning_to_pickup'] == true){
                $ret_info['to_services']['Airport Pickup'] = $pickup_price;
            }

        }
        if(isset($value['returning_from_tour'])){

            if($value['returning_from_tour'] == true){
                $ret_info['from_services']['City Tour'] = $city_tour_price;
            }

        }
        if(isset($value['returning_to_tour'])){

            if($value['returning_to_tour'] == true){
                $ret_info['to_services']['City Tour'] = $city_tour_price;
            }

        }





        if(!empty($ret_info['from_services']['Airport Pickup'])){

            $dropoff = new Carbon($ret_flight->departureDate);
            $dropoff = $dropoff->format('D d M Y');

            $pickup = [
                'title' => 'Airport Drop off',
                'sub_title'=>$ret_info['from'].', '.$dropoff,
                'qty'=>$cars,
                'price'=>$ret_info['from_services']['Airport Pickup'],
                'amount'=>intval($cars)*intval($ret_info['from_services']['Airport Pickup']),
            ];

            $services[]=$pickup;
        }

        if(!empty($ret_info['from_services']['City Tour'])){

            $city_tour = [
                'title' => 'City Tour - '.$ret_info['from'].' to '.$ret_info['to'],
                'sub_title'=>$ret_info['from'],
                'qty'=>$ret_info['child_number']+$ret_info['adult_number'],
                'price'=>$ret_info['from_services']['City Tour'],
                'amount'=>(intval($ret_info['child_number'])+intval($ret_info['adult_number']))*intval($ret_info['from_services']['City Tour']),
            ];

            $services[]=$city_tour;

        }


        if(!empty($ret_info['to_services']['Airport Pickup'])){

            $pick = new Carbon($ret_flight->arrivalDate);
            $pick = $pick->format('D d M Y');

            $pickup = [
                'title' => 'Airport Pick up',
                'sub_title'=>$ret_info['to'].', '.$pick,
                'qty'=>$cars,
                'price'=>$ret_info['to_services']['Airport Pickup'],
                'amount'=>intval($cars)*intval($ret_info['to_services']['Airport Pickup']),
            ];

            $services[]=$pickup;
        }


        if(!empty($ret_info['to_services']['City Tour'])){

            $city_tour = [
                'title' => 'City Tour - '.$ret_info['from'].' to '.$ret_info['to'],
                'sub_title'=>$ret_info['to'],
                'qty'=>$ret_info['child_number']+$ret_info['adult_number'],
                'price'=>$ret_info['to_services']['City Tour'],
                'amount'=>(intval($ret_info['child_number'])+intval($ret_info['adult_number']))*intval($ret_info['to_services']['City Tour']),

            ];

            $services[]=$city_tour;

        }




        $booking_fee = [
            'title' => 'Booking Fee',
            'sub_title'=>$ret_info['from'].' to '.$ret_info['to'].', '.$ret_flight->departureDate,
            'qty'=> $ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number'],
            'price'=>env('Booking_fee'),
            'amount'=>($ret_info['infant_number']+$ret_info['child_number']+$ret_info['adult_number']) * env('Booking_fee'),
        ];

        $services[]=$booking_fee;





    }




    $bcc1 = env('Email_BCC_One');
    $bcc2 = env('Email_BCC_Two');

    $data = [
        'general_info' => $general_info,
        'services' => $services,
    ];

    $to = $dep_flight->email;
    $bcc = [
        "$bcc1","$bcc2"
    ];

    $company = $dep_flight->company;
    $emails = $company->emails;

    if(!empty($emails)){
        $emails = explode(',',$emails);
        foreach ($emails as $email){
            $bcc[]=$email;
        }
    }

    $subject = $company->name.' Payment Receipt - '.$uniId;
    try{

        \Mail::to($to)->bcc($bcc)->send(new ReceiptMail($subject, $data));
    }catch(\Exception $e){

    }

    $response = [
        'flights'=>$flights
    ];


    return $response;



});
Route::get('/sendtickettocustomer/{slug}', function ($uniId){

//        $uniId = '24963Y';
        $unique_id = $uniId;

        $reserves = \App\FlightReserve::where('uniId', $unique_id)->orderBy('id', 'asc')->get();
        $booking = \App\FlightBooking::where('uniId', $unique_id)->first();

        $unique_id = $booking->uniId;


        $dep_flight = null;
        $ret_flight = null;
        $bounded = false;

        $dep_flight = $reserves[0];

        if(isset($reserves[1])){
            if(!empty($reserves[1])){
                $ret_flight = $reserves[1];

                if ($ret_flight->airItineraryRph == $dep_flight->airItineraryRph){
                    $bounded = true;
                }
            }
        }




        $company = $dep_flight->company;


        $travelers = $dep_flight->traveler_info;
        $travelers = json_decode($travelers);
        $travelers = $travelers->AirTravelers;

        $items = [];
        $i=0;
        foreach ($travelers as $traveler){

            $name = $traveler->PersonName;
            $name = ucfirst($name->GivenName).' '.ucfirst($name->Surname);
            $items[$i]['name'] = $name;


            $items[$i]['passport_no'] = $traveler->Document->DocId;

            $items[$i]['from_city'] = $dep_flight->fromcity->city;
            $items[$i]['to_city'] = $dep_flight->tocity->city;
            $items[$i]['from_iata'] = $dep_flight->fromcity->iata;
            $items[$i]['from_iata'] = $dep_flight->fromcity->iata;
            $items[$i]['to_iata'] = $dep_flight->tocity->iata;

            $departureDate = new Carbon($dep_flight->departureDate);
            $arrivalDate = new Carbon($dep_flight->arrivalDate);

            $items[$i]['departure'] = $departureDate->format('H:i A');
            $items[$i]['boarding'] = $departureDate->subHours(1)->format('H:i A');
            $items[$i]['date'] = $departureDate->format('d M Y');
            $items[$i]['arrival'] = $arrivalDate->format('H:i A');
            $items[$i]['class'] = json_decode($dep_flight->AirItinerary)->airItinerary->leaveOptions[0]->flightSegments[0]->bookingClassAvail->cabinType;
            $items[$i]['operated_by'] = $dep_flight->Airline->name.' '.$dep_flight->flightNumber;

            $items[$i]['airline'] = json_decode($dep_flight->AirItinerary)->isDomestic ? 'https://cdn.alibaba.ir/static/img/airlines/Domestic/'.$dep_flight->operatingAirLine.'.png' : 'https://www.gstatic.com/flights/airline_logos/70px/'.$dep_flight->operatingAirLine.'.png';


            $passengers = json_decode($dep_flight->sent_request)->TravelerInfo->AirTravelers;

            foreach ($passengers as $passneger){



                if(($passneger->PersonName->GivenName == $traveler->PersonName->GivenName) && ($passneger->PersonName->Surname == $traveler->PersonName->Surname)){
                    $tkt_ref = $passneger->TravelerRefNumber;
                }
            }

            $bkb = $booking->Alibaba_book_response;
            $bkb = json_decode($bkb);
            $bkb = $bkb->data->airBookRs;

            foreach ($bkb as $bp){

                foreach ($bp->ticketing as $b){

                    if($b->travelerRefNumber == $tkt_ref){

                        $items[$i]['tkt_no'] = $b->ticketDocumentNbr;
                        if(empty($b->ticketDocumentNbr)){
                            $items[$i]['tkt_no'] = $bp->airReservation->bookingReferences[0]->id;
                        }

                    }
                };
            }

            $i++;
        }




        if(!$bounded){
            if($ret_flight){

                $dep_flight = $ret_flight;

                $company = $dep_flight->company;


                $travelers = $dep_flight->traveler_info;
                $travelers = json_decode($travelers);
                $travelers = $travelers->AirTravelers;

                $i=sizeof($items);
                foreach ($travelers as $traveler){

                    $name = $traveler->PersonName;
                    $name = ucfirst($name->GivenName).' '.ucfirst($name->Surname);
                    $items[$i]['name'] = $name;


                    $items[$i]['passport_no'] = $traveler->Document->DocId;

                    $items[$i]['from_city'] = $dep_flight->fromcity->city;
                    $items[$i]['to_city'] = $dep_flight->tocity->city;
                    $items[$i]['from_iata'] = $dep_flight->fromcity->iata;
                    $items[$i]['from_iata'] = $dep_flight->fromcity->iata;
                    $items[$i]['to_iata'] = $dep_flight->tocity->iata;

                    $departureDate = new Carbon($dep_flight->departureDate);
                    $arrivalDate = new Carbon($dep_flight->arrivalDate);

                    $items[$i]['departure'] = $departureDate->format('H:i A');
                    $items[$i]['boarding'] = $departureDate->subHours(1)->format('H:i A');
                    $items[$i]['date'] = $departureDate->format('d M Y');
                    $items[$i]['arrival'] = $arrivalDate->format('H:i A');
                    $items[$i]['class'] = json_decode($dep_flight->AirItinerary)->airItinerary->leaveOptions[0]->flightSegments[0]->bookingClassAvail->cabinType;
                    $items[$i]['operated_by'] = $dep_flight->Airline->name.' '.$dep_flight->flightNumber;

                    $items[$i]['airline'] = json_decode($dep_flight->AirItinerary)->isDomestic ? 'https://cdn.alibaba.ir/static/img/airlines/Domestic/'.$dep_flight->operatingAirLine.'.png' : 'https://www.gstatic.com/flights/airline_logos/70px/'.$dep_flight->operatingAirLine.'.png';


                    $passengers = json_decode($dep_flight->sent_request)->TravelerInfo->AirTravelers;

                    foreach ($passengers as $passneger){



                        if(($passneger->PersonName->GivenName == $traveler->PersonName->GivenName) && ($passneger->PersonName->Surname == $traveler->PersonName->Surname)){
                            $tkt_ref = $passneger->TravelerRefNumber;
                        }
                    }

                    $bkb = $booking->Alibaba_book_response;
                    $bkb = json_decode($bkb);
                    $bkb = $bkb->data->airBookRs;

                    foreach ($bkb as $bp){

                        foreach ($bp->ticketing as $b){

                            if($b->travelerRefNumber == $tkt_ref){

                                $items[$i]['tkt_no'] = $b->ticketDocumentNbr;
                                if(empty($b->ticketDocumentNbr)){
                                    $items[$i]['tkt_no'] = $bp->airReservation->bookingReferences[0]->id;
                                }
                            }
                        };
                    }

                    $i++;
                }


            }
        }else{

            $dep_flight = $ret_flight;

            $company = $dep_flight->company;


            $travelers = $dep_flight->traveler_info;
            $travelers = json_decode($travelers);
            $travelers = $travelers->AirTravelers;

            $i=sizeof($items);
            foreach ($travelers as $traveler){

                $name = $traveler->PersonName;
                $name = ucfirst($name->GivenName).' '.ucfirst($name->Surname);
                $items[$i]['name'] = $name;


                $items[$i]['passport_no'] = $traveler->Document->DocId;

                $items[$i]['from_city'] = $dep_flight->fromcity->city;
                $items[$i]['to_city'] = $dep_flight->tocity->city;
                $items[$i]['from_iata'] = $dep_flight->fromcity->iata;
                $items[$i]['from_iata'] = $dep_flight->fromcity->iata;
                $items[$i]['to_iata'] = $dep_flight->tocity->iata;

                $departureDate = new Carbon($dep_flight->departureDate);
                $arrivalDate = new Carbon($dep_flight->arrivalDate);

                $items[$i]['departure'] = $departureDate->format('H:i A');
                $items[$i]['boarding'] = $departureDate->subHours(1)->format('H:i A');
                $items[$i]['date'] = $departureDate->format('d M Y');
                $items[$i]['arrival'] = $arrivalDate->format('H:i A');
                $items[$i]['class'] = json_decode($dep_flight->AirItinerary)->airItinerary->leaveOptions[0]->flightSegments[0]->bookingClassAvail->cabinType;
                $items[$i]['operated_by'] = $dep_flight->Airline->name.' '.$dep_flight->flightNumber;

                $items[$i]['airline'] = json_decode($dep_flight->AirItinerary)->isDomestic ? 'https://cdn.alibaba.ir/static/img/airlines/Domestic/'.$dep_flight->operatingAirLine.'.png' : 'https://www.gstatic.com/flights/airline_logos/70px/'.$dep_flight->operatingAirLine.'.png';


                $passengers = json_decode($dep_flight->sent_request)->TravelerInfo->AirTravelers;

                foreach ($items as $it){
                    if($traveler->Document->DocId == $it['passport_no']){
                        if(isset($it['tkt_no'])){
                            $items[$i]['tkt_no'] = $it['tkt_no'];
                            if(empty($b->ticketDocumentNbr)){
                                $items[$i]['tkt_no'] = $bp->airReservation->bookingReferences[0]->id;
                            }
                        }
                    }
                }


                $i++;
            }


        }











        $data=[
            'logo' => $company->logo_address,
            'add'  => $company->tkt_ad_address,
            'items' => $items
        ];




        $pdfFilePath = 'pdfs/tickets/'.$unique_id.'.pdf';
        LPDF::loadView('mail.ticketforpdf', compact(['data']), [], ['format' => 'A4-P'])->save($pdfFilePath);


        $bcc1 = env('Email_BCC_One');
        $bcc2 = env('Email_BCC_Two');

        $to = $dep_flight->email;
        $bcc = [
            "$bcc1","$bcc2"
        ];

        $company = $dep_flight->company;
        $emails = $company->emails;

        if(!empty($emails)){
            $emails = explode(',',$emails);
            foreach ($emails as $email){
                $bcc[]=$email;
            }
        }

        $subject = $company->name.' Your flight - '.$unique_id;
        try{

            \Mail::to($to)->bcc($bcc)->send(new flightTicket($subject, $data));

        }catch(\Exception $e){

        }




});



Route::get('/checkbalance', function(){

    $alibabaToken = AlibabaGeneral::getToken();
    $alibaba_api_address = env("Alibaba_Base_Url");
    $uri = '/api/v1/Credit/GetCredit';


    $client = new \GuzzleHttp\Client([
        'http_errors' => false,
        'headers' => [
            'cache-control' => 'no-cache',
            'content-type' => 'application/json',
            'x-zumo-auth' => $alibabaToken,
        ]
    ]);

    $response = $client->get($alibaba_api_address.$uri);



    $response = $response->getBody()->getContents();
    $response = json_decode($response);
    $response = $response->data;


    $to = 'info@apochi.com';
    $bcc = 'itsupport@apochi.com';


    if($response < 80000000){

    \Mail::to($to)->bcc($bcc)->send(new Remain($response));

    }else{
        return;
    }


});



























