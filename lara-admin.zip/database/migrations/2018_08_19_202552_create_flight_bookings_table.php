<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFlightBookingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('flight_bookings', function (Blueprint $table) {

            $table->increments('id');
            $table->string('uniId');

            $table->string('payment_status')->nullable();
            $table->string('booking_status')->nullable();

            $table->string('email');
            $table->integer('insurance')->nullable();
            $table->integer('city_tour')->nullable();
            $table->integer('airport_pickup')->nullable();


            $table->double('alibaba_amount', 25, 2)->nullable();
            $table->double('ex_change_rate', 25, 2)->nullable();
            $table->double('total_euro_amount', 25, 2)->nullable();
            $table->double('real_euro_amount', 25, 2)->nullable();


            $table->text('Alibaba_book_response')->nullable();
            $table->text('Alibaba_error_response')->nullable();
            $table->text('sent_request')->nullable();
            $table->text('tickets')->nullable();
            $table->integer('tickets_is_sent')->nullable();
            $table->string('ExternalBookIds')->nullable();
            $table->integer('company_id')->nullable();

            $table->text('traveler_info')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('flight_bookings');
    }
}
