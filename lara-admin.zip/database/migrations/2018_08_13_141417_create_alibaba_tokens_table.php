<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAlibabaTokensTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('alibaba_tokens', function (Blueprint $table) {
            $table->increments('id');
            $table->text('access_token');
            $table->string('token_type');
            $table->string('expires_in');
            $table->text('refresh_token');
            $table->string('as_client_id');
            $table->string('userName');
            $table->string('userId');
            $table->text('roles');
            $table->string('isVerified');
            $table->string('AppId');
            $table->string('issued');
            $table->string('expires');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('alibaba_tokens');
    }
}
