<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFlightsSearchesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('flights_searches', function (Blueprint $table) {
            $table->increments('id');
            $table->string('from');
            $table->string('to');
            $table->string('departing');
            $table->string('returning')->nullable();
            $table->integer('adult');
            $table->integer('child');
            $table->integer('infant');
            $table->string('flightClass')->nullable();
            $table->boolean('isDomestic');
            $table->integer('flightType');
            $table->string('uniId');
            $table->integer('company_id')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('flights_searches');
    }
}
