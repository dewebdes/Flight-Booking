<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePaymentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->increments('id');
            $table->string('uniId');
            $table->string('amount');
            $table->string('currency');
            $table->string('paymentType');
            $table->string('financialInstitution');
            $table->string('expiry');
            $table->string('authenticated');
            $table->string('paymentState');
            $table->string('cardholder');
            $table->string('maskedPan');
            $table->string('orderNumber');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payments');
    }
}
