<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFlightSelectsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('flight_selects', function (Blueprint $table) {
            $table->increments('id');
            $table->string('way');
            $table->string('from');
            $table->string('to');
            $table->string('arrivalDate')->nullable();
            $table->string('departureDate')->nullable();
            $table->string('operatingAirLine')->nullable();
            $table->string('bookingClassAvail')->nullable();
            $table->string('flightNumber');
            $table->double('alibaba_amount', 25, 2)->nullable();
            $table->double('ex_change_rate', 25, 2)->nullable();
            $table->double('euro_amount', 25, 2)->nullable();
            $table->string('adult');
            $table->string('child');
            $table->string('infant');
            $table->text('post_pay_load');
            $table->text('get_rph_load');
            $table->string('uniId');
            $table->string('airItineraryRph');
            $table->unique(['uniId', 'airItineraryRph']);
            $table->integer('company_id')->nullable();
            $table->tinyInteger('step')->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('flight_selects');
    }
}
