<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFlightReservesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('flight_reserves', function (Blueprint $table) {

            $table->increments('id');
            $table->string('from');
            $table->string('to');
            $table->string('way');
            $table->string('arrivalDate')->nullable();;
            $table->string('flightNumber')->nullable();
            $table->string('reserve_status')->nullable();
            $table->string('email');
            $table->string('phone');
            $table->string('mobile')->nullable();
            $table->text('traveler_info')->nullable();
            $table->double('alibaba_amount', 25, 2)->nullable();
            $table->double('ex_change_rate', 25, 2)->nullable();
            $table->double('total_euro_amount', 25, 2)->nullable();
            $table->text('insurance')->nullable();
            $table->text('city_tour')->nullable();
            $table->text('airport_pickup')->nullable();
            $table->string('departureDate');
            $table->string('operatingAirLine')->nullable();
            $table->string('uniId');
            $table->string('airItineraryRph');
            $table->string('adult');
            $table->string('child');
            $table->string('infant');
            $table->string('payment_status')->nullable();
            $table->text('AirItinerary');
            $table->text('sent_request');
            $table->text('reserve_response')->nullable();
            $table->text('Alibaba_error_response')->nullable();
            $table->unique(['uniId', 'airItineraryRph']);
            $table->integer('company_id')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('flight_reserves');
    }
}
