package com.ipozal.otus;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.BaseColumns;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.ipozal.otus.R;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import saman.zamani.persiandate.PersianDate;

import static android.provider.AlarmClock.EXTRA_MESSAGE;

public class Main3Activity extends AppCompatActivity {

  //  public SQLiteDatabase db;
    private Button btn;
    private ImageView imageview;
    private static final String IMAGE_DIRECTORY = "/nader";
    private int GALLERY = 1, CAMERA = 2;

    public String actUS="";
    public String actPASS="";
    public String actAVA="";

    WebView NWB1;
    public JavaScriptInterface JSInterface;

    private void saveToDBPerson(String msg) {

        String[] foo = msg.split("#np#");
        //"register2#np#"+
        String dieplat=foo[0];
        String dietkn=foo[1];
        String dieavatarsrc=foo[2];
        String dieregfullname=foo[3];
        String dieregmail=foo[4];
        String ddieregpas=foo[5];
        String ddieregrepas=foo[6];
        String diesendnotify=foo[7];
        String diesendmailnot=foo[8];


        SQLiteDatabase database = new SampleDBSQLiteHelper(this).getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(SampleDBContract.Person.dieplat, dieplat);
        values.put(SampleDBContract.Person.dietkn, dietkn);
        values.put(SampleDBContract.Person.dieavatarsrc, dieavatarsrc);
        values.put(SampleDBContract.Person.dieregfullname, dieregfullname);
        values.put(SampleDBContract.Person.dieregmail, dieregmail);
        values.put(SampleDBContract.Person.ddieregpas, ddieregpas);
        values.put(SampleDBContract.Person.ddieregrepas, ddieregrepas);
        values.put(SampleDBContract.Person.diesendnotify, diesendnotify);
        values.put(SampleDBContract.Person.diesendmailnot, diesendmailnot);
        PersianDate pdate = new PersianDate();
        values.put(SampleDBContract.Person.diedate, pdate.getTime());
        //values.put(SampleDBContract.Employer.COLUMN_DESCRIPTION, binding.descEditText.getText().toString());


        long newRowId = database.insert(SampleDBContract.Person.TABLE_NAME, null, values);

        //Toast.makeText(this, "The new Row Id is " + newRowId, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // setContentView(R.layout.activity_main);




        setContentView(R.layout.activity_main3);

        //workwitdb();

        //--------------------------
        String furl = "file:///android_asset/home.html";
        String stat = "a";
        int dbc=0;

try {
    SQLiteDatabase database = new SampleDBSQLiteHelper(this).getReadableDatabase();
    String[] projection = {
            SampleDBContract.Person._ID,
            SampleDBContract.Person.ddieregpas,
            SampleDBContract.Person.dieregmail,
            SampleDBContract.Person.dieregfullname
    };
    Cursor cursor = database.query(
            SampleDBContract.Person.TABLE_NAME,     // The table to query
            null,                               // The columns to return
            null,                                // The columns for the WHERE clause
            null,                            // The values for the WHERE clause
            null,                                     // don't group the rows
            null,                                     // don't filter by row groups
            null                                      // don't sort
    );

    //DatabaseHandler dbh=new DatabaseHandler(this);
    stat = "b";
     //   db=dbh.getWritableDatabase();
   // dbh.onCreate(db);

        // = mDbHelper.getWritableDatabase();
    dbc = cursor.getCount();
    stat = "c";
    if(dbc>0) {
        stat = "d";
        cursor.moveToFirst();
        stat = "d2";
        String dus =cursor.getString(6);// dbh.getUserDetails().get("dieregmail");// cursor.getString(cursor.getColumnIndex(FeedReaderContract.LoginEntry.dus));
        stat = "e";
        String dps =cursor.getString(7);// dbh.getUserDetails().get("ddieregpas");// cursor.getString(cursor.getColumnIndex(FeedReaderContract.LoginEntry.dps));
        actUS=dus;
        actPASS=dps;
        actAVA=cursor.getString(4);
        furl = "file:///android_asset/home.html?logedin=" + dus + "&" + dps;
    }//}            stat="43";
}catch (Exception ex){

   // stat=ex.getMessage();
}
     //   }
        //NWB1.setVisibility(View.VISIBLE);

       // Toast.makeText(this,stat+" - "+dbc+" - "+furl + " - "+stat , Toast.LENGTH_LONG).show();
        //wv = (WebView) findViewById(R.id.NWB1);
        //wv.loadUrl("file:///android_asset/appWB.html");   // now it will not fail here

        NWB1 = (WebView) findViewById(R.id.NWB1);
        NWB1.getSettings().setJavaScriptEnabled(true);
        // NWB1.addJavascriptInterface(new WebViewJavaScriptInterface(this), "app");
        NWB1.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            NWB1.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        } else {
            NWB1.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        //NWB1.setWebViewClient(new MyBrowser());
        NWB1.getSettings().setLoadsImagesAutomatically(true);
        NWB1.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        NWB1.getSettings().setAppCacheEnabled(false);
        NWB1.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        //NWB1.getSettings().setJavaScriptEnabled(true);
        NWB1.getSettings().setDomStorageEnabled(true);
        NWB1.getSettings().setUseWideViewPort(true);
        NWB1.setWebChromeClient(new WebChromeClient());
        NWB1.setScrollbarFadingEnabled(true);
        NWB1.clearCache(true);
        NWB1.setVerticalScrollBarEnabled(false);
        NWB1.getSettings().setAllowUniversalAccessFromFileURLs(true);
        //String furl = "http://transport.maxim.shop/KookiKlub/appFa";


        NWB1.setHorizontalScrollBarEnabled(false);

        JSInterface = new JavaScriptInterface(this);
        NWB1.addJavascriptInterface(JSInterface, "JSInterface");

        NWB1.loadUrl(furl);

        NWB1.setWebViewClient(new WebViewClient() {
            @Override
            public void onLoadResource (WebView view, String url){

                ////Toast.makeText(getContext(), "+++ on load res call", Toast.LENGTH_LONG).show();
            }
            public void onPageFinished (WebView view, String url){
                // //Toast.makeText(thisActivity, "is: "+baseScript.length(), Toast.LENGTH_LONG).show();
                super.onPageFinished(view, url);

            }

        });

/*
        final Handler h2 = new Handler();
        h2.postDelayed(new Runnable() {
            private long time = 0;

            @Override
            public void run() {

                final ImageView imageView = (ImageView) findViewById(R.id.imageView);
                Animation myFadeInAnimation = AnimationUtils.loadAnimation(getBaseContext(), R.anim.fadein);
                imageView.startAnimation(myFadeInAnimation); //Set animation to your ImageView

                imageView.animate().scaleX(2).scaleY(2).alpha(0).setDuration(1000);




                final Handler h3 = new Handler();
                h3.postDelayed(new Runnable() {
                    private long time = 0;

                    @Override
                    public void run() {

                        imageView.setVisibility(View.GONE);
                        //showWait();
                        NWB1.setVisibility(View.VISIBLE);

                        //Animation fstshow = AnimationUtils.loadAnimation(getBaseContext(), R.anim.fastshow);
                        //NWB1.startAnimation(fstshow); //Set animation to your ImageView


                    }
                }, 1000);




            }
        }, 3000);
*/

    }

    private void takeScreenshot() {
        Date now = new Date();
        android.text.format.DateFormat.format("yyyy-MM-dd_hh:mm:ss", now);

        try {
            // image naming and path  to include sd card  appending name you choose for file
            String mPath = Environment.getExternalStorageDirectory().toString() + "/nader" + ".jpg";

            // create bitmap screen capture
            View v1 = getWindow().getDecorView().getRootView();
            v1.setDrawingCacheEnabled(true);
            Bitmap bitmap = Bitmap.createBitmap(v1.getDrawingCache());
            v1.setDrawingCacheEnabled(false);

            File imageFile = new File(mPath);

            FileOutputStream outputStream = new FileOutputStream(imageFile);
            int quality = 100;
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream);
            outputStream.flush();
            outputStream.close();

            //Toast.makeText(this,mPath, Toast.LENGTH_LONG).show();

            //openScreenshot(imageFile);
        } catch (Throwable e) {
            // Several error may come out with file handling or DOM
            e.printStackTrace();
        }
    }

    public void  startmic(){

    }
    public void  startavatar(){
        Intent intent = new Intent(this, Main4Activity.class);
        //EditText editText = (EditText) findViewById(R.id.editText);
        String message = "hi";//editText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);

    }
    private void showPictureDialog(){
        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(this);
        pictureDialog.setTitle("Select Action");
        String[] pictureDialogItems = {
                "Select photo from gallery",
                "Capture photo from camera" };
        pictureDialog.setItems(pictureDialogItems,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                choosePhotoFromGallary();
                                break;
                            case 1:
                                takePhotoFromCamera();
                                break;
                        }
                    }
                });
        pictureDialog.show();
    }


    public void choosePhotoFromGallary() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        startActivityForResult(galleryIntent, GALLERY);
    }

    private void takePhotoFromCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, CAMERA);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == this.RESULT_CANCELED) {
            return;
        }
        Toast.makeText(Main3Activity.this, "cod: "+requestCode, Toast.LENGTH_SHORT).show();
        if (requestCode == GALLERY) {
            if (data != null) {
                Uri contentURI = data.getData();
                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), contentURI);
                    //String path = saveImage(bitmap);
                  //  Toast.makeText(Main3Activity.this, "Image Saved: "+path, Toast.LENGTH_SHORT).show();
                    //imageview.setImageBitmap(bitmap);
                    //NWB1.loadUrl("file:///" +
                           // Environment.getExternalStorageDirectory().getPath() +
                            //path);


                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                    byte[] byteArray = byteArrayOutputStream .toByteArray();

                    String encoded = Base64.encodeToString(byteArray, Base64.DEFAULT);

                    Toast.makeText(Main3Activity.this, encoded, Toast.LENGTH_SHORT).show();

                    NWB1.loadUrl("javascript:" + "myavatarnew('"+encoded+"');");


                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(Main3Activity.this, "Failed!", Toast.LENGTH_SHORT).show();
                }
            }

        } else if (requestCode == CAMERA) {
            Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
            //imageview.setImageBitmap(thumbnail);
            String nmg = saveImage(thumbnail);


            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            thumbnail.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
            byte[] byteArray = byteArrayOutputStream .toByteArray();

            String encoded = Base64.encodeToString(byteArray, Base64.DEFAULT);


            NWB1.loadUrl("javascript:" + "myavatarnew('"+encoded+"');");

           // Toast.makeText(Main3Activity.this, encoded, Toast.LENGTH_SHORT).show();
        }
    }

    public String saveImage(Bitmap myBitmap) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        myBitmap.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
        File wallpaperDirectory = new File(
                Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
        // have the object build the directory structure, if needed.
        if (!wallpaperDirectory.exists()) {
            wallpaperDirectory.mkdirs();
        }

        try {
            File f = new File(wallpaperDirectory, Calendar.getInstance()
                    .getTimeInMillis() + ".jpg");
            f.createNewFile();
            FileOutputStream fo = new FileOutputStream(f);
            fo.write(bytes.toByteArray());
            MediaScannerConnection.scanFile(this,
                    new String[]{f.getPath()},
                    new String[]{"image/jpeg"}, null);
            fo.close();
            Log.d("TAG", "File Saved::--->" + f.getAbsolutePath());

            return f.getAbsolutePath();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        return "";
    }

    public void  startavatar2(){
        /*Intent intent = new Intent(this, Main5Activity.class);
        //EditText editText = (EditText) findViewById(R.id.editText);
        String message = "hi";//editText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);*/
        //showPictureDialog();
        takePhotoFromCamera();

    }
    public void startcamera(){

        Intent intent = new Intent(this, MainActivity.class);
        //EditText editText = (EditText) findViewById(R.id.editText);
        String message = "hi";//editText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);

    }

    public void save2db(String ts){
        String offdb="";
        String file = "offdb.js";
        if (true) {

            try {
                InputStream inputStream = openFileInput(file);

                if (inputStream != null) {
                    InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    String receiveString = "";
                    StringBuilder stringBuilder = new StringBuilder();

                    while ((receiveString = bufferedReader.readLine()) != null) {
                        stringBuilder.append(receiveString);
                    }

                    inputStream.close();
                    offdb = stringBuilder.toString();
                }
            } catch (FileNotFoundException e) {
                //Log.e("login activity", "File not found: " + e.toString());
            } catch (IOException e) {
                //Log.e("login activity", "Can not read file: " + e.toString());
            }
        }

        offdb = offdb + ts;
        String filename = file;
        String fileContents = offdb;
        FileOutputStream outputStream;

        try {
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            outputStream.write(fileContents.getBytes());
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        //  Toast.makeText(this,  offdb, Toast.LENGTH_LONG).show();

    }


public void register2(String msg){
        saveToDBPerson(msg);
    //String[] foo = msg.split("#np#");
    //"register2#np#"+
    /*String dieplat=foo[0];
    String dietkn=foo[1];
    String dieavatarsrc=foo[2];
    String dieregfullname=foo[3];
    String dieregmail=foo[4];
    String ddieregpas=foo[5];
    String ddieregrepas=foo[6];
    String diesendnotify=foo[7];
    String diesendmailnot=foo[8];*/
    //DatabaseHandler dbh=new DatabaseHandler(this);
    //int dbc =dbh.getRowCount();
    //dbh.addUser(msg);
/*
    FeedReaderDbHelper mDbHelper = new FeedReaderDbHelper(getContext());
// Gets the data repository in write mode
    SQLiteDatabase db = mDbHelper.getWritableDatabase();

// Create a new map of values, where column names are the keys
    ContentValues values = new ContentValues();
    values.put(FeedReaderContract.PersonEntry.dieplat, foo[0]);
    values.put(FeedReaderContract.PersonEntry.dietkn, foo[1]);
    values.put(FeedReaderContract.PersonEntry.dieavatarsrc, foo[2]);
    values.put(FeedReaderContract.PersonEntry.dieregfullname, foo[3]);
    values.put(FeedReaderContract.PersonEntry.dieregmail, foo[4]);
    values.put(FeedReaderContract.PersonEntry.ddieregpas, foo[5]);
    values.put(FeedReaderContract.PersonEntry.ddieregrepas, foo[6]);
    values.put(FeedReaderContract.PersonEntry.diesendnotify, foo[7]);
    values.put(FeedReaderContract.PersonEntry.diesendmailnot, foo[8]);

    String sortOrder =
            FeedReaderContract.FeedEntry._ID + " DESC";
    db = mDbHelper.getReadableDatabase();
    Cursor cursor = db.query(
            FeedReaderContract.FeedEntry.TABLE_NAME,   // The table to query
            null,             // The array of columns to return (pass null to get all)
            null,              // The columns for the WHERE clause
            null,          // The values for the WHERE clause
            null,                   // don't group the rows
            null,                   // don't filter by row groups
            sortOrder               // The sort order
    );
    List itemIds = new ArrayList<>();
    String titrs="";

    db = mDbHelper.getWritableDatabase();
// Deletes a row given its rowId, but I want to be able to pass
    // in the name of the KEY_NAME and have it delete that row.
    db.delete(FeedReaderContract.FeedEntry.TABLE_NAME, null, null);
*/
  /*  while(cursor.moveToNext()) {
        long itemId = cursor.getLong(
                cursor.getColumnIndexOrThrow(FeedReaderContract.FeedEntry._ID));
        String data = cursor.getString(cursor.getColumnIndex(FeedReaderContract.FeedEntry.COLUMN_NAME_TITLE));

        titrs =titrs+" , "+ data;//+" , ";
        //long itemId = cursor.getS(
        //      cursor.getColumnIndexOrThrow(FeedReaderContract.FeedEntry._ID));

        itemIds.add(itemId);
    }
    cursor.close();*/


// Insert the new row, returning the primary key value of the new row
   // long newRowId = db.insert(FeedReaderContract.PersonEntry.TABLE_NAME, null, values);
    //Toast.makeText(this,newRowId+" created - "+cursor.getCount(), Toast.LENGTH_LONG).show();




}

    public void startlogin2(String msg){
        //dus,dps
        String[] foo = msg.split("#np#");
        //"register2#np#"+
        //String dieplat=foo[0];
        String dus=foo[1];
        String dps=foo[2];
        /*String dieregfullname=foo[3];
        String dieregmail=foo[4];
        String ddieregpas=foo[5];
        String ddieregrepas=foo[6];
        String diesendnotify=foo[7];
        String diesendmailnot=foo[8];
*/
        FeedReaderDbHelper mDbHelper = new FeedReaderDbHelper(getContext());
// Gets the data repository in write mode
        SQLiteDatabase db = mDbHelper.getWritableDatabase();

// Create a new map of values, where column names are the keys
        ContentValues values = new ContentValues();
        values.put(FeedReaderContract.LoginEntry.dus, foo[1]);
        values.put(FeedReaderContract.LoginEntry.dps, foo[2]);

        String sortOrder =
                FeedReaderContract.FeedEntry._ID + " DESC";
        db = mDbHelper.getReadableDatabase();
        Cursor cursor = db.query(
                FeedReaderContract.LoginEntry.TABLE_NAME,   // The table to query
                null,             // The array of columns to return (pass null to get all)
                null,              // The columns for the WHERE clause
                null,          // The values for the WHERE clause
                null,                   // don't group the rows
                null,                   // don't filter by row groups
                sortOrder               // The sort order
        );
        List itemIds = new ArrayList<>();
        String titrs="";

        db = mDbHelper.getWritableDatabase();
// Deletes a row given its rowId, but I want to be able to pass
        // in the name of the KEY_NAME and have it delete that row.
        db.delete(FeedReaderContract.FeedEntry.TABLE_NAME, null, null);

  /*  while(cursor.moveToNext()) {
        long itemId = cursor.getLong(
                cursor.getColumnIndexOrThrow(FeedReaderContract.FeedEntry._ID));
        String data = cursor.getString(cursor.getColumnIndex(FeedReaderContract.FeedEntry.COLUMN_NAME_TITLE));

        titrs =titrs+" , "+ data;//+" , ";
        //long itemId = cursor.getS(
        //      cursor.getColumnIndexOrThrow(FeedReaderContract.FeedEntry._ID));

        itemIds.add(itemId);
    }
    cursor.close();*/


// Insert the new row, returning the primary key value of the new row
        long newRowId = db.insert(FeedReaderContract.PersonEntry.TABLE_NAME, null, values);
        Toast.makeText(this,newRowId+" login - "+cursor.getCount(), Toast.LENGTH_LONG).show();




    }

    public void manageWBcommands(String msg) {

        Toast.makeText(this,msg, Toast.LENGTH_LONG).show();


        String[] foo = msg.split("#np#");
        String cmd = foo[0];
        String param = "";
        try {
            param = foo[1];
        } catch (Exception ex) {
            param = "";
        }

        if (cmd.trim().equals("register2")){
            register2(msg);
        }

        if (cmd.trim().equals("startavatar2")) {
            startavatar2();
        }
        if (cmd.trim().equals("startavatar")) {
            startavatar();
        }

        if (cmd.trim().equals("savestat")) {
          //  takeScreenshot();
        }
        if (cmd.trim().equals("startcamera")) {
            startcamera();
        }
        if (cmd.trim().equals("startmic")) {
            startmic();
        }

        if (cmd.trim().equals("doalert")) {

            String prm1 = foo[1];

            Toast.makeText(this,prm1, Toast.LENGTH_LONG).show();

        }

        if (cmd.trim().equals("savelogin")){
            String dus = foo[1];
            String dps = foo[2];
            save2db("diesaveduser='" + dus + "';diesavedpass='" + dps + "';");
            startlogin2(msg);
        }

    }

    public class WebViewJavaScriptInterface {

        private Context context;

        /*
         * Need a reference to the context in order to sent a post message
         */
        public WebViewJavaScriptInterface(Context context) {
            this.context = context;
        }

        /*
         * This method can be called from Android. @JavascriptInterface
         * required after SDK version 17.
         */
        @JavascriptInterface
        public void makeToast(String message, boolean lengthLong) {

            //((PagerActivity)getActivity()).manageWBcommands(message);
            // manageWBcommands(message);

        }
    }
    private class MyBrowser extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }


        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            view.clearCache(true);

            //hideWait();

            /*
            //Toast.makeText(context, message, Toast.LENGTH_LONG).show();
            //wv1.loadUrl("javascript:var msg=window.location.href;app.makeToast(msg, '123');");
            NWB1.loadUrl("javascript:var msg='urlLoaded#np#'+window.location.href;app.makeToast(msg, '123');");

            //--------------------- hack1 ---------------
            String jqCmd = "jQuery('input[type=text]').click(function(){app.makeToast('hideWait', '123');});";
            jqCmd = jqCmd + "jQuery('#doCancel').click(function(){app.makeToast('showWait', '123');});";
            jqCmd = jqCmd + "jQuery('#doPay').click(function(){app.makeToast('showWait', '123');});";
            jqCmd = "if(jQuery('#doPay').length>0){" + jqCmd + "};";
            NWB1.loadUrl("javascript:" + jqCmd);
            //--------------------------------------------
*/

        }
    }

    public class JavaScriptInterface {
        Context mContext;

        /** Instantiate the interface and set the context */
        JavaScriptInterface(Context c) {
            mContext = c;
        }

        @JavascriptInterface
        public void changeActivity(String m)
        {
            manageWBcommands(m);
            //Intent i = new Intent(JavascriptInterfaceActivity.this, nextActivity.class);
            //startActivity(i);
            //finish();
        }
    }

    public static class FeedEntry implements BaseColumns {
        public static final String TABLE_NAME = "nader";
        public static final String COLUMN_NAME_TITLE = "title";
        public static final String COLUMN_NAME_SUBTITLE = "subtitle";
    }

    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + FeedReaderContract.FeedEntry.TABLE_NAME + " (" +
                    FeedReaderContract.FeedEntry._ID + " INTEGER PRIMARY KEY," +
                    FeedReaderContract.FeedEntry.COLUMN_NAME_TITLE + " TEXT," +
                    FeedReaderContract.FeedEntry.COLUMN_NAME_SUBTITLE + " TEXT)";

    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + FeedReaderContract.FeedEntry.TABLE_NAME;

    public class FeedReaderDbHelper extends SQLiteOpenHelper {
        // If you change the database schema, you must increment the database version.
        public static final int DATABASE_VERSION = 1;
        public static final String DATABASE_NAME = "FeedReader.db";

        public FeedReaderDbHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(SQL_CREATE_ENTRIES);
        }
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // This database is only a cache for online data, so its upgrade policy is
            // to simply to discard the data and start over
            db.execSQL(SQL_DELETE_ENTRIES);
            onCreate(db);
        }
        public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            onUpgrade(db, oldVersion, newVersion);
        }
    }

    public void aa(){

    }
    public void workwitdb(){
        FeedReaderDbHelper mDbHelper = new FeedReaderDbHelper(getContext());
// Gets the data repository in write mode
        SQLiteDatabase db = mDbHelper.getWritableDatabase();

// Create a new map of values, where column names are the keys
        ContentValues values = new ContentValues();
        values.put(FeedReaderContract.FeedEntry.COLUMN_NAME_TITLE, "key1");
        values.put(FeedReaderContract.FeedEntry.COLUMN_NAME_SUBTITLE, "key2");

// Insert the new row, returning the primary key value of the new row
        long newRowId = db.insert(FeedReaderContract.FeedEntry.TABLE_NAME, null, values);
        //Toast.makeText(this,newRowId+" created", Toast.LENGTH_LONG).show();

         db = mDbHelper.getReadableDatabase();

// Define a projection that specifies which columns from the database
// you will actually use after this query.
        String[] projection = {
                BaseColumns._ID,
                FeedReaderContract.FeedEntry.COLUMN_NAME_TITLE,
                FeedReaderContract.FeedEntry.COLUMN_NAME_SUBTITLE
        };

// Filter results WHERE "title" = 'My Title'
        String selection = FeedReaderContract.FeedEntry.COLUMN_NAME_TITLE + " = ?";
        String[] selectionArgs = { "My Title" };

// How you want the results sorted in the resulting Cursor
        String sortOrder =
                FeedReaderContract.FeedEntry.COLUMN_NAME_SUBTITLE + " DESC";

        Cursor cursor = db.query(
                FeedReaderContract.FeedEntry.TABLE_NAME,   // The table to query
                null,             // The array of columns to return (pass null to get all)
                null,              // The columns for the WHERE clause
                null,          // The values for the WHERE clause
                null,                   // don't group the rows
                null,                   // don't filter by row groups
                sortOrder               // The sort order
        );
        List itemIds = new ArrayList<>();
        String titrs="";


       // Cursor  cursor2 = db.rawQuery("select * from "+FeedReaderContract.FeedEntry.TABLE_NAME,null);


        while(cursor.moveToNext()) {
            long itemId = cursor.getLong(
                    cursor.getColumnIndexOrThrow(FeedReaderContract.FeedEntry._ID));
            String data = cursor.getString(cursor.getColumnIndex(FeedReaderContract.FeedEntry.COLUMN_NAME_TITLE));

            titrs =titrs+" , "+ data;//+" , ";
            //long itemId = cursor.getS(
              //      cursor.getColumnIndexOrThrow(FeedReaderContract.FeedEntry._ID));

            itemIds.add(itemId);
        }
        cursor.close();
        Toast.makeText(this,newRowId+" - "+titrs, Toast.LENGTH_LONG).show();
    }

    private Context getContext() {

        return  getBaseContext();
    }


}
