package com.ipozal.otus.Transformations;

import android.support.v4.view.ViewPager;
import android.view.View;

public class SimpleTransformation implements ViewPager.PageTransformer {
    @Override
    public void transformPage(View page, float position) {

    }
}