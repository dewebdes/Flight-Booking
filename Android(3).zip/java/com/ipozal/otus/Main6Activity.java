package com.ipozal.otus;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;

public class Main6Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
    }
    private WebView NWB1;
    private WebView NWB2;

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onStart() {
        super.onStart();

        NWB1 = (WebView) findViewById(R.id.NWB1);
        NWB1.getSettings().setJavaScriptEnabled(true);
        NWB1.addJavascriptInterface(new Main6Activity.WebViewJavaScriptInterface(this), "app");
        NWB1.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            NWB1.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        } else {
            NWB1.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        NWB1.setWebViewClient(new Main6Activity.MyBrowser());
        NWB1.getSettings().setLoadsImagesAutomatically(true);
        NWB1.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        NWB1.getSettings().setAppCacheEnabled(false);
        NWB1.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        NWB1.getSettings().setJavaScriptEnabled(true);
        NWB1.getSettings().setDomStorageEnabled(true);
        NWB1.getSettings().setUseWideViewPort(true);
        NWB1.setWebChromeClient(new WebChromeClient());
        NWB1.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Toast.makeText(getBaseContext(), consoleMessage.message(),Toast.LENGTH_LONG).show();
                return super.onConsoleMessage(consoleMessage);
            }
        });
        NWB1.setScrollbarFadingEnabled(true);
        NWB1.clearCache(true);
        NWB1.setVerticalScrollBarEnabled(false);
        NWB1.getSettings().setAllowUniversalAccessFromFileURLs(true);
        NWB1.loadUrl("https://www.fly.de/");


        //--------------------
        String furl = "file:///android_asset/home3.html";
        NWB2 = (WebView) findViewById(R.id.NWB2);
        NWB2.getSettings().setJavaScriptEnabled(true);
        NWB2.addJavascriptInterface(new Main6Activity.WebViewJavaScriptInterface(this), "app");
        NWB2.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            NWB2.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        } else {
            NWB2.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        NWB2.setWebViewClient(new Main6Activity.MyBrowser());
        NWB2.getSettings().setLoadsImagesAutomatically(true);
        NWB2.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        NWB2.getSettings().setAppCacheEnabled(false);
        NWB2.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        NWB2.getSettings().setJavaScriptEnabled(true);
        NWB2.getSettings().setDomStorageEnabled(true);
        NWB2.getSettings().setUseWideViewPort(true);
        NWB2.setWebChromeClient(new WebChromeClient());
        NWB2.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Toast.makeText(getBaseContext(), consoleMessage.message(),Toast.LENGTH_LONG).show();
                return super.onConsoleMessage(consoleMessage);
            }
        });
        NWB2.setScrollbarFadingEnabled(true);
        NWB2.clearCache(true);
        NWB2.setVerticalScrollBarEnabled(false);
        NWB2.getSettings().setAllowUniversalAccessFromFileURLs(true);
        NWB2.loadUrl(furl);


       /* Button clickButton = (Button) findViewById(R.id.button);
        clickButton.setOnClickListener( new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub

                //NWB1.loadUrl("javascript:"+"var tbnum=document.getElementsByTagName('input');var mytb;for(var i=0;i<=tbnum.length-1;i++){if('google'==tbnum[i].value){mytb=tbnum[i];};};mytb.value='Delta.ir'; app.makeToast(mytb.value, '123');");
                // NWB1.loadUrl("javascript:"+"document.getElementById('lst-ib').value = 'Some random text';");

                startSearchFor("خرید ملک در تهران");

            }
        });
*/


    }

    public String dieFlag="ns";
    public String dieFlag2="ns";
    public String dieDM="delta.ir";//"ihome.ir";
    public void startSearchFor(String ts){

        NWB1.loadUrl("javascript:"+"var buttonCol=document.getElementsByTagName('form');var mybutton=buttonCol[0];var myint1;function kliksearch(){mybutton.submit();clearInterval(myint1);app.makeToast('setFlag2Start', '123');};var myklikers='';for(var i=0;i<=buttonCol.length-1;i++){};");
        NWB1.loadUrl("javascript:"+"var mytx='"+ts+"';");
        NWB1.loadUrl("javascript:"+"var tbnum=document.getElementsByTagName('input');var mytb;var myint0;function changesearch(){mytb.value=mytx;clearInterval(myint0);myint1=setInterval(kliksearch,7000);};for(var i=0;i<=tbnum.length-1;i++){if('google'==tbnum[i].value){mytb=tbnum[i];myint0=setInterval(changesearch,7000);};};");


    }
    public void search4DM(){

        NWB1.loadUrl("javascript:function getNextPage(){clearInterval(window.intx3);var pageCols=document.getElementsByTagName('a');for(var i=0;i<=pageCols.length-1;i++){if(pageCols[i].innerHTML.indexOf('More results')>-1){var nextpg=pageCols[i];nextpg.click();break;}}};");
        NWB1.loadUrl("javascript:"+"var citeCol=document.getElementsByTagName('a');var mycite=0;var myint2;function klikcite(){mycite.click();clearInterval(myint2);app.makeToast('setFlag2Visited', '123');};for(var i=0;i<=citeCol.length-1;i++){if(citeCol[i].href.indexOf('"+dieDM+"')>-1){mycite=citeCol[i];myint2=setInterval(klikcite,7000);break;}};if(mycite==0){window.intx3=setInterval(getNextPage,7000);app.makeToast('setFlag2NextPage', '123');}");

    }
    public void search4DM2(){

        //  NWB1.loadUrl("javascript:function getNextPage(){clearInterval(window.intx3);var pageCols=document.getElementsByTagName('a');for(var i=0;i<=pageCols.length-1;i++){if(pageCols[i].innerHTML.indexOf('More results')>-1){var nextpg=pageCols[i];nextpg.click();break;}}};");
        //NWB1.loadUrl("javascript:"+"var citeCol=document.getElementsByTagName('a');var mycite=0;var myint2;function klikcite(){mycite.click();clearInterval(myint2);app.makeToast('setFlag2Visited', '123');};for(var i=0;i<=citeCol.length-1;i++){if(citeCol[i].href.indexOf('"+dieDM+"')>-1){mycite=citeCol[i];myint2=setInterval(klikcite,7000);break;}};if(mycite==0){window.intx3=setInterval(getNextPage,7000);app.makeToast('setFlag2NextPage', '123');}");

        NWB1.loadUrl("javascript:function getNextPage2(){alert(123);}getNextPage2();");
    }

    public void onclick(View vw){
        NWB1.post(new Runnable() {
            @Override
            public void run() {
                EditText cmdx   = (EditText)findViewById(R.id.editText);
                NWB1.loadUrl("javascript:"+cmdx.getText());
                NWB1.bringToFront();
            }
        });
    }

    public class WebViewJavaScriptInterface {

        private Context context;
        public WebViewJavaScriptInterface(Context context) {
            this.context = context;
        }
        @JavascriptInterface
        public void makeToast(String message, boolean lengthLong) {


            String[] words = message.split("nnpp");

            String cmd = words[0];

            Toast.makeText(getBaseContext(), message,Toast.LENGTH_LONG).show();
            //NWB1.bringToFront();

            if(cmd.equals("go2search")){
                NWB1.post(new Runnable() {
                    @Override
                    public void run() {
                        NWB1.loadUrl("javascript:function go2search(){document.getElementById('link_suchen').click();}go2search();");
                        //NWB1.bringToFront();
                    }
                });
            }

            if(cmd.equals("readsearch")){
                String jscmd = "javascript:function readsearch(){";
                jscmd += "var dret='';var Bundesland = document.getElementsByName('bundesLand')[0].getElementsByTagName('option');";
                jscmd += "for(var i=0;i<=Bundesland.length-1;i++){";
                jscmd += "dret+=Bundesland[i].innerText+'nnpp';";
                jscmd += "};app.makeToast('readsearchxnnpp'+dret, '123');";
                jscmd += "};readsearch();";

                //NWB1.loadUrl(jscmd);
                final String finalJscmd = jscmd;
                NWB1.post(new Runnable() {
                    @Override
                    public void run() {
                        NWB1.loadUrl(finalJscmd);
                        //NWB1.bringToFront();
                    }
                });


            }
            if(cmd.equals("readsearchx")){

                final String finalJscmd = message;
                NWB2.post(new Runnable() {
                    @Override
                    public void run() {
                        NWB2.loadUrl("javascript:injectsearch('"+finalJscmd+"');");
                        //NWB1.bringToFront();
                    }
                });
                Toast.makeText(getBaseContext(), message,Toast.LENGTH_LONG).show();

            }

            //-------------

            if(cmd.equals("readGericht")){
                String jscmd = "javascript:function readsearch(){";
                jscmd += "var dret='';var behoerde = document.getElementsByName('behoerde')[0].getElementsByTagName('option');";
                jscmd += "for(var i=0;i<=behoerde.length-1;i++){";
                jscmd += "dret+=behoerde[i].innerText+'nnpp';";
                jscmd += "};app.makeToast('readGerichtxnnpp'+dret, '123');";
                jscmd += "};readsearch();";

                //NWB1.loadUrl(jscmd);
                final String finalJscmd = jscmd;
                NWB1.post(new Runnable() {
                    @Override
                    public void run() {
                        NWB1.loadUrl(finalJscmd);
                        //NWB1.bringToFront();
                    }
                });


            }
            if(cmd.equals("readGerichtx")){

                final String finalJscmd = message;
                NWB2.post(new Runnable() {
                    @Override
                    public void run() {
                        NWB2.loadUrl("javascript:injectGericht('"+finalJscmd+"');");
                        //NWB1.bringToFront();
                    }
                });
                Toast.makeText(getBaseContext(), message,Toast.LENGTH_LONG).show();

            }

            //-------------

            if(cmd.equals("setstate")){
                String jscmd = "javascript:function setdstat(stt){";
                jscmd += "var behoerde = document.getElementsByName('bundesLand')[0].getElementsByTagName('option');";
                jscmd += "for(var i=0;i<=behoerde.length-1;i++){";
                jscmd += "if(behoerde[i].innerText == stt){behoerde[i].setAttribute('selected','selected');}";
                jscmd += "};behoerdeZuBundesland();";
                jscmd += "};setdstat('"+words[1]+"');";
//app.makeToast('readGerichtxnnpp'+dret, '123');
                //NWB1.loadUrl(jscmd);
                final String finalJscmd = jscmd;
                NWB1.post(new Runnable() {
                    @Override
                    public void run() {
                        NWB1.loadUrl(finalJscmd);
                        // NWB1.bringToFront();
                    }
                });


            }

            //--------------


            if(cmd.equals("readsearchresult")){

            }


            if(cmd.equals("testalert")){
                Toast.makeText(getBaseContext(), "A:: "+words[1], Toast.LENGTH_LONG).show();


                NWB2.post(new Runnable() {
                    @Override
                    public void run() {
                        NWB2.loadUrl("javascript:function getNextPage2(){app.makeToast('testalert2nnpp222', '123');}getNextPage2();");
                    }
                });




            }

            if(cmd.equals("testalert2")) {
                Toast.makeText(getBaseContext(), "bb:: " + words[1], Toast.LENGTH_LONG).show();
            }

            //fillsearch
            if(cmd.equals("fillsearch")){
                String nachname = words[1];
                String vorname = words[2];
                String sprache1 = words[3];
                String sprache2 = words[4];
                String sprache3 = words[5];
                String dGerichtsel = words[6];

                String jscmd = "javascript:function fillsearch(){";

                jscmd += "var stt="+dGerichtsel+"';var behoerde = document.getElementsByName('behoerde')[0].getElementsByTagName('option');";
                jscmd += "for(var i=0;i<=behoerde.length-1;i++){";
                jscmd += "if(behoerde[i].innerText == stt){behoerde[i].setAttribute('selected','selected');}};";

                jscmd += "document.getElementsByName('nachname')[0].value = "+nachname+";";
                jscmd += "document.getElementsByName('vorname')[0].value = "+vorname+";";

                jscmd += "document.getElementById('sprache1').value = "+sprache1+";";
                jscmd += "document.getElementById('sprache2').value = "+sprache2+";";
                jscmd += "document.getElementById('sprache3').value = "+sprache3+";";

                jscmd += "document.getElementById('suchSubmit').click();";
                //jscmd += "};behoerdeZuBundesland();";
                jscmd += "};fillsearch();";
//app.makeToast('readGerichtxnnpp'+dret, '123');
                //NWB1.loadUrl(jscmd);



                jscmd = "javascript:var nachname = '"+nachname+"';" +
                        "var vorname = '"+vorname+"';" +
                        "var sprache1 = '"+sprache1+"';" +
                        "var sprache2 = '"+sprache2+"';" +
                        "var sprache3 = '"+sprache3+"';" +
                        "var dGerichtsel = '';" +
                        "var Dolmetscherin = 'checked';" +
                        "var Übersetzerin = '';" +
                        "var Beeidigung = '';" +
                        "function fillsearch(){" +
                        "var stt=dGerichtsel;var behoerde = document.getElementsByName('behoerde')[0].getElementsByTagName('option');" +
                        "for(var i=0;i<=behoerde.length-1;i++){" +
                        "if(behoerde[i].innerText == stt){behoerde[i].setAttribute('selected','selected');}}" +
                        "document.getElementsByName('nachname')[0].value = nachname;" +
                        "document.getElementsByName('vorname')[0].value = vorname;" +
                        "document.getElementsByName('taetigAlsDolmetscher')[0].checked = Dolmetscherin;" +
                        "document.getElementsByName('taetigAlsUebersetzer')[0].checked = Übersetzerin;" +
                        "document.getElementsByName('beeidigungErmaechtigungBestellung')[0].checked = Beeidigung;" +
                        "document.getElementById('sprache1').value = sprache1;" +
                        "document.getElementById('sprache2').value = sprache2;" +
                        "document.getElementById('sprache3').value = sprache3;" +
                        "document.getElementById('suchSubmit').click();" +
                        "};fillsearch();";


                final String finalJscmd = jscmd;
                NWB1.post(new Runnable() {
                    @Override
                    public void run() {
                        NWB1.loadUrl(finalJscmd);
                        NWB1.bringToFront();
                    }
                });


            }

            if(cmd.equals("setpgcont")){
                String jscmd = "javascript:function setpgcont(){";
                jscmd += "var thref = 'suche_action?action_eintraege=1000';var acols=document.getElementsByTagName('a');";
                jscmd += "for(var i=acols.length-1;i>=0;i--){";
                jscmd += "if(acols[i].href.indexOf(thref)>-1){acols[i].click();break;}";
                jscmd += "};";
                jscmd += "};setpgcont();";
                final String finalJscmd = jscmd;
                NWB1.post(new Runnable() {
                    @Override
                    public void run() {
                        NWB1.loadUrl(finalJscmd);
                        //NWB1.bringToFront();
                    }
                });
            }
            //--------
            if(cmd.equals("injectcontinfo")){
                String jscmd = "javascript:injectcontinfo("+words[1]+");";
                final String finalJscmd = jscmd;
                NWB2.post(new Runnable() {
                    @Override
                    public void run() {
                        NWB2.loadUrl("");
                    }
                });
            }
            if(cmd.equals("getcontinfo")){
                String jscmd = "javascript:function getcontinfo(){";
                jscmd += "var cct = document.getElementById('table1').children[0].children[2].innerText.split(':')[1].split('(')[0].trim();";
                jscmd += "app.makeToast('injectcontinfonnpp'+cct, '123');";
                jscmd += "};getcontinfo();";
//app.makeToast('readGerichtxnnpp'+dret, '123');
                //NWB1.loadUrl(jscmd);
                final String finalJscmd = jscmd;
                NWB1.post(new Runnable() {
                    @Override
                    public void run() {
                        NWB1.loadUrl(finalJscmd);
                        // NWB1.bringToFront();
                    }
                });


            }
            //showvv1
            if(cmd.equals("showvv1")){
                NWB1.bringToFront();

            }
            //--------
            if(cmd.equals("injectcreslist")){
                String jscmd = "javascript:injectreslist("+words[1]+");";
                final String finalJscmd = jscmd;
                NWB2.post(new Runnable() {
                    @Override
                    public void run() {
                        NWB2.loadUrl(finalJscmd);
                    }
                });
            }
            //injectcreslist
            if(cmd.equals("radandgo")){
                String jscmd = "javascript:function radandgo(){";
                jscmd += "var dout = '';var dtbl = document.getElementById('table1').getElementsByTagName('table')[2].getElementsByTagName('tr');";
                jscmd += "for(var i=1;i<=dtbl.length-1;i++){";
                jscmd += "var tds = dtbl[i].getElementsByTagName('td')";
                jscmd += "dout+=tds[0]+'nntt'+tds[1]+'nntt'+tds[2]+'nntt'+tds[3]+'nntt'+tds[4]+'nntt'+tds[5]+'nndd';";
                jscmd += "app.makeToast('injectcreslistnnpp'+dout, '123');";
                jscmd += "document.getElementById('seite').parentNode.getElementsByTagName('a')[0].click();";
                //suche_action?action_seite=2


                jscmd += "};radandgo();";
//app.makeToast('readGerichtxnnpp'+dret, '123');
                //NWB1.loadUrl(jscmd);
                final String finalJscmd = jscmd;
                NWB1.post(new Runnable() {
                    @Override
                    public void run() {
                        NWB1.loadUrl(finalJscmd);
                        // NWB1.bringToFront();
                    }
                });


            }
            //---------------------
            //https://fluege.fly.de/suggester?st=os&aid=flyde&lang=de_DE&phrase=bar
//app.makeToast('showvv1', '123');
            //injectadjust
            if(cmd.equals("injectadjust")){
                String jscmd = "javascript:function injectadjust(){";
                jscmd += "var dinpt = '"+words[1]+"';'";//var dtbl = document.getElementById('table1').getElementsByTagName('table')[2].getElementsByTagName('tr');";


                jscmd += "citydb = JSON.parse(dinpt);$('#vonsel').empty();";

                jscmd += "for(var i=0;i<=citydb.length-1;i++){";
                jscmd += "$('#vonsel').append($('<option>'+citydb[i].id+' - '+citydb[i].label+'</option>'));";
                //jscmd += "app.makeToast('injectadjustnnpp'+(xhr.response), '123');";
                jscmd += "}";
                //jscmd += "}";

                //jscmd += "xhr.open('GET', 'https://www.fly.de/typo3conf/ext/provider/Resources/Public/Php/suggest.php?locales=de_DE&getGeoByLetter=1&railsearch=N&term='+dinpt, true);";
                //jscmd += "xhr.send('');";


                jscmd += "};injectadjust();";
//app.makeToast('readGerichtxnnpp'+dret, '123');
                //NWB1.loadUrl(jscmd);
                final String finalJscmd = jscmd;
                NWB2.post(new Runnable() {
                    @Override
                    public void run() {
                        NWB2.loadUrl(finalJscmd);
                        // NWB1.bringToFront();citydb = JSON.parse(db);
                    }
                });
            }
            if(cmd.equals("searchvon")){
                Toast.makeText(getBaseContext(), words[1],Toast.LENGTH_LONG).show();
                String jscmd = "javascript:function getadjast(){";
                jscmd += "var dinpt = '"+words[1]+"';";//var dtbl = document.getElementById('table1').getElementsByTagName('table')[2].getElementsByTagName('tr');";


                jscmd += "var xhr = new XMLHttpRequest();";

                jscmd += "xhr.onreadystatechange = function() {";
                jscmd += "if (xhr.readyState === 4) {";
                //jscmd += "app.makeToast('injectadjustnnpp'+(xhr.response), '123');";
                jscmd += "console.log('injectadjustnnpp'+(xhr.response));";
                jscmd += "}";
                jscmd += "}";

                jscmd += "xhr.open('GET', 'https://www.fly.de/typo3conf/ext/provider/Resources/Public/Php/suggest.php?locales=de_DE&getGeoByLetter=1&railsearch=N&term='+dinpt, true);";
                jscmd += "xhr.send('');";


                jscmd += "};getadjast();";
//app.makeToast('readGerichtxnnpp'+dret, '123');
                //NWB1.loadUrl(jscmd);
                final String finalJscmd = jscmd;
                NWB1.post(new Runnable() {
                    @Override
                    public void run() {
                        NWB1.loadUrl(finalJscmd);
                        // NWB1.bringToFront();
                    }
                });
            }
            //----------------------
            //link_suchen


            if(message.equals("setFlag2Start")){
                dieFlag="searchstarted";
            }
            if(message.equals("setFlag2Visited")){
                dieFlag="searchfinished";
            }
        }
    }

    private class MyBrowser extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            view.clearCache(true);

            if(dieFlag.equals("searchstarted")){
                // search4DM();
            }

        }
    }


}
