package com.ipozal.otus;

import android.provider.BaseColumns;

public final class FeedReaderContract {
    // To prevent someone from accidentally instantiating the contract class,
    // make the constructor private.
    private FeedReaderContract() {}

    /* Inner class that defines the table contents */
    public static class FeedEntry implements BaseColumns {
        public static final String TABLE_NAME = "nader";
        public static final String COLUMN_NAME_TITLE = "title";
        public static final String COLUMN_NAME_SUBTITLE = "subtitle";
    }
    public static class PersonEntry implements BaseColumns {
        public static final String TABLE_NAME = "naderPERSON";
        public static final String COLUMN_NAME_TITLE = "title";
        public static final String COLUMN_NAME_SUBTITLE = "subtitle";
        public static final String dieplat="dieplat";//foo[0];
        public static final String dietkn="dietkn";//foo[1];
        public static final String dieavatarsrc="dieavatarsrc";//foo[2];
        public static final String dieregfullname="dieregfullname";//foo[3];
        public static final String dieregmail="dieregmail";//foo[4];
        public static final String ddieregpas="ddieregpas";//foo[5];
        public static final String ddieregrepas="ddieregrepas";//foo[6];
        public static final String diesendnotify="diesendnotify";//foo[7];
        public static final String diesendmailnot="diesendmailnot";//foo[8];
    }
    public static class LoginEntry implements BaseColumns {
        public static final String TABLE_NAME = "naderLOGIN";
        public static final String dus="dus";//foo[0];
        public static final String dps="dps";//foo[1];

    }



}