import Vue from 'vue'
import './plugins/vuetify'
import App from './App.vue'
import router from './router'

import Toaster from 'v-toaster'
import 'v-toaster/dist/v-toaster.css'
Vue.use(Toaster, {timeout: 5000})


Vue.config.productionTip = false




Vue.prototype.$hostname = 'http://apochi.ipozal.com/api/';
Vue.prototype.$hostwebname = 'http://apochi.ipozal.com/';
Vue.prototype.$thisAppAddress = 'http://176.9.28.86:8080';
Vue.prototype.$tookenaccess='eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6ImE5N2I5ZWM3MjNkZjViNzU5NTJjMDgwMzQxMTQxZWVkNDAyNjJjNGE2MjM5NTRjOWRiYzFlMTgyMTlhZDM2YmYyNjk4OTM3ZDNiN2U5ZTQ5In0.eyJhdWQiOiI0IiwianRpIjoiYTk3YjllYzcyM2RmNWI3NTk1MmMwODAzNDExNDFlZWQ0MDI2MmM0YTYyMzk1NGM5ZGJjMWUxODIxOWFkMzZiZjI2OTg5MzdkM2I3ZTllNDkiLCJpYXQiOjE1NTY0NTkyNDcsIm5iZiI6MTU1NjQ1OTI0NywiZXhwIjoxNTg4MDgxNjQ3LCJzdWIiOiIxIiwic2NvcGVzIjpbXX0.g6lqnw0mIyMFvRMkPM5tkFrPTtOxUZ90lPTE6DJSpBnnIdhAdupHbQw-4Fw-so1tOeNH37BFftYQPo0Ii9V3MvrUmtM5o2pF5XUY1qFGWyijMRdFhSwpFPAzJbk8zFruU3uIzbZ6AJFQ9GBQYyihawynu5_4aPQnJ_pOjCsxGX0xR0nV2CfUiGKcoup1YUraoLsOUrGL1GEs369h6wgsVvccibmGazAHShzwNQlkoS9sby4XjSgml2G5nyCV46WWWEmgwqJn6lugbroy5pekrQyhC9UyAeTmX-q6mDxn6TxmifxFoZC7Gr3LLufFLIxbUfC3_Wy-whHqnQd8AtoF_DKl7mqkLUZLnVTk7CRsWUjIVC19_vX2uy-LhuNi2wpAZo550XYR93N8BF_JPjzu-I65yiyxG5tvcF4G6G_Hdk4ELgY4xvVgwWHnYP4Heu8IYeUiKoUh_YPjE4xxWiDQyjJNV90eguwjSNVjWSoUVmttv98pKPXRkpiEVsLyapj91xe-5Cq3CZNyCKrFbvkA3A-iChyQ39pSgZPvfzRQDk40-yn7nVvzdG_8i7_dxjnDkuzHjSuPYz78aRhLjxMFZWU-_FB3X0PrYBZEZ5bxPr9Ejoh__oPGSeANXlOShw5pRgY51GttrE17GjtTCq1lkhiAOT29K2Z2n_JBP1pT5gU';
console.log('this is our new token', Vue.prototype.$tookenaccess);





new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
