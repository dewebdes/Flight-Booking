<template>
    <div>
        <div id="SearchP">



            <SearchHeader></SearchHeader>



        </div>
    </div>
</template>

<script>


    import SearchHeader from '@/components/Search/SearchHeader'

    export default {
        name:'Search',
        components:{
            SearchHeader
        },
        mounted(){

        },
        data(){
            return{

            }
        },
        methods:{

        }
    }
</script>
