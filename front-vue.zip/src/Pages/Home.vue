<template>
    <div>
        <div id="Homepage">


            <HomeHeader></HomeHeader>



        </div>
    </div>
</template>

<script>


    import HomeHeader from '@/components/Home/HomeHeader'

    export default {
        name:'Home',
        components:{
            HomeHeader
        },
        mounted(){

        },
        data(){
            return{

            }
        },
        methods:{

        }
    }
</script>
