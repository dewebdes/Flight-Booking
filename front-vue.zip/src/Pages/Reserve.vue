<template>
    <div>
        <div id="Reservep">


            <ReserveHeader></ReserveHeader>



        </div>
    </div>
</template>

<script>


    import ReserveHeader from '@/components/Reserve/ReserveHead'

    export default {
        name:'Reserve',
        components:{
            ReserveHeader
        },
        mounted(){

        },
        data(){
            return{

            }
        },
        methods:{

        }
    }
</script>
