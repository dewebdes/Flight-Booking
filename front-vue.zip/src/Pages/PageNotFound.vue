<template>
    <div>

        <div class="md-layout-item md-gutter notfound">
            Page Not Found 404
            <img src="https://www.gstatic.com/flights/app/error_white_1080.png" alt="">

        </div>
    </div>
</template>
<style>
    .notfound img{
        margin: 0 auto;
        display: block;
        max-width: 100%;
        text-align: center;
        font-size: 40px;
        color: #3cafd0;
    }
    .notfound{
        padding-top: 50px;
        text-align: center;
        font-size: 40px;
        color: #3cafd0;
    }
</style>