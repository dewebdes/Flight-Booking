<template>
    <div>
        <div id="bookingP">


            <BookingHeader></BookingHeader>



        </div>
    </div>
</template>

<script>


    import BookingHeader from '@/components/Booking/BookingHeader'

    export default {
        name:'Booking',
        components:{
            BookingHeader
        },
        mounted(){

        },
        data(){
            return{

            }
        },
        methods:{

        }
    }
</script>
