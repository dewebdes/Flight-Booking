import Vue from 'vue'
import Router from 'vue-router'
import Home from './Pages/Home.vue'
import Search from './Pages/Search.vue'
import Reserve from './Pages/Reserve.vue'
import Booking from './Pages/Booking.vue'
import PageNotFound from './Pages/PageNotFound.vue'


Vue.use(Router)

export default new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
      {
          path: '/',
          name: 'home',
          component: Home
      },
      {
          path: '/search/:travel/',
          name: 'Search',
          component: Search
      },
      {
          path: '/reserve/:id/',
          name: 'Reserve',
          component: Reserve
      },
      {
          path: '/booking/:id/',
          name: 'Booking',
          component: Booking
      },
      {
          path: "*",
          name: 'PageNotFound',
          component: PageNotFound
      }

  ]
})
