<template>
    <v-layout>
        <v-flex xs12 id="seprbox">
            <v-card dark color="#00355f" style="margin-top: 35px; min-height: 180px;" class="pa-4">

                <!-- Drop Down Section -->
                <v-layout pt-3 class="top-menu">
                    <v-menu bottom origin="center center" transition="scale-transition">
                        <v-btn slot="activator" color="primary" dark>
                            {{ tripTypetext | showFlighType }}
                        </v-btn>
                        <v-list>
                            <v-list-tile @click="changeTripType('Round trip')"><v-list-tile-title>Round trip</v-list-tile-title></v-list-tile>
                            <v-list-tile @click="changeTripType('One way')"><v-list-tile-title>One way</v-list-tile-title></v-list-tile>
                            <!--<v-list-tile @click="changeTripType('Package')"><v-list-tile-title>Package</v-list-tile-title></v-list-tile>-->
                        </v-list>
                    </v-menu>

                    <v-menu :close-on-content-click="false" bottom origin="center center"
                            transition="scale-transition" content-class="mymenuclastest"
                            class="search-box-menu-item pl-2">
                        <v-btn v-if="passengersSum <= 1" slot="activator" color="primary" dark class="passenger-sum-btn">
                            {{ passengersSum }} Passenger
                        </v-btn>
                        <v-btn v-if="passengersSum > 1" slot="activator" color="primary" dark class="passenger-sum-btn">
                            {{ passengersSum }} Passengers
                        </v-btn>
                        <v-list style="height: 180px; display: flex; flex-direction: column; justify-content: center;">
                            <v-list-tile style="height: 70px;">
                                <v-list-tile-title style="height: 100%; display: flex; justify-content: center;"><span class="passcounttxt"
                                                                                                                       style="padding-right: 38px; padding: 0 !important; margin-top: 10px !important;">Adults</span> <span
                                        @click="minusAdult" class="passcount minus" style="padding-top: 0"></span> <span
                                        class="passcountnumber" style="margin-top: -6px;">{{ Adults }}</span> <span @click="plusAdult"
                                                                                                                    class="passcount plus" style="padding-top: 0"></span>
                                </v-list-tile-title>
                            </v-list-tile>
                            <v-list-tile style="height: 70px;">
                                <v-list-tile-title style="height: 100%; display: flex; justify-content: center;"><span class="passcounttxt" style="padding: 0 !important; margin-top: 3px;">Children <span style="position: absolute; top: 20px; left: 0; color: #757575; font-size: 14px;">Aged 2-12</span></span> <span
                                        @click="minusChild" class="passcount minus" style="padding-top: 0"></span> <span
                                        class="passcountnumber" style="margin-top: -6px;">{{ Childs }}</span> <span @click="plusChild"
                                                                                                                    class="passcount plus" style="padding-top: 0"></span>
                                </v-list-tile-title>
                            </v-list-tile>
                            <v-list-tile style="height: 70px;">
                                <v-list-tile-title style="height: 100%; display: flex; justify-content: center;"><span class="passcounttxt"
                                                                                                                       style="padding-right: 35px; padding: 0 !important; margin-top: 3px;">Infants</span> <span style="position: absolute; top: 20px; left: 0; color: #757575; font-size: 14px;">Aged 0-2</span><span
                                        @click="minusInfant" class="passcount minus" style="padding-top: 0"></span> <span
                                        class="passcountnumber" style="margin-top: -6px;">{{ Infants }}</span> <span @click="plusInfant"
                                                                                                                     class="passcount plus" style="padding-top: 0"></span>
                                </v-list-tile-title>
                            </v-list-tile>
                        </v-list>
                    </v-menu>
                    <v-menu bottom origin="center center" transition="scale-transition" v-if="!this.domestic">
                        <v-btn slot="activator" color="primary" dark>
                            {{ flightClass }}
                        </v-btn>
                        <v-list>
                            <v-list-tile @click="changeFlightClass('Economy')"><v-list-tile-title>Economy</v-list-tile-title></v-list-tile>
                            <v-list-tile @click="changeFlightClass('Business')"><v-list-tile-title>Business</v-list-tile-title></v-list-tile>
                            <v-list-tile @click="changeFlightClass('First Class')"><v-list-tile-title>First Class</v-list-tile-title></v-list-tile>
                        </v-list>
                    </v-menu>
                </v-layout>
                <!-- /Drop Down Section -->


                <!-- Input Section -->
                <v-flex xs12 px-4>
                    <v-layout row wrap >

                        <v-flex md7 xs12 icityhome>
                            <v-layout row wrap>
                                <v-flex md6 xs12 class="serchcityinputs">
                                    <!--<my-select v-model="computedDepartureIata" v-bind:options="this.countries" class="i-v-select left-i-v-select" placeholder="From"></my-select>-->
                                    <!--<my-select v-model="homePageOrigin" v-bind:options="this.countries" class="i-v-select left-i-v-select" placeholder="From"></my-select>-->
                                    <my-select :class="theclassesorigin" label="airport" v-model="homePageOrigin"
                                               :filterable="false"
                                               :options="this.options" placeholder="From" @search="onSearch">
                                        <template slot="no-options">
                                            type to search destinations..
                                        </template>
                                        <template slot="option" slot-scope="option">
                                            <div class="d-center" v-if="!option.top">
                                                <div v-if="!option.top" class="baseline-flight">
                                                </div>
                                                <div v-if="!option.top" class="mselecttxtwrapper">
                                                    <span class="sp1">{{ option.airport }}</span>
                                                    <span class="sp2">{{ option.cityCountry }}</span>
                                                </div>
                                            </div>
                                            <div class="d-center mselectdividerwrapper" v-if="option.top" disabled>
                                                <div v-if="option.top">
                                                    <span class="mselectdivider">{{ option.top }}</span>
                                                </div>
                                            </div>
                                        </template>
                                        <template slot="selected-option" slot-scope="option">
                                            <div class="myselected d-center selected">
                                                <div class="baseline-flight">
                                                </div>
                                                <div class="mselecttxtwrapper">
                                                    <span class="sp1">{{ option.airport }}</span>
                                                </div>
                                            </div>
                                        </template>
                                    </my-select>
                                    <span id="searchboxloadingone" v-if="firstSearchLoading">
                                        <img src="/pics/loadding.gif" alt="">
                                        </span>
                                </v-flex>

                                <div class="gws-flights-form__swapper" @click="swapOriginDepart"></div>

                                <v-flex md6 xs12 class="serchcityinputs">
                                    <!--<my-select v-model="homePageDestination" v-bind:options="this.countries" class="i-v-select right-i-v-select" placeholder="To"></my-select>-->
                                    <my-select :class="theclasses" label="airport" v-model="homePageDestination"
                                               :filterable="false"
                                               :options="this.optionsDest" placeholder="To" @search="onSearchDest">
                                        <template slot="no-options">
                                            type to search destinations..
                                        </template>
                                        <template slot="option" slot-scope="optionDest">
                                            <div class="d-center" v-if="!optionDest.top">
                                                <div v-if="!optionDest.top" class="baseline-flight">
                                                </div>
                                                <div v-if="!optionDest.top" class="mselecttxtwrapper">
                                                    <span class="sp1">{{ optionDest.airport }}</span>
                                                    <span class="sp2">{{ optionDest.cityCountry }}</span>
                                                </div>
                                            </div>
                                            <div class="d-center mselectdividerwrapper" v-if="optionDest.top" disabled>
                                                <div v-if="optionDest.top">
                                                    <span class="mselectdivider">{{ optionDest.top }}</span>
                                                </div>
                                            </div>
                                        </template>
                                        <template slot="selected-option" slot-scope="optionDest">
                                            <div class="myselected d-center selected">
                                                <div class="baseline-flight">
                                                </div>
                                                <div class="mselecttxtwrapper">
                                                    <span class="sp1">{{ optionDest.airport }}</span>
                                                </div>
                                            </div>
                                        </template>
                                    </my-select>
                                    <span id="searchboxloadingtwo" v-if="secondSearchLoading">
                                        <img src="/pics/loadding.gif" alt="">
                                        </span>
                                </v-flex>
                            </v-layout>
                        </v-flex>

                        <v-flex md5 xs12 v-if="this.tripType !== 'One way'" class="departing-wrapper">
                            <v-layout row wrap>
                                <v-flex xs12 md6 lg6 idatepickersinglehome>
                                    <v-menu
                                            ref="menu1"
                                            :close-on-content-click="false"
                                            v-model="menu1"
                                            :nudge-right="40"
                                            lazy
                                            transition="scale-transition"
                                            offset-y
                                            full-width
                                            max-width="290px"
                                            min-width="290px"
                                    >
                                        <v-text-field
                                                slot="activator"
                                                v-model="computedDateFormattedDeparting"
                                                label="Departing"
                                                persistent-hint
                                                prepend-icon="event"
                                                @blur="departing = parseDate(dateFormatted)"
                                                readonly
                                        ></v-text-field>
                                        <v-date-picker
                                                v-model="departing"
                                                no-title
                                                @input="menu1 = false"
                                                :min="today"
                                                :max="nextYear"
                                        ></v-date-picker>
                                    </v-menu>
                                </v-flex>

                                <v-flex xs12 lg6 md6 idatepickersinglehome>
                                    <v-menu
                                            ref="menu2"
                                            :close-on-content-click="false"
                                            v-model="menu2"
                                            :nudge-right="40"
                                            lazy
                                            transition="scale-transition"
                                            offset-y
                                            full-width
                                    >
                                        <v-text-field
                                                slot="activator"
                                                v-model="computedDateFormattedReturning"
                                                label="Returning"
                                                persistent-hint
                                                prepend-icon="event"
                                                @blur="returning = parseDate(dateFormatted)"
                                                readonly
                                        ></v-text-field>
                                        <v-date-picker
                                                v-model="returning"
                                                no-title
                                                @input="menu2 = false"
                                                :min="today"
                                                :max="nextYear"
                                        ></v-date-picker>
                                    </v-menu>
                                </v-flex>
                            </v-layout>
                        </v-flex>

                        <v-flex md5 xs12 v-if="this.tripType == 'One way'" class="departing-wrapper">
                            <v-layout row wrap>
                                <v-flex xs12 lg12 idatepickersinglehome>
                                    <v-menu
                                            ref="menu1"
                                            :close-on-content-click="false"
                                            v-model="menu1"
                                            :nudge-right="40"
                                            lazy
                                            transition="scale-transition"
                                            offset-y
                                            full-width
                                            max-width="290px"
                                            min-width="290px"
                                    >
                                        <v-text-field
                                                slot="activator"
                                                v-model="computedDateFormattedDeparting"
                                                label="Departing"
                                                persistent-hint
                                                prepend-icon="event"
                                                @blur="departing = parseDate(dateFormatted)"
                                                readonly
                                        ></v-text-field>
                                        <v-date-picker
                                                v-model="departing"
                                                no-title
                                                @input="menu1 = false"
                                                :min="today"
                                                :max="nextYear"
                                        ></v-date-picker>
                                    </v-menu>
                                </v-flex>
                            </v-layout>
                        </v-flex>
                    </v-layout>
                </v-flex>
                <!-- /Input Section -->

                <!-- Search Button -->
                <v-layout>
                    <v-flex id="SERPSearchBtn" style="position: absolute; width: 100%; padding-right: 5%;">
                        <span @click="doSearch">
                            <img class="flt-fab-icon" src="https://apochi.com/img/search_white_24dp.png" alt="" height="24"
                                 width="24" data-atf="3" jstcache="1792">
                            SEARCH
                        </span>
                    </v-flex>
                    <!--<div id="homeSearchBtn">
                        <span @click="doSearch">
                            <img class="flt-fab-icon" src="https://apochi.com/img/search_white_24dp.png" alt="" height="24"
                                 width="24" data-atf="3" jstcache="1792">
                            SEARCH
                        </span>
                    </div>-->
                </v-layout>
                <!-- Search Button -->

            </v-card>
        </v-flex>
    </v-layout>
</template>

<style>
    [v-cloak]{
        display: none;
    }
    .passcount{
        padding: 19px 25px;
        border-radius: 4px;
        cursor: pointer;
    }
    .passcount.minus{
        background: #e0e0e0 url(//www.gstatic.com/images/icons/material/system/2x/remove_black_24dp.png) no-repeat center/24px;
    }
    .passcount.plus{
        background: #e0e0e0 url(//www.gstatic.com/images/icons/material/system/2x/add_black_24dp.png) no-repeat center/24px;
    }
    .passcountnumber, .passcounttxt{
        padding: 19px 25px;
    }
    .passcounttxt{
        padding-left: 0px;
        width: 120px;
    }
    .serchcityinputs .dropdown.v-select.single.searchable {
        background: rgba(255,255,255,0.7);
        padding: 5px 0;
        border-radius: 4px;
    }
    .serchcityinputs .dropdown-toggle {
        border: none!important;
    }
    .indigo {
        background-color: #00355f !important;
        border-color: #00355f !important;
    }
    .dropdown.v-select.single.searchable button, #HomeSearchBox .dropdown.v-select.single.searchable input, #HomeSearchBox .dropdown.v-select.single.searchable span {
        float: left;
        padding-left: 15px;
        color: #fff;
    }
    .serchcityinputs .vs__actions{
        display: none!important;
    }
    .serchcityinputs .selected-tag{
        max-width: 86%;
        max-height: 23px;
        display: inline-block;
        overflow: hidden;
    }
    .gws-flights-form__swapper {
        background-color: #0c3560;
        border-radius: 100%;
        margin: auto -13px;
        height: 32px;
        -webkit-transition: background-color 150ms ease 0ms;
        width: 32px;
        z-index: 1;
        margin-left: -16px;
        margin-right: -17px;
        cursor: pointer;
    }
    .gws-flights-form__swapper::after {
        background: url(//www.gstatic.com/images/icons/material/system/2x/swap_horiz_white_24dp.png) no-repeat center/24px;
        content: '';
        display: block;
        height: 32px;
        -webkit-transition: transform 150ms ease 0ms;
        width: 32px;
    }
    .icityhome{
        padding-top:16px!important;
    }
    .idatepickersinglehome{
        -webkit-text-fill-color: #fff;
    }
    .idatepickersinglehome .theme--light.v-text-field .v-input__slot:before {
        border-color: #e0e0e0;
    }
    #SERPSearchBtn span{
        padding: 10px 30px 10px 24px;
        border-radius: 50px;
        color: #0c3560;
        align-items: center;
        border: none;
        box-shadow: 0 3px 5px -1px rgba(0,0,0,0.2), 0 6px 10px 0 rgba(0,0,0,0.14), 0 1px 18px 0 rgba(0,0,0,0.12);
        box-sizing: border-box;
        cursor: pointer;
        display: flex;
        min-width: 56px;
        outline: none;
        position: relative;
        user-select: none;
        background-color: #fc0;
        margin-bottom: 30px;
        margin-top: -27px;
        max-width: 140px;
        margin: 0 auto;
        margin-top: -25px;
        margin-bottom: 25px;
    }
    /*homeSearchBtn*/
    #SERPSearchBtn{
        margin-top: 35px;
        font-weight: bold;
    }

    .idatepickersinglehome{
        padding-left: 20px;
    }

    .serchcityinputs .dropdown.v-select.single.searchable{
        padding-left: 5px;
    }

    @media (min-width:768px) {
        .serchcityinputs:nth-child(1){
            padding-right: 5px;
        }

        .serchcityinputs:nth-child(3){
            padding-left: 5px;
        }
    }

    @media (max-width: 767px){
        .serchcityinputs:nth-child(1){
            padding-bottom: 5px;
        }

        .serchcityinputs:nth-child(3){
            padding-top: 5px;
        }

        .departing-wrapper{
            margin-top: 20px;
        }

        .idatepickersinglehome{
            padding-left: 0;
        }

        .top-menu{
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .passenger-sum-btn{
            padding-left: 5px;
            padding-right: 5px;
        }
    }

    @media (max-width:960px) {
        .gws-flights-form__swapper{
            margin: 0 auto!important;
            margin-top: -15px!important;
            margin-bottom: -15px!important;
            -ms-transform: rotate(90deg); /* IE 9 */
            -webkit-transform: rotate(90deg); /* Safari */
            transform: rotate(90deg)
        }
    }
    #seprbox .v-btn__content:after {
        background: url(//www.gstatic.com/images/icons/material/system/2x/arrow_drop_down_white_24dp.png) no-repeat -8px/24px;
        content: "";
        height: 13px;
        opacity: .7;
        width: 8px;
        display: -ms-inline-flexbox;
        display: inline-flex;
        margin-left: 5px;
    }
    button.v-btn.theme--dark.primary{
        background: none!important;
        background-color: none!important;
        box-shadow: none!important;
    }
    button.v-btn.theme--dark.primary:hover{
        background: none!important;
        background-color: none!important;
        box-shadow: none!important;
    }
    #seprbox img {
        height: auto;
        max-width: 2.5rem;
        margin-right: 1rem;
    }

    #seprbox .d-center {
        display: flex;
        align-items: center;
    }

    .myselected .baseline-flight {
        width: 20px;
        height: 20px;
        background-size: 18px 18px;
    }

    .mselectdivider {
        padding: 14px 0px;
        display: block;
        width: 100%;
        font-size: 15px;
        font-weight: bold;
    }

    .myselectsaireeee ul.dropdown-menu li {
        border-top: 1px solid #eee;
    }

    .mselectdividerwrapper {
        pointer-events: none;
    }

    .myselectsair ul.dropdown-menu li:nth-child(1), .myselectsair ul.dropdown-menu li:nth-child(10), .myselectsair ul.dropdown-menu li:nth-child(1) a, .myselectsair ul.dropdown-menu li:nth-child(10) a {
        pointer-events: none;
    }

    .myselectsaireeee span.sp1, .myselectsair span.sp2{
        color:#000!important;
    }

    .myselectsaireeee ul.dropdown-menu li:nth-child(1){
        border-top:none!important;
    }

    .serchcityinputs .v-select .dropdown-menu{
        margin-top: -10px!important;
        margin-left: 10px!important;
        border-radius: 5px!important;
        Width:150%!important;
    }
    .serchcityinputs .selected-tag{
        font-size: 10px;
    }
    .dropdown.v-select.open.single.searchable.myselectsaireeee.i-v-select.left-i-v-select .selected-tag{
        display: none!important;
    }
    #seprbox .myselectsaireeee .selected-tag .mselecttxtwrapper .sp1{
        margin-left: -5px;
        font-size: 14px;
        max-width: 195px;
        overflow: hidden;
        max-height: 15px;
        font-weight: 500;
        line-height: 17px;
    }
    #seprbox .originleft.myselectsaireeee .selected-tag .baseline-flight{
        margin-left: 0px!important;
    }
    .serchcityinputs input{
        color: #000000!important;
    }


    #searchboxloadingone{
        display: inline-block;
        overflow: hidden;
        margin-top: -37px;
        position: absolute;
        margin-left: 80px;
        padding-top: 7px;
    }
    #searchboxloadingtwo{
        display: inline-block;
        overflow: hidden;
        margin-top: -37px;
        position: absolute;
        margin-left: 80px;
        padding-top: 7px;
    }
    #searchboxloadingone img{
        min-width: 100px;
    }
    #searchboxloadingtwo img{
        min-width: 100px;
    }

    #seprbox img{
        margin-right: 4px !important;
    }

</style>

<script>
    import axios from 'axios'
    Vue.prototype.$axios = axios

    import moment from 'moment'
    Vue.prototype.moment = moment

    import vSelect from 'vue-select'
    Vue.component('my-select', vSelect)






    import Vue from 'vue'
    export default {
        name: 'HomeSearchBox',

        data: vm => ({
        tripTypetext:'',
        theclasses: "myselectsair myselectsaireeee i-v-select left-i-v-select",
        theclassesorigin: "originleft myselectsair myselectsaireeee i-v-select left-i-v-select",
        options: [
            {
                "top": "Popular Iranian Domestic Destinations",
                "airport": "Mehrabad Tehran (THR)",
                "cityCountry": "Tehran, Iran",
                "Iata": "THR"
            },
            {
                "airport": "Mehrabad Tehran (THR)",
                "cityCountry": "Tehran, Iran",
                "Iata": "THR"
            },
            {
                "airport": "Ahwaz (AWZ)",
                "cityCountry": "Ahwaz, Iran",
                "Iata": "AWZ"
            },
            {
                "airport": "Shiraz (SYZ)",
                "cityCountry": "Shiraz, Iran",
                "Iata": "SYZ"
            },
            {
                "airport": "Mashhad (MHD)",
                "cityCountry": "Mashad, Iran",
                "Iata": "MHD"
            },
            {
                "airport": "Bandar Abbas (BND)",
                "cityCountry": "Bandar Abbas, Iran",
                "Iata": "BND"
            },
            {
                "airport": "Isfahan (IFN)",
                "cityCountry": "Isfahan, Iran",
                "Iata": "IFN"
            },
            {
                "airport": "Tabriz (TBZ)",
                "cityCountry": "Tabriz, Iran",
                "Iata": "TBZ"
            },
            {
                "airport": "Kish (KIH)",
                "cityCountry": "Kish Island, Iran",
                "Iata": "KIH"
            },
            {
                "top": "Popular International Destinations",
                "airport": "Istanbul (Any)",
                "cityCountry": "Istanbul, Turkey",
                "Iata": "ISTALL"
            },
            {
                "airport": "Istanbul (Any)",
                "cityCountry": "Istanbul, Turkey",
                "Iata": "ISTALL"
            },
            {
                "airport": "Dubai (Any)",
                "cityCountry": "Dubai, United Arab Emirates",
                "Iata": "DXBALL"
            },
            {
                "airport": "Tbilisi (Any)",
                "cityCountry": "Tbilisi, Georgia",
                "Iata": "TBSALL"
            },
            {
                "airport": "Moscow (Any)",
                "cityCountry": "Moscow, Russia",
                "Iata": "MOWALL"
            },
            {
                "airport": "Paris (Any)",
                "cityCountry": "Paris, France",
                "Iata": "PARALL"
            },
            {
                "airport": "Canada (Any)",
                "cityCountry": "Canada, Canada",
                "Iata": "YTOALL"
            },
            {
                "airport": "Amsterdam (Any)",
                "cityCountry": "Amsterdam, Netherlands",
                "Iata": "AMSALL"
            },
            {
                "airport": "Brussels (Any)",
                "cityCountry": "Brussels, Belgium",
                "Iata": "BRUALL"
            },
        ],
        optionsDest: [
            {
                "top": "Popular Iranian Domestic Destinations",
                "airport": "Mehrabad Tehran (THR)",
                "cityCountry": "Tehran, Iran",
                "Iata": "THR"
            },
            {
                "airport": "Mehrabad Tehran (THR)",
                "cityCountry": "Tehran, Iran",
                "Iata": "THR"
            },
            {
                "airport": "Ahwaz (AWZ)",
                "cityCountry": "Ahwaz, Iran",
                "Iata": "AWZ"
            },
            {
                "airport": "Shiraz (SYZ)",
                "cityCountry": "Shiraz, Iran",
                "Iata": "SYZ"
            },
            {
                "airport": "Mashhad (MHD)",
                "cityCountry": "Mashad, Iran",
                "Iata": "MHD"
            },
            {
                "airport": "Bandar Abbas (BND)",
                "cityCountry": "Bandar Abbas, Iran",
                "Iata": "BND"
            },
            {
                "airport": "Isfahan (IFN)",
                "cityCountry": "Isfahan, Iran",
                "Iata": "IFN"
            },
            {
                "airport": "Tabriz (TBZ)",
                "cityCountry": "Tabriz, Iran",
                "Iata": "TBZ"
            },
            {
                "airport": "Kish (KIH)",
                "cityCountry": "Kish Island, Iran",
                "Iata": "KIH"
            },
            {
                "top": "Popular International Destinations",
                "airport": "Istanbul (Any)",
                "cityCountry": "Istanbul, Turkey",
                "Iata": "ISTALL"
            },
            {
                "airport": "Istanbul (Any)",
                "cityCountry": "Istanbul, Turkey",
                "Iata": "ISTALL"
            },
            {
                "airport": "Dubai (Any)",
                "cityCountry": "Dubai, United Arab Emirates",
                "Iata": "DXBALL"
            },
            {
                "airport": "Tbilisi (Any)",
                "cityCountry": "Tbilisi, Georgia",
                "Iata": "TBSALL"
            },
            {
                "airport": "Moscow (Any)",
                "cityCountry": "Moscow, Russia",
                "Iata": "MOWALL"
            },
            {
                "airport": "Paris (Any)",
                "cityCountry": "Paris, France",
                "Iata": "PARALL"
            },
            {
                "airport": "Canada (Any)",
                "cityCountry": "Canada, Canada",
                "Iata": "YTOALL"
            },
            {
                "airport": "Amsterdam (Any)",
                "cityCountry": "Amsterdam, Netherlands",
                "Iata": "AMSALL"
            },
            {
                "airport": "Brussels (Any)",
                "cityCountry": "Brussels, Belgium",
                "Iata": "BRUALL"
            },
        ],

        firstSearchLoading:false,
        secondSearchLoading:false,
        tripType: 'One way',
        passengersSum: 1,
        Adults: 1,
        Childs: 0,
        Infants: 0,
        flightClass: 'Economy',
        homePageDestination: null,
        homePageOrigin: null,
        countries: [],
        dateFormatted: vm.formatDate(new Date().toISOString().substr(0, 10)),
        menu1: false,
        menu2: false,
        departing:new Date().toISOString().substr(0, 10),
        returning: null,

        // URL Data
        url: {
            params: '',
            queries: '',
        },

        // New Search Variables
        destIata: '',
        depIata: '',
        flagDepAirport: 0,
        flagDestAirport: 0,
        flagDepDate: 0,
        flagRetDate: 0,
        flagPassengersSum: 0,
        flagTripType: 0,
        today: '',
        nextYear: '',
        domestic: false,

        // Coutries
        fromCountry: '',
        toCountry: '',



    }),

    mounted(){


        this.firstloadingcities();
        // Created Object for Search
        this.search = {
            // from: this.homePageOrigin.value,
            // to: this.homePageDestination.value,
            departing: moment(this.departing).format('Y-MM-DD'),
            // returning: (this.returning !== null) ? moment(this.returning).format('Y-MM-DD') : null,
            returning: (this.returning !== null) ? moment(this.returning).format('Y-MM-DD') : moment(this.departing).format('Y-MM-DD'),
            adult: this.Adults,
            Child: this.Childs,
            infant: this.Infants,
            flightClass: (!this.domestic) ? this.flightClass : null,
            step: 1,
            mode: this.mode,
        }

        if(this.$route.query.step == 2){
            this.tripTypetext = 'Round trip'
        }

        // console.log("\n####### Mounted #######")
        // console.log('SERP->Mounted->Search: ', this.search);
        // console.log('OOO: ', parseInt('4'))
        // console.log("####### Mounted #######\n")


    },

    methods:{
        onSearchDest(searchval) {
            this.searchDes(searchval);
        },
        onSearch(searchval) {
            this.searchori(searchval);
        },
        searchori: _.debounce(function (searchval) {
            this.firstSearchLoading = true
            this.theclasses = "myselectsaireeee i-v-select left-i-v-select"
            this.theclassesorigin = "originleft myselectsaireeee i-v-select left-i-v-select"
            let header = {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + this.$tookenaccess,
            };
            axios.get(this.$hostname + `get/cities/` + `${escape(searchval)}`, {headers: header})
                .then(res => {
                this.firstSearchLoading = false

            this.options = res.data.data;
        });
        }, 1000),
            searchDes: _.debounce(function (searchval) {
            this.secondSearchLoading = true
            this.theclasses = "myselectsaireeee i-v-select left-i-v-select"
            this.theclassesorigin = "originleft myselectsaireeee i-v-select left-i-v-select"
            let header = {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + this.$tookenaccess,
            };
            axios.get(this.$hostname + `get/cities/` + `${escape(searchval)}`, {headers: header})
                .then(res => {
                this.secondSearchLoading = false
            this.optionsDest = res.data.data;
        });
        }, 1000),

            firstloadingcities(){
            var from = this.$route.params.travel.split('-')[0]
            var to = this.$route.params.travel.split('-')[1]
            let header = {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + this.$tookenaccess,
            };
            axios.get(this.$hostname + `get/cities/` + `${escape(from)}`, {headers: header})
                .then(res => {
                this.homePageOrigin = res.data.data[0];
        });
            axios.get(this.$hostname + `get/cities/` + `${escape(to)}`, {headers: header})
                .then(res => {
                this.homePageDestination = res.data.data[0];
        });
        },
        changeTripType: function (ttval) {

            this.tripType = ttval
            this.tripTypetext = ttval

        },
        minusAdult: function () {


            if(this.Adults == 1){
                this.Adults = 1
                return
            }
            this.Adults--
            this.passengersSum = parseInt(this.Adults) + parseInt(this.Childs) + parseInt(this.Infants)
        },
        plusAdult: function () {
            this.Adults++
            this.passengersSum = parseInt(this.Adults) + parseInt(this.Childs) + parseInt(this.Infants)

        },
        minusChild: function () {
            if(this.Childs == 0){
                this.Childs = 0
                return
            }
            this.Childs--
            this.passengersSum = parseInt(this.Adults) + parseInt(this.Childs) + parseInt(this.Infants)

        },
        plusChild: function () {
            this.Childs++
            this.passengersSum = parseInt(this.Adults) + parseInt(this.Childs) + parseInt(this.Infants)

        },
        minusInfant: function () {
            if(this.Infants == 0){
                this.Infants = 0
                return
            }
            this.Infants--
            this.passengersSum = parseInt(this.Adults) + parseInt(this.Childs) + parseInt(this.Infants)

        },
        plusInfant: function () {
            this.Infants++
            this.passengersSum = parseInt(this.Adults) + parseInt(this.Childs) + parseInt(this.Infants)

        },
        changeFlightClass: function (fcval) {
            this.flightClass = fcval
        },
        swapOriginDepart: function () {
            var temp1 = this.homePageDestination
            var temp2 = this.homePageOrigin
            this.homePageOrigin = temp1
            this.homePageDestination = temp2

        },


        formatDate (date) {
            if (!date) return null

            const [year, month, day] = date.split('-')
            return `${month}/${day}/${year}`
        },
        parseDate (date) {
            if (!date) return null

            const [month, day, year] = date.split('/')
            return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`
        },

        setMode(mode){
            this.mode = mode;
        },

        doSearch: function () {





            //---- Validation Section ----
            // if(this.homePageOrigin == null){
            //     this.$toaster.warning('Please select origin airport')
            //     return
            // }
            // if(this.homePageDestination == null){
            //     this.$toaster.warning('Please select destination airport')
            //     return
            // }
            if(this.departing == null){
                this.$toaster.warning('Please select departure date')
                return
            }
            // Validation for Round Trip => Null Returning
            if(this.tripType === 'Round trip' && this.returning == null){
                this.$toaster.warning('Please select return date')
                return
            }
            // Validation for Round Trip =>  Compare Departing Data & Returning Date
            if(this.tripType === 'Round trip' && !moment(this.departing).isBefore(moment(this.returning))){
                this.$toaster.warning('Please select correct date')
                return
            }
            // Validation for Package => Null Returning
            if(this.tripType === 'Package' && this.returning == null){
                this.$toaster.warning('Please select return date')
                return
            }
            // Validation for Package =>  Compare Departing Data & Returning Date
            if(this.tripType === 'Package' && !moment(this.departing).isBefore(moment(this.returning))){
                this.$toaster.warning('Please select correct date')
                return
            }

            // Change Mode to Package Trip
            if(this.tripType == 'Package'){
                this.mode = 'package';
            }
            if(this.tripType == 'Round trip'){
                this.mode = 'roundtrip';
            }
            if(this.tripType == 'One way'){
                this.mode = 'oneway';
            }


            if(this.domestic == true){
                if(this.tripType == 'Round trip' || this.tripType == 'Package'){
                    this.setMode('roundtrip');
                }
            } else if (this.domestic == false){
                if(this.tripType == 'Round trip' || this.tripType == 'Package'){
                    this.setMode('package');
                    this.changeTripType('Package');
                }
            }
            if(this.$route.query.mode == 'roundtrip')
                if(this.domestic == false)
                    this.setMode('package');




            var search = {
                from: this.homePageOrigin.Iata,
                to: this.homePageDestination.Iata,
                departing: moment(this.departing).format('Y-MM-DD'),
                returning: (this.returning != null) ? moment(this.returning).format('Y-MM-DD') : null,
                adult: this.Adults,
                Child: this.Childs,
                infant: this.Infants,
                flightClass: (!this.domestic) ? this.flightClass : null,
                step: 1,
                mode: this.mode,
            }



            this.$emit('do-Search', search)
        },

        setCountries(airports){
            this.countries = airports;
            this.countries.reverse();
        },

        // allowedDates: val => parseInt(val.split('-')[2], 10) % 2 === 0,
    },
    computed: {
        computedDateFormattedDeparting () {
            return this.formatDate(this.departing)
        },
        computedDateFormattedReturning () {
            return this.formatDate(this.returning)
        },
    },
    watch:{
        // homePageOrigin: function (val) {
        //     console.log('homePageOrigin: ', this.homePageOrigin)
        //     // if(val !== null){
        //     //     var test = val.cityCountry
        //     //     var test2 = val.Iata
        //     //     if(test.includes("Iran") && !(test2.includes("IKA"))){
        //     //         this.domestic = true;
        //     //     }
        //     //     this.homePageOrigin =  val
        //     // }else {
        //     //     this.domestic = false;
        //     // }
        //
        //
        //     if(val != null){
        //         if(val.cityCountry.includes('Iran' && val.Iata != 'IKA')){
        //             this.domestic = true;
        //         } else{
        //             this.domestic = false;
        //         }
        //     }
        //
        //
        //     // this.domestic = false;
        //
        // },
        // homePageDestination: function (val) {
        //     console.log('homePageDestination: ', this.homePageDestination)
        //     // if(val !== null){
        //     //     var test = val.cityCountry
        //     //     var test2 = val.Iata
        //     //     if(test.includes("Iran") && !(test2.includes("IKA"))){
        //     //         this.domestic = true;
        //     //     }
        //     //     this.homePageDestination =  val
        //     // }else {
        //     //     this.domestic = false;
        //     // }
        //
        //
        //     if(val != null){
        //         if(val.cityCountry.includes('Iran' && val.Iata != 'IKA')){
        //             this.domestic = true;
        //         } else{
        //             this.domestic = false;
        //         }
        //     }
        //
        //
        //     // this.domestic = false;
        //
        // },

        homePageOrigin(){
            let from = this.homePageOrigin;
            let to = this.homePageDestination;
            if(from != null && to != null){
                if(from.cityCountry.includes('Iran') && from.Iata != 'IKA' && to.cityCountry.includes('Iran') && to.Iata != 'IKA'){
                    this.domestic = true;
                } else{
                    this.domestic = false;
                }
            }
        },

        homePageDestination(){
            let from = this.homePageOrigin;
            let to = this.homePageDestination;
            if(from != null && to != null){
                if(from.cityCountry.includes('Iran') && from.Iata != 'IKA' && to.cityCountry.includes('Iran') && to.Iata != 'IKA'){
                    this.domestic = true;
                } else{
                    this.domestic = false;
                }
            }
        },

        departing (val) {
            this.dateFormatted = this.formatDate(this.departing)
        },

        returning (val) {
            this.dateFormatted = this.formatDate(this.returning)
        },

        // Do New Search
        Adults(){
            // this.$emit('do-Search', this.search)
            // console.log('Adult Watcher: ', this.search)
        },

        computedDestinationIata(){
            if(this.flagDest > 0){
                var search = {
                    from: this.depIata,
                    to: this.destIata,
                    departing: moment(this.departing).format('Y-MM-DD'),
                    returning: (this.returning != null) ? moment(this.returning).format('Y-MM-DD') : null,
                    adult: this.Adults,
                    Child: this.Childs,
                    infant: this.Infants,
                    flightClass: (!this.domestic) ? this.flightClass : null,
                    step: 1,
                    mode: this.mode,
                }

                this.$emit('do-search', search)
            }
            this.flagDest++;
        },


    },
    filters:{
        showFlighType(val){
            if(val == 'Package'){
                val = 'Round Trip'
            }
            return val;
        }
    },
    created(){
        // this.getCities();

        // Fill Search Box
        let depAirportIata = '';
        let retAirportIata = '';
        // console.log('URL: ', this.$route);
        this.departing = this.$route.query.departing;
        if(this.returning != ''){
            this.returning = this.$route.query.returning;
            // this.returning = '2019-03-03';
            // this.returning = this.$route.query.departing;
        }
        this.Adults = this.$route.query.adult;
        this.Childs = this.$route.query.child;
        this.Infants = this.$route.query.infant;
        this.passengersSum = parseInt(this.Adults) + parseInt(this.Childs) + parseInt(this.Infants);
        if(this.$route.query.mode == 'oneway'){
            this.changeTripType('One way');
        }
        if(this.$route.query.mode == 'roundtrip'){
            this.changeTripType('Round trip');
        }
        if(this.$route.query.mode == 'package'){
            this.changeTripType('Package');
        }

        depAirportIata = this.$route.params.travel.split('-')[0];
        retAirportIata = this.$route.params.travel.split('-')[1];

        this.today = moment().format('Y-MM-DD');
        this.nextYear = moment().add(1, 'y').format('Y-MM-DD');



    },


    }
</script>