<template>
    <v-card class="mb-2 py-3 loading-cart loading-cart--filter" style="border: none !important;">
        <vue-content-loading>
            <rect x="30" y="15" rx="4" ry="4" width="40" height="5" />
            <rect x="30" y="25" rx="4" ry="4" width="60" height="5" />

            <rect x="120" y="15" rx="4" ry="4" width="40" height="5" />
            <rect x="120" y="25" rx="4" ry="4" width="60" height="5" />

            <rect x="210" y="15" rx="4" ry="4" width="40" height="5" />
            <rect x="210" y="25" rx="4" ry="4" width="60" height="5" />

            <rect x="300" y="15" rx="4" ry="4" width="40" height="5" />
            <rect x="300" y="25" rx="4" ry="4" width="60" height="5" />
        </vue-content-loading>
    </v-card>
</template>


<style>
    .loading-cart--filter{
        height: 140px;
        background: rgb(240, 240, 240) !important;
        border: none !important;
    }
</style>


<script>
    import VueContentLoading from 'vue-content-loading';
    import { VclFacebook, VclInstagram } from 'vue-content-loading'


    export default{
        components:{
            VueContentLoading,
            VclFacebook,
            VclInstagram,
        },
    }
</script>