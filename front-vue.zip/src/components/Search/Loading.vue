<template>
    <v-app>
        <v-card class="mb-2 py-3 loading-cart">
            <vue-content-loading :width="300" :height="20">
                <circle cx="13" cy="10" r="10" />
                <rect x="30" y="2" rx="4" ry="4" width="150" height="3" />
                <rect x="30" y="9" rx="4" ry="4" width="65" height="3" />
                <rect x="30" y="16" rx="4" ry="4" width="110" height="3" />
            </vue-content-loading>
        </v-card>

        <v-card class="mb-2 py-3 loading-cart">
            <vue-content-loading :width="300" :height="20">
                <circle cx="13" cy="10" r="10" />
                <rect x="30" y="2" rx="4" ry="4" width="150" height="3" />
                <rect x="30" y="9" rx="4" ry="4" width="65" height="3" />
                <rect x="30" y="16" rx="4" ry="4" width="110" height="3" />
            </vue-content-loading>
        </v-card>

        <v-card class="mb-2 py-3 loading-cart">
            <vue-content-loading :width="300" :height="20">
                <circle cx="13" cy="10" r="10" />
                <rect x="30" y="2" rx="4" ry="4" width="150" height="3" />
                <rect x="30" y="9" rx="4" ry="4" width="65" height="3" />
                <rect x="30" y="16" rx="4" ry="4" width="110" height="3" />
            </vue-content-loading>
        </v-card>

        <v-card class="mb-2 py-3 loading-cart">
            <vue-content-loading :width="300" :height="20">
                <circle cx="13" cy="10" r="10" />
                <rect x="30" y="2" rx="4" ry="4" width="150" height="3" />
                <rect x="30" y="9" rx="4" ry="4" width="65" height="3" />
                <rect x="30" y="16" rx="4" ry="4" width="110" height="3" />
            </vue-content-loading>
        </v-card>
    </v-app>
</template>


<style>
    .loading-cart{
        border-radius: 10px;
        margin: 10px 0 !important;
        box-shadow: 5px 5px 5px rgba(0, 0, 0, 0.1) !important;
        border: 1px solid rgba(0, 0, 0, .1) !important;
    }
</style>


<script>
    import VueContentLoading from 'vue-content-loading';
    import { VclFacebook, VclInstagram } from 'vue-content-loading'


    export default{
        components:{
            VueContentLoading,
            VclFacebook,
            VclInstagram,
        },
    }
</script>