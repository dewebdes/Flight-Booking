<template>
    <!-- Flight Card -->
    <v-card class="mb-2 py-3" v-if="Airline">
        <v-card-actions v-if="!show">

            <v-flex xs2 @click="selectFlight">
                <v-avatar>
                    <img
                        :src="Airlogo"
                        alt="Airline Logo"
                    >
                </v-avatar>
            </v-flex>

            <v-flex xs7 @click="selectFlight">
                <v-layout column d-flex justify-space-between align-center>
                    <v-flex>
                        <v-layout d-flex justify-center >
                            <v-flex class="r-f-h-iata-box">
                                <v-flex class="r-f-h-time">
                                    {{ this.departure | getTheHour }}
                                </v-flex>

                                <v-flex class="r-f-h-iata-id">
                                    {{ this.from_iata }}
                                </v-flex>
                            </v-flex>
                            <v-flex class="r-f-h-arrow">
                                <img src="https://www.gstatic.com/flights/app/2x/arrow_0.png" alt="" width="35">
                            </v-flex>
                            <v-flex class="r-f-h-iata-box">
                                <v-flex class="r-f-h-time">
                                    {{ this.arrival | getTheHour }}
                                </v-flex>

                                <v-flex class="r-f-h-iata-id">
                                    {{ this.to_iata }}
                                </v-flex>
                            </v-flex>
                        </v-layout>
                    </v-flex>

                    <v-flex class="r-f-h-subcontent">
                        {{ this.stops }} - {{ this.totalDuration }} - {{ this.Airline }}
                    </v-flex>
                </v-layout>
            </v-flex>

            <v-flex xs3 class="responsive-price">
                <span class="r-f-h-price" @click="selectFlight">
                    €{{ this.totalPrice }}
                </span>
                <v-btn icon @click="show = !show">
                    <v-icon>{{ show ? 'keyboard_arrow_down' : 'keyboard_arrow_up' }}</v-icon>
                </v-btn>
            </v-flex>

        </v-card-actions>


        <v-card-actions v-if="show" class="iCard-expanded-header">
            <v-flex xs2>
                <v-avatar>
                    <img
                            :src="Airlogo"
                            alt="Airline Logo"
                    >
                </v-avatar>
            </v-flex>

            <v-flex xs7>
                <v-layout column d-flex justify-space-between align-center>
                    <v-flex>
                        <v-layout d-flex justify-center >
                            <v-flex class="r-f-h-iata-box">
                                <v-flex class="r-f-h-time">
                                    {{ this.departure | getTheHour }}
                                </v-flex>

                                <v-flex class="r-f-h-iata-id">
                                    {{ this.from_iata }}
                                </v-flex>
                            </v-flex>
                            <v-flex class="r-f-h-arrow">
                                <img src="https://www.gstatic.com/flights/app/2x/arrow_0.png" alt="" width="35">
                            </v-flex>
                            <v-flex class="r-f-h-iata-box">
                                <v-flex class="r-f-h-time">
                                    {{ this.arrival | getTheHour }}
                                </v-flex>

                                <v-flex class="r-f-h-iata-id">
                                    {{ this.to_iata }}
                                </v-flex>
                            </v-flex>
                        </v-layout>
                    </v-flex>

                    <v-flex class="r-f-h-subcontent">
                        {{ this.stops }} - {{ this.totalDuration }} - {{ Airline }}
                    </v-flex>
                </v-layout>
            </v-flex>

            <v-flex xs3 class="responsive-price">
                <span class="r-f-h-price">
                    €{{ this.totalPrice }}
                </span>
                <v-btn icon @click="show = !show">
                    <v-icon>{{ show ? 'keyboard_arrow_down' : 'keyboard_arrow_up' }}</v-icon>
                </v-btn>
            </v-flex>
        </v-card-actions>

        <v-slide-y-transition>
            <v-card-text v-show="show">
                <v-layout>
                    <v-flex xs12>
                        <v-layout>
                            <v-flex d-flex xs12 pt-3>
                                <v-flex class="flight-card-expanded-details-responsive">
                                    <span class="responsive-list-style">-</span> {{ this.departure | getTheHour }} - {{ this.departureAirportName }}
                                    <br>
                                    <span class="responsive-list-style">-</span> Travel time: {{ this.flightDuration | stopDuration }}
                                    <br>
                                    <span class="responsive-list-style">-</span> {{ this.arrival | getTheHour }} - {{ this.arrivalAirportName }}
                                    <br>
                                    <span class="responsive-list-style">-</span> {{ this.Airline }} - {{ this.Flightclass }} - {{ this.flightNumber }}
                                </v-flex>
                            </v-flex>
                        </v-layout>
                    </v-flex>
                </v-layout>
            </v-card-text>
        </v-slide-y-transition>
    </v-card>
    <!-- /Flight Card -->




</template>


<style>
    .flight-card-dotted{
        position: absolute;
    }

    .flight-card-expanded-details-responsive{
        border-left: 3px dashed #dedede;
        padding-left: 10px;
    }

    .iCard-expanded-header{
        border-bottom: 1px solid #dedede;
        padding-bottom: 24px;
    }

    .responsive-price{
        display: flex;
        justify-content: flex-end;
        align-items: center;
    }

    .r-f-h-time{
        font-size: 16px;
    }

    .r-f-h-iata-box{
        display: flex;
        flex-direction: column;
        justify-content: center;
        padding-left: 10px;
    }

    .r-f-h-arrow{
        padding-left: 10px;
        padding-top: 3px;
    }

    .r-f-h-subcontent{
        color: rgba(0,0,0,.56);
        font-size: 12px;
        /*padding-left: 10px;*/
        margin-top: 3px;
    }

    .r-f-h-iata-id{
        color: #80868b;
        font-size: 12px;
    }

    .r-f-h-price{
        font-size: 16px;
        font-weight: bold;
    }

    .responsive-list-style{
        color: #dedede;
        font-weight: bold;
        font-size: 19px;
    }
</style>


<script>
    import moment from 'moment'
    import axios from 'axios'
    import Swal from 'sweetalert2'

    export default {
        data(){
            return {
                // Expand
                show: false,

                // Responsive Status
                window:{
                    width: 0,
                    height: 0
                },
                responsiveStatus: false,

                Airlogo:'//www.gstatic.com/flights/airline_logos/70px/IR.png',
                departure:'',
                arrival:'',
                Airline: '',
                totalDuration: '',
                from_iata: '',
                to_iata: '',
                stops: '',
                totalPrice: '',
                headerOpenMode: false,
                arrivalAirportName:'',
                departureAirportName:'',
                Flightclass:'',
                flightNumber:'',
                flagExpand: false,
                flightDuration: '',
                boxHeight: '',

                // Return Flight in Package Trip
                returnStatus: false,
                returnDeparture: '',
                returnArrival: '',
                returnTotalDuration: '',
                returnStops: '',
                returnTotalPrice: '',
                returnFlightclass: '',
                returnFlightNumber: '',

                // The flights have stop
                flight2: {},
                flight3: {},
                flight4: {},
                multiAirline: false,
                logo1: '',
                logo2: '',
                logo3: '',
                logo4: '',
                logo5: '',

                // Round Trip Status
                roundTripStatus: false,
                mode: '',
            }
        },

        props: [
            'infoData'
        ],

        mounted(){
            this.loadInfo()

            // Responsive Calculations
            this.window.width = window.innerWidth;
            this.window.height = window.innerHeight;
            if(this.window.width < 768){
                this.responsiveStatus = true;
            }

            // console.log('Info Data in Flight Card: ', this.infoData)
        },

        methods:{
            selectFlight:function () {


                let header = {
                    'Accept': 'application/json',
                    'Authorization': 'Bearer ' + this.$tookenaccess,
                };
                let data =  this.infoData

                let param = this.$route.params
                let query = this.$route.query

                // console.log('Before Select: Query', query);



                axios.post( this.$hostname + 'flight/select', data ,{ headers: header})
                    .then(response => {

                        this.notFound = false

                        // If Trip is Round Trip &  Step = 1
                        if(query.returning && query.step == 1 && query.mode == 'roundtrip'){
                            let params = {
                                from: this.infoData.flightSegments[0].arrivalAirport.iata,
                                to: this.infoData.flightSegments[0].departureAirport.iata,
                                departing: query.returning,
                                adult: query.adult,
                                child: query.child,
                                infant: query.infant,
                                step: 2,
                                // Edit
                                flightClass: 'Economy',
                                uniId: this.infoData.localID2,
                            };

                            // console.log('FlightCard.vue => this.infoDate', this.infoData)

                            var fromHomeToSearchUrl = '/search/' + params.from + '-' + params.to ;
                            (params.departing !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'?departing='+params.departing : fromHomeToSearchUrl = fromHomeToSearchUrl + '?departing=' + moment().format('Y-MM-DD');
                            (params.adult !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&adult='+params.adult : fromHomeToSearchUrl+'&adult=0';
                            (params.child !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&child='+params.child : fromHomeToSearchUrl+'&child=0';
                            (params.infant !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&infant='+params.infant : fromHomeToSearchUrl+'&infant=0';
                            (params.flightClass !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&flightClass='+params.flightClass : fromHomeToSearchUrl = fromHomeToSearchUrl;
                            (params.step !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&step='+params.step : fromHomeToSearchUrl+'&step=1';
                            // Add UniID
                            (params.uniId !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&uniId='+params.uniId : fromHomeToSearchUrl+'&uniId=0';

                            // console.log('Step 1 to 2', fromHomeToSearchUrl);

                            this.$router.push(fromHomeToSearchUrl);
                            // this.$router.replace(fromHomeToSearchUrl);

                        } else{
                            // console.log('Before going to reserve page!');
                            let fromSearchToReservehUrl = /reserve/+response.data.data;

                            this.$router.push(fromSearchToReservehUrl);
                        }

                    })
                    .catch(e => {
                        Swal({
                            title: 'Time is over',
                            text: 'Time is over, please try again.',
                            imageUrl: '/pics/hourglass.png',
                            imageWidth: '100',
                            confirmButtonText: 'Try Again'
                        }).then((result) => {
                            if (result.value) {
                                window.location.reload();
                            }
                        })

                        // console.log('Select Error: ', e);
                    });



            },
            showDetails: function () {

                this.headerOpenMode = !this.headerOpenMode;

                this.boxHeight = 'auto';
                // console.log('Box Height: ', this.boxHeight);




            },
            loadInfo:function () {


                // Multi Airline Detect
                this.stops = this.infoData.Tstops
                var flightAirline = [];

                for(var i=0; i < this.infoData.flightSegments.length; i++){
                    flightAirline.push(this.infoData.flightSegments[i].operatingAirLine.iata);
                }

                if(this.stops != 'Nonstop'){
                    for(let i = 0; i < this.infoData.flightSegments.length; i++){
                        // console.log('Enter multi airline detecter');
                        for(let j = 0; j < this.infoData.flightSegments.length; j++){
                            if (flightAirline[i] !== flightAirline[j]){
                                this.multiAirline = true;
                            }
                        }
                    }
                } else{
                    this.multiAirline = false;
                }


                // for Round Trip Flights
                //


                if(this.multiAirline){
                    this.Airlogo = "https://www.gstatic.com/flights/airline_logos/70px/multi.png";
                } else{
                    this.Airlogo = this.infoData.AirlLogoBase+this.infoData.flightSegments[0].operatingAirLine.iata+'.png'
                }





                // this.Airlogo = this.infoData.AirlLogoBase+this.infoData.flightSegments[0].operatingAirLine.iata+'.png'
                this.departure = this.infoData.flightSegments[0].departureDate
                this.arrival = this.infoData.flightSegments[0].arrivalDate
                this.arrivalAirportName = this.infoData.flightSegments[0].arrivalAirport.apname
                this.departureAirportName = this.infoData.flightSegments[0].departureAirport.apname
                this.Airline = this.infoData.flightSegments[0].operatingAirLine.name
                this.totalDuration = this.infoData.totalFlightDuration
                this.from_iata = this.infoData.flightSegments[0].departureAirport.iata
                this.to_iata = this.infoData.flightSegments[0].arrivalAirport.iata
                this.stops = this.infoData.Tstops
                this.totalPrice = this.infoData.totalPrice
                this.Flightclass = this.infoData.flightSegments[0].Flightclass
                this.flightNumber = this.infoData.flightSegments[0].flightNumber
                this.flightDuration = this.infoData.flightSegments[0].flightDuration;
                this.logo1 = this.infoData.AirlLogoBase+this.infoData.flightSegments[0].operatingAirLine.iata+'.png';

                // Initilize Return Trip in Package Trip
                if('returnFlightSegments' in this.infoData){
                    this.returnStatus = true;
                    this.returnDeparture = this.infoData.returnFlightSegments[0].departureDate;
                    this.returnArrival = this.infoData.returnFlightSegments[0].arrivalDate;
                    this.returnTotalDuration = this.infoData.returnFlightSegments[0].returnTotalDuration;
                    this.returnStops = this.infoData.returnFlightSegments[0].returnStops;
                    this.returnTotalPrice = this.infoData.returnFlightSegments[0].returnTotalPrice;
                    this.returnFlightclass = this.infoData.returnFlightSegments[0].Flightclass;
                    this.returnFlightNumber = this.infoData.returnFlightSegments[0].flightNumber;
                }

                // The Flights That Have Stops
                if(this.stops == '1Stop'){
                    this.flight2 = {
                        'departure': this.infoData.flightSegments[1].departureDate,
                        'departureAirportName': this.infoData.flightSegments[1].departureAirport.apname,
                        'totalDuration': '',
                        'arrival': this.infoData.flightSegments[1].arrivalDate,
                        'arrivalAirportName': this.infoData.flightSegments[1].arrivalAirport.apname,
                        'Airline': this.infoData.flightSegments[1].operatingAirLine.name,
                        'Flightclass': this.infoData.flightSegments[1].Flightclass,
                        'flightNumber': this.infoData.flightSegments[1].flightNumber,
                        'stopDuration': this.infoData.flightSegments[1].StopDuration,
                        'flightDuration': this.infoData.flightSegments[1].flightDuration,
                        'airlineLogo': this.infoData.AirlLogoBase+this.infoData.flightSegments[1].operatingAirLine.iata+'.png',
                    };
                    this.logo2 = this.infoData.AirlLogoBase+this.infoData.flightSegments[1].operatingAirLine.iata+'.png';
                }

                if(this.stops == '2Stops'){
                    this.flight2 = {
                        'departure': this.infoData.flightSegments[1].departureDate,
                        'departureAirportName': this.infoData.flightSegments[1].departureAirport.apname,
                        'totalDuration': '',
                        'arrival': this.infoData.flightSegments[1].arrivalDate,
                        'arrivalAirportName': this.infoData.flightSegments[1].arrivalAirport.apname,
                        'Airline': this.infoData.flightSegments[1].operatingAirLine.name,
                        'Flightclass': this.infoData.flightSegments[1].Flightclass,
                        'flightNumber': this.infoData.flightSegments[1].flightNumber,
                        'stopDuration': this.infoData.flightSegments[1].StopDuration,
                        'flightDuration': this.infoData.flightSegments[1].flightDuration,
                        'airlineLogo': this.infoData.AirlLogoBase+this.infoData.flightSegments[1].operatingAirLine.iata+'.png',
                    };

                    this.flight3 = {
                        'departure': this.infoData.flightSegments[2].departureDate,
                        'departureAirportName': this.infoData.flightSegments[2].departureAirport.apname,
                        'totalDuration': '',
                        'arrival': this.infoData.flightSegments[2].arrivalDate,
                        'arrivalAirportName': this.infoData.flightSegments[2].arrivalAirport.apname,
                        'Airline': this.infoData.flightSegments[2].operatingAirLine.name,
                        'Flightclass': this.infoData.flightSegments[2].Flightclass,
                        'flightNumber': this.infoData.flightSegments[2].flightNumber,
                        'stopDuration': this.infoData.flightSegments[2].StopDuration,
                        'flightDuration': this.infoData.flightSegments[2].flightDuration,
                        'airlineLogo': this.infoData.AirlLogoBase+this.infoData.flightSegments[2].operatingAirLine.iata+'.png',
                    };

                    this.logo2 = this.infoData.AirlLogoBase+this.infoData.flightSegments[1].operatingAirLine.iata+'.png';
                    this.logo3 = this.infoData.AirlLogoBase+this.infoData.flightSegments[2].operatingAirLine.iata+'.png';
                }

                if(this.stops == '3Stops'){
                    this.flight2 = {
                        'departure': this.infoData.flightSegments[1].departureDate,
                        'departureAirportName': this.infoData.flightSegments[1].departureAirport.apname,
                        'totalDuration': '',
                        'arrival': this.infoData.flightSegments[1].arrivalDate,
                        'arrivalAirportName': this.infoData.flightSegments[1].arrivalAirport.apname,
                        'Airline': this.infoData.flightSegments[1].operatingAirLine.name,
                        'Flightclass': this.infoData.flightSegments[1].Flightclass,
                        'flightNumber': this.infoData.flightSegments[1].flightNumber,
                        'stopDuration': this.infoData.flightSegments[1].StopDuration,
                        'flightDuration': this.infoData.flightSegments[1].flightDuration,
                        'airlineLogo': this.infoData.AirlLogoBase+this.infoData.flightSegments[1].operatingAirLine.iata+'.png',
                    };

                    this.flight3 = {
                        'departure': this.infoData.flightSegments[2].departureDate,
                        'departureAirportName': this.infoData.flightSegments[2].departureAirport.apname,
                        'totalDuration': '',
                        'arrival': this.infoData.flightSegments[2].arrivalDate,
                        'arrivalAirportName': this.infoData.flightSegments[2].arrivalAirport.apname,
                        'Airline': this.infoData.flightSegments[2].operatingAirLine.name,
                        'Flightclass': this.infoData.flightSegments[2].Flightclass,
                        'flightNumber': this.infoData.flightSegments[2].flightNumber,
                        'stopDuration': this.infoData.flightSegments[2].StopDuration,
                        'flightDuration': this.infoData.flightSegments[2].flightDuration,
                        'airlineLogo': this.infoData.AirlLogoBase+this.infoData.flightSegments[2].operatingAirLine.iata+'.png',
                    };

                    this.flight4 = {
                        'departure': this.infoData.flightSegments[3].departureDate,
                        'departureAirportName': this.infoData.flightSegments[3].departureAirport.apname,
                        'totalDuration': '',
                        'arrival': this.infoData.flightSegments[3].arrivalDate,
                        'arrivalAirportName': this.infoData.flightSegments[3].arrivalAirport.apname,
                        'Airline': this.infoData.flightSegments[3].operatingAirLine.name,
                        'Flightclass': this.infoData.flightSegments[3].Flightclass,
                        'flightNumber': this.infoData.flightSegments[3].flightNumber,
                        'stopDuration': this.infoData.flightSegments[3].StopDuration,
                        'flightDuration': this.infoData.flightSegments[3].flightDuration,
                        'airlineLogo': this.infoData.AirlLogoBase+this.infoData.flightSegments[3].operatingAirLine.iata+'.png',
                    };

                    this.logo2 = this.infoData.AirlLogoBase+this.infoData.flightSegments[1].operatingAirLine.iata+'.png';
                    this.logo3 = this.infoData.AirlLogoBase+this.infoData.flightSegments[2].operatingAirLine.iata+'.png';
                    this.logo4 = this.infoData.AirlLogoBase+this.infoData.flightSegments[3].operatingAirLine.iata+'.png';
                }

                // if(this.returnStatus){
                //     this.boxHeight = '100px';
                // } else{
                //     this.boxHeight = '87px';
                // }
                this.boxHeight = '100px';


            },
            reserveIt:function () {
                var item = this.infoData;
                alert(item.id);
                alert(item.name);
            }
        },

        filters:{
            getTheHour: function (Val) {
                return moment(Val).format('h:mm A')
            },
            openDeparure: function (val) {
                return moment(val).format('dd MMM YY')
            },

            stopDuration(time){
                time = time.split(":");
                var newTime = parseInt(time[1]) + "h " + parseInt(time[2]) + 'm'
                return newTime;
            }
        },

        watch: {
            infoData: function (newVal, oldVal) {
                this.loadInfo()
                // console.log('Prop changed: ', newVal, ' | was: ', oldVal)
            }
        },

        computed: {
            iStops(){
                return this.stops;
            }
        }
    }
</script>