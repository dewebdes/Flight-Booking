<template>
    <!-- Flight Card -->
    <v-card class="mb-2 py-3 mobile-flight-card" v-if="Airline">
        <v-card-actions v-if="!show">

            <v-layout column justify-center>
                <v-layout>

                    <v-flex xs2 @click="show = !show" >
                        <v-avatar>
                            <img
                                    :src="depFlightWrapper.Airlogo"
                                    :alt="depFlightArr[0].Airline"
                            >
                        </v-avatar>
                    </v-flex>

                    <v-flex xs7 @click="show = !show" >
                        <v-layout column d-flex justify-space-between align-center>
                            <v-flex>
                                <v-layout d-flex justify-center >
                                    <v-flex class="r-f-h-iata-box">
                                        <v-flex class="r-f-h-time">
                                            {{ this.depFlightWrapper.departure | getTheHour }}
                                        </v-flex>

                                        <v-flex class="r-f-h-iata-id">
                                            {{ this.depFlightWrapper.from_iata }}
                                        </v-flex>
                                    </v-flex>
                                    <v-flex class="r-f-h-arrow">
                                        <img src="https://www.gstatic.com/flights/app/2x/arrow_0.png" alt="" width="35">
                                    </v-flex>
                                    <v-flex class="r-f-h-iata-box">
                                        <v-flex class="r-f-h-time">
                                            {{ this.depFlightWrapper.arrival | getTheHour }}
                                        </v-flex>

                                        <v-flex class="r-f-h-iata-id">
                                            {{ this.depFlightWrapper.to_iata }}
                                        </v-flex>
                                    </v-flex>
                                </v-layout>
                            </v-flex>

                            <!--<v-flex class="r-f-h-subcontent">-->
                            <!--{{ this.depFlightWrapper.stops }} - {{ this.depFlightWrapper.depFlightDuration }} - {{ this.depFlightArr[0].Airline }}-->
                            <!--</v-flex>-->
                        </v-layout>
                    </v-flex>

                    <v-flex xs3 class="responsive-price">
                        <span class="r-f-h-price" @click="show = !show">
                            €{{ this.depFlightWrapper.totalPrice }}
                        </span>
                        <v-btn icon @click="show = !show">
                            <v-icon>{{ show ? 'keyboard_arrow_down' : 'keyboard_arrow_up' }}</v-icon>
                        </v-btn>
                    </v-flex>

                </v-layout>

                <v-layout>
                    <v-flex xs12 class="r-f-h-subcontent">
                        {{ this.depFlightWrapper.stops | stopCount }} - {{ this.depFlightWrapper.depFlightDuration }} - {{ this.depFlightArr[0].Airline }}
                    </v-flex>
                </v-layout>
            </v-layout>

        </v-card-actions>


        <v-card-actions v-if="show" class="iCard-expanded-header">
            <v-flex xs2>
                <v-avatar>
                    <img
                            :src="depFlightWrapper.Airlogo"
                            :alt="depFlightArr[0].Airline"
                    >
                </v-avatar>
            </v-flex>

            <v-flex xs7>
                <v-layout column d-flex justify-space-between align-center>
                    <v-flex>
                        <v-layout d-flex justify-center >
                            <v-flex class="r-f-h-iata-box">
                                <v-flex class="r-f-h-time">
                                    {{ this.depFlightWrapper.departure | getTheHour }}
                                </v-flex>

                                <v-flex class="r-f-h-iata-id">
                                    {{ this.depFlightWrapper.from_iata }}
                                </v-flex>
                            </v-flex>
                            <v-flex class="r-f-h-arrow">
                                <img src="https://www.gstatic.com/flights/app/2x/arrow_0.png" alt="" width="35">
                            </v-flex>
                            <v-flex class="r-f-h-iata-box">
                                <v-flex class="r-f-h-time">
                                    {{ this.depFlightWrapper.arrival | getTheHour }}
                                </v-flex>

                                <v-flex class="r-f-h-iata-id">
                                    {{ this.depFlightWrapper.to_iata }}
                                </v-flex>
                            </v-flex>
                        </v-layout>
                    </v-flex>

                    <v-flex class="r-f-h-subcontent">
                        {{ this.depFlightWrapper.stops }} - {{ this.depFlightWrapper.depFlightDuration }} - {{ depFlightArr[0].Airline }}
                    </v-flex>
                </v-layout>
            </v-flex>

            <v-flex xs3 class="responsive-price">
                <span class="r-f-h-price">
                    €{{ this.depFlightWrapper.totalPrice }}
                </span>
                <v-btn icon @click="show = !show">
                    <v-icon>{{ show ? 'keyboard_arrow_down' : 'keyboard_arrow_up' }}</v-icon>
                </v-btn>
            </v-flex>
        </v-card-actions>

        <v-slide-y-transition>
            <v-card-text v-show="show">
                <v-layout>
                    <v-flex xs12>
                        <v-layout>
                            <v-btn
                                    color="info"
                                    block
                                    outline
                                    @click="selectFlight"
                                    :disabled="selectLoading"
                            >
                                Select Flight
                                <span slot="loader" class="custom-loader">
                                    <v-icon light>cached</v-icon>
                                </span>
                            </v-btn>
                        </v-layout>
                        <!--<v-layout>-->
                            <!--<v-flex d-flex xs12 pt-3>-->
                                <!--<v-flex class="flight-card-expanded-details-responsive">-->
                                    <!--<span class="responsive-list-style">-</span> {{ this.depFlightWrapper.departure | getTheHour }} - {{ this.depFlightArr[0].departureAirportName }}-->
                                    <!--<br>-->
                                    <!--<span class="responsive-list-style">-</span> Travel time: {{ this.depFlightWrapper.depFlightDuration }}-->
                                    <!--<br>-->
                                    <!--<span class="responsive-list-style">-</span> {{ this.depFlightWrapper.arrival | getTheHour }} - {{ this.depFlightArr[0].arrivalAirportName }}-->
                                    <!--<br>-->
                                    <!--<span class="responsive-list-style">-</span> {{ this.depFlightArr[0].Airline }} - {{ this.depFlightArr[0].Flightclass }} - {{ this.depFlightArr[0].flightNumber }}-->
                                <!--</v-flex>-->
                            <!--</v-flex>-->
                        <!--</v-layout>-->

                        <!--<span v-if="mode=='package'"><strong>Departure:</strong></span>-->
                        <v-flex class="return-title-flightcard" v-if="mode=='package'"><strong>Departure</strong></v-flex>
                        <!-- Expand 1 (Departure) -->
                        <v-layout pt-4>
                            <v-flex d-flex xs12>
                                <img class="flight-card-dotted" src="https://www.gstatic.com/flights/app/1x/dotted_flight_80dp.png" alt="">
                                <v-flex class="flight-card-expanded-details">
                                    <v-flex class="serp-travel-airport">
                                        {{ this.depFlightArr[0].departure | getTheHour }} - {{ this.depFlightArr[0].departureAirportName }}
                                    </v-flex>
                                    <br>
                                    <v-flex class="serp-travel-time">
                                        Travel time: {{ this.depFlightArr[0].depFlightDuration | stopDuration }}
                                    </v-flex>
                                    <br>
                                    <v-flex class="serp-travel-airport">
                                        {{ this.depFlightArr[0].arrival | getTheHour }} - {{ this.depFlightArr[0].arrivalAirportName }}
                                    </v-flex>
                                    <v-flex class="serp-travel-airline">
                                        {{ this.depFlightArr[0].Airline }} - {{ this.depFlightArr[0].Flightclass }} - {{ this.depFlightArr[0].flightNumber }}
                                    </v-flex>
                                </v-flex>
                            </v-flex>
                        </v-layout>
                        <!-- /Expand 1 (Departure) -->

                        <!-- Stop HR -->
                        <v-layout v-if="depFlightWrapper.depStopCount > 0">
                            <v-flex d-flex xs12>
                                <v-flex class="serp-travel-stop-hr" py-3>
                                    <!--6 h 25 m layover Baku GYD-->
                                    {{ this.depFlightArr[0].depSegmentStopDuration | stopDuration }} . {{ this.depFlightArr[0].arrivalAirportName }}
                                </v-flex>
                            </v-flex>
                        </v-layout>
                        <!-- /Stop HR -->

                        <!-- Expand 2 (Departure) -->
                        <v-layout class="serp-travel-stop-wrapper" v-if="depFlightWrapper.depStopCount > 0">
                            <v-flex d-flex xs12>
                                <img class="flight-card-dotted" src="https://www.gstatic.com/flights/app/1x/dotted_flight_80dp.png" alt="">
                                <v-flex class="flight-card-expanded-details">
                                    <v-flex class="serp-travel-airport">
                                        {{ this.depFlightArr[1].departure | getTheHour }} - {{ this.depFlightArr[1].departureAirportName }}
                                    </v-flex>
                                    <br>
                                    <v-flex class="serp-travel-time">
                                        Travel time: {{ this.depFlightArr[1].depFlightDuration | stopDuration }}
                                    </v-flex>
                                    <br>
                                    <v-flex class="serp-travel-airport">
                                        {{ this.depFlightArr[1].arrival | getTheHour }} - {{ this.depFlightArr[1].arrivalAirportName }}
                                    </v-flex>
                                    <v-flex class="serp-travel-airline">
                                        {{ this.depFlightArr[1].Airline }} - {{ this.depFlightArr[1].Flightclass }} - {{ this.depFlightArr[1].flightNumber }}
                                    </v-flex>
                                </v-flex>
                            </v-flex>
                        </v-layout>
                        <!-- /Expand 2 (Departure) -->

                        <!-- Stop HR -->
                        <v-layout v-if="depFlightWrapper.depStopCount > 1">
                            <v-flex d-flex xs12>
                                <v-flex class="serp-travel-stop-hr" py-3>
                                    <!--6 h 25 m layover Baku GYD-->
                                    {{ this.depFlightArr[1].depSegmentStopDuration | stopDuration }} . {{ this.depFlightArr[1].arrivalAirportName }}
                                </v-flex>
                            </v-flex>
                        </v-layout>
                        <!-- /Stop HR -->

                        <!-- Expand 3 (Departure) -->
                        <v-layout class="serp-travel-stop-wrapper" v-if="depFlightWrapper.depStopCount > 1">
                            <v-flex d-flex xs12>
                                <img class="flight-card-dotted" src="https://www.gstatic.com/flights/app/1x/dotted_flight_80dp.png" alt="">
                                <v-flex class="flight-card-expanded-details">
                                    <v-flex class="serp-travel-airport">
                                        {{ this.depFlightArr[2].departure | getTheHour }} - {{ this.depFlightArr[2].departureAirportName }}
                                    </v-flex>
                                    <br>
                                    <v-flex class="serp-travel-time">
                                        Travel time: {{ this.depFlightArr[2].depFlightDuration | stopDuration }}
                                    </v-flex>
                                    <br>
                                    <v-flex class="serp-travel-airport">
                                        {{ this.depFlightArr[2].arrival | getTheHour }} - {{ this.depFlightArr[2].arrivalAirportName }}
                                    </v-flex>
                                    <v-flex class="serp-travel-airline">
                                        {{ this.depFlightArr[2].Airline }} - {{ this.depFlightArr[2].Flightclass }} - {{ this.depFlightArr[2].flightNumber }}
                                    </v-flex>
                                </v-flex>
                            </v-flex>
                        </v-layout>
                        <!-- /Expand 3 (Departure) -->



                        <!-- Return Expanded (Nonstop) -->
                        <v-flex xs12 mt-3 v-if="mode=='package'">
                            <v-flex class="return-title-flightcard"><strong>Return</strong></v-flex>

                            <!-- Expand 1 (Return) -->
                            <v-layout pt-4>
                                <v-flex d-flex xs12>
                                    <img class="flight-card-dotted" src="https://www.gstatic.com/flights/app/1x/dotted_flight_80dp.png" alt="">
                                    <v-flex class="flight-card-expanded-details">
                                        <v-flex class="serp-travel-airport">
                                            {{ this.retFlightArr[0].departure | getTheHour }} - {{ this.retFlightArr[0].departureAirportName }}
                                        </v-flex>
                                        <br>
                                        <v-flex class="serp-travel-time">
                                            Travel time: {{ this.retFlightArr[0].retFlightDuration | stopDuration }}
                                        </v-flex>
                                        <br>
                                        <v-flex class="serp-travel-airport">
                                            {{ this.retFlightArr[0].arrival | getTheHour }} - {{ this.retFlightArr[0].arrivalAirportName }}
                                        </v-flex>
                                        <br>
                                        <v-flex class="serp-travel-airline">
                                            {{ this.retFlightArr[0].Airline }} - {{ this.retFlightArr[0].Flightclass }} - {{ this.retFlightArr[0].flightNumber }}
                                        </v-flex>
                                    </v-flex>
                                </v-flex>
                            </v-layout>
                            <!-- /Expand 1 (Return) -->

                            <!-- Stop HR -->
                            <v-layout v-if="depFlightWrapper.retStopCount > 0">
                                <v-flex d-flex xs12>
                                    <v-flex class="serp-travel-stop-hr" py-3>
                                        <!--6 h 25 m layover Baku GYD-->
                                        {{ this.retFlightArr[0].retSegmentStopDuration | stopDuration }} . {{ this.retFlightArr[0].arrivalAirportName }}
                                    </v-flex>
                                </v-flex>
                            </v-layout>
                            <!-- /Stop HR -->

                            <!-- Expand 2 (Departure) -->
                            <v-layout class="serp-travel-stop-wrapper" v-if="depFlightWrapper.retStopCount > 0">
                                <v-flex d-flex xs12>
                                    <img class="flight-card-dotted" src="https://www.gstatic.com/flights/app/1x/dotted_flight_80dp.png" alt="">
                                    <v-flex class="flight-card-expanded-details">
                                        <v-flex class="serp-travel-airport">
                                            {{ this.retFlightArr[1].departure | getTheHour }} - {{ this.retFlightArr[1].departureAirportName }}
                                        </v-flex>
                                        <br>
                                        <v-flex class="serp-travel-time">
                                            Travel time: {{ this.retFlightArr[1].retFlightDuration | stopDuration }}
                                        </v-flex>
                                        <br>
                                        <v-flex class="serp-travel-airport">
                                            {{ this.retFlightArr[1].arrival | getTheHour }} - {{ this.retFlightArr[1].arrivalAirportName }}
                                        </v-flex>
                                        <br>
                                        <v-flex class="serp-travel-airline">
                                            {{ this.retFlightArr[1].Airline }} - {{ this.retFlightArr[1].Flightclass }} - {{ this.retFlightArr[1].flightNumber }}
                                        </v-flex>
                                    </v-flex>
                                </v-flex>
                            </v-layout>
                            <!-- /Expand 2 (Departure) -->

                            <!-- Stop HR -->
                            <v-layout v-if="depFlightWrapper.retStopCount > 1">
                                <v-flex d-flex xs12>
                                    <v-flex class="serp-travel-stop-hr" py-3>
                                        <!--6 h 25 m layover Baku GYD-->
                                        {{ this.retFlightArr[1].retSegmentStopDuration | stopDuration }} . {{ this.retFlightArr[1].arrivalAirportName }}
                                    </v-flex>
                                </v-flex>
                            </v-layout>
                            <!-- /Stop HR -->

                            <!-- Expand 3 (Departure) -->
                            <v-layout class="serp-travel-stop-wrapper" v-if="depFlightWrapper.retStopCount > 1">
                                <v-flex d-flex xs12>
                                    <img class="flight-card-dotted" src="https://www.gstatic.com/flights/app/1x/dotted_flight_80dp.png" alt="">
                                    <v-flex class="flight-card-expanded-details">
                                        <v-flex class="serp-travel-airport">
                                            {{ this.retFlightArr[2].departure | getTheHour }} - {{ this.retFlightArr[2].departureAirportName }}
                                        </v-flex>
                                        <br>
                                        <v-flex class="serp-travel-time">
                                            Travel time: {{ this.retFlightArr[2].retFlightDuration | stopDuration }}
                                        </v-flex>
                                        <br>
                                        <v-flex class="serp-travel-airport">
                                            {{ this.retFlightArr[2].arrival | getTheHour }} - {{ this.retFlightArr[2].arrivalAirportName }}
                                        </v-flex>
                                        <br>
                                        <v-flex class="serp-travel-airline">
                                            {{ this.retFlightArr[2].Airline }} - {{ this.retFlightArr[2].Flightclass }} - {{ this.retFlightArr[2].flightNumber }}
                                        </v-flex>
                                    </v-flex>
                                </v-flex>
                            </v-layout>
                            <!-- /Expand 3 (Departure) -->

                        </v-flex>
                        <!-- /Return Expanded -->



                    </v-flex>
                </v-layout>
            </v-card-text>
        </v-slide-y-transition>
    </v-card>
    <!-- /Flight Card -->




</template>





<style>
    .flight-card-dotted{
        position: absolute;
    }

    .flight-card-expanded-details-responsive{
        border-left: 3px dashed #dedede;
        padding-left: 10px;
    }

    .iCard-expanded-header{
        border-bottom: 1px solid #dedede;
        padding-bottom: 24px;
    }

    .responsive-price{
        display: flex;
        justify-content: flex-end;
        align-items: center;
    }

    .r-f-h-time{
        font-size: 16px;
    }

    .r-f-h-iata-box{
        display: flex;
        flex-direction: column;
        justify-content: center;
        padding-left: 10px;
    }

    .r-f-h-arrow{
        padding-left: 10px;
        padding-top: 3px;
    }

    .r-f-h-subcontent{
        color: rgba(0,0,0,.56);
        font-size: 12px;
        /*padding-left: 10px;*/
        margin-top: 3px;
    }

    .r-f-h-iata-id{
        color: #80868b;
        font-size: 12px;
    }

    .r-f-h-price{
        font-size: 16px;
        font-weight: bold;
    }

    .responsive-list-style{
        color: #dedede;
        font-weight: bold;
        font-size: 19px;
    }

    .custom-loader {
        animation: loader 1s infinite;
        display: flex;
    }
    @-moz-keyframes loader {
        from {
            transform: rotate(0);
        }
        to {
            transform: rotate(360deg);
        }
    }
    @-webkit-keyframes loader {
        from {
            transform: rotate(0);
        }
        to {
            transform: rotate(360deg);
        }
    }
    @-o-keyframes loader {
        from {
            transform: rotate(0);
        }
        to {
            transform: rotate(360deg);
        }
    }
    @keyframes loader {
        from {
            transform: rotate(0);
        }
        to {
            transform: rotate(360deg);
        }
    }

    @media only screen and (max-width: 768px){
        .serp-travel-airport{
            font-size: 14px;
        }

        .serp-travel-airline{
            padding-top: 7px;
        }

        .r-f-h-subcontent{
            text-align: center;
            border-top: 1px solid #d3d3d3;
            border-bottom: 1px solid #d3d3d3;
            margin-top: 15px;
        }

        .serp-travel-stop-hr{
            line-height: 10px;
        }
    }

    .return-title-flightcard{
        width: 100%;
        border-top: 2px solid #d3d3d3;
        border-bottom: 2px solid #d3d3d3;
        text-align: center;
        color: #37474F;
        /*margin-bottom: 15px;*/
        margin-top: 30px;
    }

    .mobile-flight-card{
        box-shadow: 6px 6px 6px rgba(0, 0, 0, .07);
        border-radius: 10px;
        border: 1px solid rgba(0, 0, 0, .1) !important;
        margin: 15px 0 !important;
    }
</style>


<script>
    import moment from 'moment'
    import axios from 'axios'
    import Swal from 'sweetalert2'

    export default {
        data(){
            return {
                // Expand
                show: false,

                // Responsive Status
                window:{
                    width: 0,
                    height: 0
                },
                responsiveStatus: false,

                Airlogo:'//www.gstatic.com/flights/airline_logos/70px/IR.png',
                departure:'',
                arrival:'',
                Airline: '',
                totalDuration: '',
                from_iata: '',
                to_iata: '',
                stops: '',
                totalPrice: '',
                headerOpenMode: false,
                arrivalAirportName:'',
                departureAirportName:'',
                Flightclass:'',
                flightNumber:'',
                flagExpand: false,
                flightDuration: '',
                boxHeight: '',

                // Return Flight in Package Trip
                returnStatus: false,
                returnDeparture: '',
                returnArrival: '',
                returnTotalDuration: '',
                returnStops: '',
                returnTotalPrice: '',
                returnFlightclass: '',
                returnFlightNumber: '',

                // The flights have stop
                flight2: {},
                flight3: {},
                flight4: {},
                multiAirline: false,
                logo1: '',
                logo2: '',
                logo3: '',
                logo4: '',
                logo5: '',

                // Round Trip Status
                roundTripStatus: false,
                mode: '',

                // Flight Wrapper
                depFlightWrapper: [
                    {
                        departure: '',
                        arrival: '',
                        departureAirportName: '',
                        arrivalAirportName: '',
                        Airline: '',
                        Airlogo: '',
                        from_iata: '',
                        to_iata: '',
                        stops: '',
                        totalPrice: '',
                        Flightclass: '',
                        flightNumber: '',
                        flightDuration: '',
                        logo1: '',
                        totalFlightDuration: '',
                        depFlightDuration: '',
                        totalStopDuration: '',
                        depStopDuration: '',
                        depStopCount: 0,
                        depStopStatus: '',
                        stopCount: 0,
                        stopStatus: '',
                    }
                ],
                retFlightWrapper: [
                    {
                        departure: '',
                        arrival: '',
                        departureAirportName: '',
                        arrivalAirportName: '',
                        Airline: '',
                        Airlogo: '',
                        from_iata: '',
                        to_iata: '',
                        stops: '',
                        totalPrice: '',
                        Flightclass: '',
                        flightNumber: '',
                        flightDuration: '',
                        logo1: '',
                        totalFlightDuration: '',
                        retFlightDuration: '',
                        totalStopDuration: '',
                        retStopDuration: '',
                        retStopCount: 0,
                        retStopStatus: '',
                        stopCount: 0,
                        stopStatus: '',
                    }
                ],
                depFlightArr: [
                    {
                        departure: '',
                        arrival: '',
                        departureAirportName: '',
                        arrivalAirportName: '',
                        Airline: '',
                        from_iata: '',
                        to_iata: '',
                        stops: '',
                        totalPrice: '',
                        Flightclass: '',
                        flightNumber: '',
                        flightDuration: '',
                        logo1: '',
                        totalFlightDuration: '',
                        depFlightDuration: '',
                        totalStopDuration: '',
                        depStopDuration: '',
                    },
                    {
                        departure: '',
                        arrival: '',
                        departureAirportName: '',
                        arrivalAirportName: '',
                        Airline: '',
                        from_iata: '',
                        to_iata: '',
                        stops: '',
                        totalPrice: '',
                        Flightclass: '',
                        flightNumber: '',
                        flightDuration: '',
                        logo1: '',
                        totalFlightDuration: '',
                        depFlightDuration: '',
                        totalStopDuration: '',
                        depStopDuration: '',
                    },
                    {
                        departure: '',
                        arrival: '',
                        departureAirportName: '',
                        arrivalAirportName: '',
                        Airline: '',
                        from_iata: '',
                        to_iata: '',
                        stops: '',
                        totalPrice: '',
                        Flightclass: '',
                        flightNumber: '',
                        flightDuration: '',
                        logo1: '',
                        totalFlightDuration: '',
                        depFlightDuration: '',
                        totalStopDuration: '',
                        depStopDuration: '',
                    },
                    {
                        departure: '',
                        arrival: '',
                        departureAirportName: '',
                        arrivalAirportName: '',
                        Airline: '',
                        from_iata: '',
                        to_iata: '',
                        stops: '',
                        totalPrice: '',
                        Flightclass: '',
                        flightNumber: '',
                        flightDuration: '',
                        logo1: '',
                        totalFlightDuration: '',
                        depFlightDuration: '',
                        totalStopDuration: '',
                        depStopDuration: '',
                    },
                    {
                        departure: '',
                        arrival: '',
                        departureAirportName: '',
                        arrivalAirportName: '',
                        Airline: '',
                        from_iata: '',
                        to_iata: '',
                        stops: '',
                        totalPrice: '',
                        Flightclass: '',
                        flightNumber: '',
                        flightDuration: '',
                        logo1: '',
                        totalFlightDuration: '',
                        depFlightDuration: '',
                        totalStopDuration: '',
                        depStopDuration: '',
                    },
                ],
                retFlightArr: [
                    {
                        departure: '',
                        arrival: '',
                        departureAirportName: '',
                        arrivalAirportName: '',
                        Airline: '',
                        from_iata: '',
                        to_iata: '',
                        stops: '',
                        totalPrice: '',
                        Flightclass: '',
                        flightNumber: '',
                        flightDuration: '',
                        logo1: '',
                        totalFlightDuration: '',
                        retFlightDuration: '',
                        totalStopDuration: '',
                        retStopDuration: '',
                    },
                    {
                        departure: '',
                        arrival: '',
                        departureAirportName: '',
                        arrivalAirportName: '',
                        Airline: '',
                        from_iata: '',
                        to_iata: '',
                        stops: '',
                        totalPrice: '',
                        Flightclass: '',
                        flightNumber: '',
                        flightDuration: '',
                        logo1: '',
                        totalFlightDuration: '',
                        retFlightDuration: '',
                        totalStopDuration: '',
                        retStopDuration: '',
                    },
                    {
                        departure: '',
                        arrival: '',
                        departureAirportName: '',
                        arrivalAirportName: '',
                        Airline: '',
                        from_iata: '',
                        to_iata: '',
                        stops: '',
                        totalPrice: '',
                        Flightclass: '',
                        flightNumber: '',
                        flightDuration: '',
                        logo1: '',
                        totalFlightDuration: '',
                        retFlightDuration: '',
                        totalStopDuration: '',
                        retStopDuration: '',
                    },
                    {
                        departure: '',
                        arrival: '',
                        departureAirportName: '',
                        arrivalAirportName: '',
                        Airline: '',
                        from_iata: '',
                        to_iata: '',
                        stops: '',
                        totalPrice: '',
                        Flightclass: '',
                        flightNumber: '',
                        flightDuration: '',
                        logo1: '',
                        totalFlightDuration: '',
                        retFlightDuration: '',
                        totalStopDuration: '',
                        retStopDuration: '',
                    },
                    {
                        departure: '',
                        arrival: '',
                        departureAirportName: '',
                        arrivalAirportName: '',
                        Airline: '',
                        from_iata: '',
                        to_iata: '',
                        stops: '',
                        totalPrice: '',
                        Flightclass: '',
                        flightNumber: '',
                        flightDuration: '',
                        logo1: '',
                        totalFlightDuration: '',
                        retFlightDuration: '',
                        totalStopDuration: '',
                        retStopDuration: '',
                    },
                ],

                // Select Loading
                selectLoading: false,

            }
        },

        props: [
            'infoData'
        ],

        mounted(){
            this.loadInfo()

            // Responsive Calculations
            this.window.width = window.innerWidth;
            this.window.height = window.innerHeight;
            if(this.window.width < 768){
                this.responsiveStatus = true;
            }

            this.mode = this.$route.query.mode;

            // console.log('Info Data in Flight Card: ', this.infoData)

            if(this.infoData.totalFlightDuration == null){
                this.infoData = null;
            }
        },

        methods:{
            testMethod(){
                alert(':)')
            },

            selectFlight:function () {

                this.selectLoading = true;

                this.$emit('selectLoading');


                let header = {
                    'Accept': 'application/json',
                    'Authorization': 'Bearer ' + this.$tookenaccess,
                };
                let data =  this.infoData

                let param = this.$route.params
                let query = this.$route.query


                // console.log('Before Select: Query', query);



                axios.post( this.$hostname + 'flight/select', data ,{ headers: header})
                    .then(response => {

                        this.selectLoading = true;

                        this.notFound = false

                        // If Trip is Round Trip &  Step = 1
                        if(query.returning && query.step == 1 && query.mode == 'roundtrip'){
                            let params = {
                                from: this.infoData.leaveOptions.flightSegments[0].arrivalAirport.iata,
                                to: this.infoData.leaveOptions.flightSegments[0].departureAirport.iata,
                                departing: query.returning,
                                adult: query.adult,
                                child: query.child,
                                infant: query.infant,
                                step: 2,
                                // Edit
                                flightClass: 'Economy',
                                uniId: this.infoData.localID2,
                            };

                            // console.log('FlightCard.vue => this.infoDate', this.infoData)

                            var fromHomeToSearchUrl = '/search/' + params.from + '-' + params.to ;
                            (params.departing !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'?departing='+params.departing : fromHomeToSearchUrl = fromHomeToSearchUrl + '?departing=' + moment().format('Y-MM-DD');
                            (params.adult !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&adult='+params.adult : fromHomeToSearchUrl+'&adult=0';
                            (params.child !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&child='+params.child : fromHomeToSearchUrl+'&child=0';
                            (params.infant !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&infant='+params.infant : fromHomeToSearchUrl+'&infant=0';
                            (params.flightClass !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&flightClass='+params.flightClass : fromHomeToSearchUrl = fromHomeToSearchUrl;
                            (params.step !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&step='+params.step : fromHomeToSearchUrl+'&step=1';
                            // Add UniID
                            (params.uniId !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&uniId='+params.uniId : fromHomeToSearchUrl+'&uniId=0';

                            // console.log('Step 1 to 2', fromHomeToSearchUrl);

                            this.$router.push(fromHomeToSearchUrl);
                            // this.$router.replace(fromHomeToSearchUrl);

                        } else{
                            // console.log('Before going to reserve page!');
                            let fromSearchToReservehUrl = /reserve/+response.data.data;

                            this.$router.push(fromSearchToReservehUrl);
                        }

                    })
                    .catch(e => {
                        Swal({
                            title: 'Time is over',
                            text: 'Time is over, please try again.',
                            imageUrl: '/pics/hourglass.png',
                            imageWidth: '100',
                            confirmButtonText: 'Try Again'
                        }).then((result) => {
                            if (result.value) {
                                window.location.reload();
                            }
                        })
                        // console.log('Select Error: ', e);
                    });



            },
            showDetails: function () {

                this.headerOpenMode = !this.headerOpenMode;

                this.boxHeight = 'auto';
                // console.log('Box Height: ', this.boxHeight);





            },
            loadInfo:function () {
                let flightData = this.infoData;
                let depFlightSegments= this.infoData.leaveOptions.flightSegments;
                this.depFlightWrapper = this.infoData.leaveOptions.flightSegments;
                let retFlightSegments = '';
                // console.log('DepFlightWrapper: ', this.depFlightWrapper);
                if(typeof this.infoData.returnOptions !== 'undefined'){
                    retFlightSegments= this.infoData.returnOptions.flightSegments;
                    this.retFlightWrapper = this.infoData.returnOptions.flightSegments;
                }


                // Flight Data Wrapper
                this.depFlightWrapper.departure = flightData.depDate
                this.depFlightWrapper.arrival = flightData.arrDate
                this.depFlightWrapper.departureAirportName = flightData.depAirport
                this.depFlightWrapper.arrivalAirportName = flightData.arrAirport
                // this.depFlightWrapper.Airline = depFlightSegments[i].operatingAirLine.name
                this.depFlightWrapper.from_iata = flightData.depIata
                this.depFlightWrapper.to_iata = flightData.arrIata
                this.depFlightWrapper.stops = flightData.Tstops
                this.depFlightWrapper.totalPrice = flightData.totalPrice
                this.depFlightWrapper.Flightclass = depFlightSegments[0].Flightclass
                this.depFlightWrapper.flightNumber = depFlightSegments[0].flightNumber
                this.depFlightWrapper.flightDuration = flightData.totalFlightDuration
                this.depFlightWrapper.logo1 = flightData.AirlLogoBase + depFlightSegments[0].operatingAirLine.iata+'.png';
                this.depFlightWrapper.totalFlightDuration = flightData.totalFlightDuration
                this.depFlightWrapper.depFlightDuration = flightData.depFlightDuration
                this.depFlightWrapper.retFlightDuration = flightData.retFlightDuration
                this.depFlightWrapper.totalStopDuration = flightData.totalStopDuration
                this.depFlightWrapper.depStopDuration = flightData.depStopDuration
                this.depFlightWrapper.retStopDuration = flightData.retStopDuration
                this.depFlightWrapper.depStopCount = flightData.depStopCount
                this.depFlightWrapper.retStopCount = flightData.retStopCount
                this.depFlightWrapper.depStopStatus = flightData.depStopStatus
                this.depFlightWrapper.retStopStatus = flightData.retStopStatus
                this.depFlightWrapper.stopCount = flightData.stopCount
                this.depFlightWrapper.stopStatus = flightData.stopStatus



                for(let i = 0; i <= this.infoData.depStopCount; i++){
                    this.depFlightArr[i].departure = depFlightSegments[i].departureDate
                    this.depFlightArr[i].arrival = depFlightSegments[i].arrivalDate
                    this.depFlightArr[i].departureAirportName = depFlightSegments[i].departureAirport.name
                    this.depFlightArr[i].arrivalAirportName = depFlightSegments[i].arrivalAirport.name
                    this.depFlightArr[i].Airline = depFlightSegments[i].operatingAirLine.name
                    this.depFlightArr[i].from_iata = depFlightSegments[i].departureAirport.iata
                    this.depFlightArr[i].to_iata = depFlightSegments[i].arrivalAirport.iata
                    this.depFlightArr[i].stops = flightData.Tstops
                    this.depFlightArr[i].totalPrice = flightData.totalPrice
                    this.depFlightArr[i].Flightclass = depFlightSegments[i].Flightclass
                    this.depFlightArr[i].flightNumber = depFlightSegments[i].flightNumber
                    this.depFlightArr[i].flightDuration = depFlightSegments[i].flightDuration
                    this.depFlightArr[i].logo1 = flightData.AirlLogoBase + depFlightSegments[i].operatingAirLine.iata+'.png';
                    this.depFlightArr[i].totalFlightDuration = flightData.totalFlightDuration
                    this.depFlightArr[i].depFlightDuration = depFlightSegments[i].flightDuration
                    this.depFlightArr[i].totalStopDuration = flightData.totalStopDuration
                    this.depFlightArr[i].totalStopCount = flightData.stopCount
                    this.depFlightArr[i].totalStopStatus = flightData.stopStatus
                    this.depFlightArr[i].depStopDuration = flightData.depStopDuration
                    this.depFlightArr[i].depStopCount = flightData.depStopCount
                    this.depFlightArr[i].depSegmentStopDuration = depFlightSegments[i].flightDuration
                }

                // console.log('SSSSS', this.depFlightArr)


                if(typeof this.infoData.returnOptions !== 'undefined'){
                    for(let i = 0; i <= this.infoData.retStopCount; i++){
                        this.retFlightArr[i].departure = retFlightSegments[i].departureDate
                        this.retFlightArr[i].arrival = retFlightSegments[i].arrivalDate
                        this.retFlightArr[i].departureAirportName = retFlightSegments[i].departureAirport.name
                        this.retFlightArr[i].arrivalAirportName = retFlightSegments[i].arrivalAirport.name
                        this.retFlightArr[i].Airline = retFlightSegments[i].operatingAirLine.name
                        this.retFlightArr[i].from_iata = retFlightSegments[i].departureAirport.iata
                        this.retFlightArr[i].to_iata = retFlightSegments[i].arrivalAirport.iata
                        this.retFlightArr[i].stops = flightData.Tstops
                        this.retFlightArr[i].totalPrice = flightData.totalPrice
                        this.retFlightArr[i].Flightclass = retFlightSegments[i].Flightclass
                        this.retFlightArr[i].flightNumber = retFlightSegments[i].flightNumber
                        this.retFlightArr[i].flightDuration = flightData.totalFlightDuration
                        this.retFlightArr[i].logo1 = flightData.AirlLogoBase + retFlightSegments[i].operatingAirLine.iata+'.png';
                        this.retFlightArr[i].totalFlightDuration = flightData.totalFlightDuration
                        this.retFlightArr[i].retFlightDuration = retFlightSegments[i].flightDuration
                        this.retFlightArr[i].totalStopDuration = flightData.totalStopDuration
                        this.retFlightArr[i].totalStopCount = flightData.stopCount
                        this.retFlightArr[i].retStopDuration = flightData.retStopDuration
                        this.retFlightArr[i].retStopCount = flightData.retStopCount
                        this.retFlightArr[i].retSegmentStopDuration = retFlightSegments[i].flightDuration
                    }
                }


                // ###### Multi Airline Detect ######
                this.depFlightWrapper.stops = flightData.Tstops
                var flightAirline = [];
                for(var i=0; i < depFlightSegments.length; i++){
                    flightAirline.push(depFlightSegments[i].operatingAirLine.iata);
                }
                if(this.depFlightWrapper.stops != 'Nonstop'){
                    for(let i = 0; i < depFlightSegments.length; i++){
                        // console.log('Enter multi airline detecter');
                        for(let j = 0; j < depFlightSegments.length; j++){
                            if (flightAirline[i] !== flightAirline[j]){
                                this.multiAirline = true;
                            }
                        }
                    }
                } else{
                    this.multiAirline = false;
                }
                // for Round Trip Flight
                if(this.multiAirline){
                    this.depFlightWrapper.Airlogo = "https://www.gstatic.com/flights/airline_logos/70px/multi.png";
                } else{
                    this.depFlightWrapper.Airlogo = flightData.AirlLogoBase + depFlightSegments[0].operatingAirLine.iata+'.png'
                }
                // ###### /Multi Airline Detect ######





                // this.Airlogo = this.infoData.AirlLogoBase+this.infoData.flightSegments[0].operatingAirLine.iata+'.png'
                this.departure = flightData.depDate
                // alert(flightData.depDate)

                this.arrival = flightData.arrDate
                this.departureAirportName = flightData.depAirport
                this.arrivalAirportName = flightData.arrAirport
                this.Airline = depFlightSegments[0].operatingAirLine.name
                this.from_iata = flightData.depIata
                this.to_iata = flightData.arrIata
                this.stops = flightData.Tstops
                this.totalPrice = flightData.totalPrice
                this.Flightclass = depFlightSegments[0].Flightclass
                this.flightNumber = depFlightSegments[0].flightNumber
                this.flightDuration = flightData.totalFlightDuration
                this.logo1 = flightData.AirlLogoBase + depFlightSegments[0].operatingAirLine.iata+'.png';
                this.totalFlightDuration = flightData.totalFlightDuration
                this.depFlightDuration = flightData.depFlightDuration
                this.totalStopDuration = flightData.totalStopDuration
                this.depStopDuration = flightData.depStopDuration


                // Initilize Return Trip in Package Trip
                // if('returnFlightSegments' in this.infoData){
                if(typeof retFlightSegments[0] !== 'undefined'){
                    this.returnStatus = true;
                    this.returnDeparture = flightData.returnDepDate
                    this.returnArrival = flightData.returnArrDate
                    this.returnDepartureAirport = flightData.returnDepAirport
                    this.returnArrivalAirport = flightData.returnArrAirport;
                    this.returnDepartureIata = flightData.returnDepIata
                    this.returnArrivalIata = flightData.returnArrIata;
                    this.returnStops = flightData.retStopDuration
                    this.returnFlightclass = retFlightSegments[0].Flightclass;
                    this.returnFlightNumber = retFlightSegments[0].flightNumber;
                    this.retFlightDuration = flightData.retFlightDuration;
                    this.retStopDuration = flightData.retStopDuration;
                }


                // if(this.returnStatus){
                //     this.boxHeight = '100px';
                // } else{
                //     this.boxHeight = '87px';
                // }
                this.boxHeight = '100px';


            },
            reserveIt:function () {
                var item = this.infoData;
                alert(item.id);
                alert(item.name);
            }
        },

        filters:{
            getTheHour: function (Val) {
                return moment(Val).format('h:mm A')
            },
            openDeparure: function (val) {
                return moment(val).format('dd MMM YY')
            },

            stopDuration(time){
                let newTime = time;
                if(time != null){
                    if (time.indexOf(":") > -1) {
                        time = time.split(":");
                        newTime = parseInt(time[1]) + "h " + parseInt(time[2]) + 'm'
                    } else {
                        newTime = parseInt(time) + "h";
                    }
                }

                return newTime;
            },

            stopCount(val){
                if(val == '1Stop')
                    return '1 Stop';
                if(val == '2Stops')
                    return '2 Stops';
                if(val == '3Stops')
                    return '3 Stops';
                if(val == '4Stops')
                    return '4 Stops';
                if(val == 'Nonstop')
                    return 'Nonstop';
            }
        },

        watch: {
            infoData: function (newVal, oldVal) {
                this.loadInfo()
                // console.log('Prop changed: ', newVal, ' | was: ', oldVal)
            }
        },

        computed: {
            iStops(){
                return this.stops;
            }
        }
    }
</script>