<template>
    <v-app>
        <v-layout column>
            <!--<v-layout justify-center align-center class="text-md-center" v-if="((depCountry=='Iran' && arrCountry=='Iran') && (this.theFrom=='IKA' || this.theTo=='IKA'))">-->
                <!--<v-card class="py-3 d-flex justify-center align-center px-2 iran-attention-card">-->
                    <!--<img src="/pics/chart.png" alt="" class="mr-2" width="25">-->
                    <!--<v-flex>-->
                        <!--Attention! <span class="attention-text">. All domestic flights from/to Tehran, depart/arrive from/to Mehrabad airport (THR). IKA airport operates only for international flights.</span>-->
                    <!--</v-flex>-->
                <!--</v-card>-->
            <!--</v-layout>-->

            <v-flex class="text-md-center noflight-section">
                <v-layout justify-space-between class="not-flight-content-wrapper">
                    <v-flex align-center justify-center column fill-height>
                        <h2 class="text-md-center text-xs-center">No flights found</h2>
                        <p class="text-md-center text-xs-center mt-3">There are no flights available on your chosen dates. Try changing the dates of your search.</p>
                        <v-layout justify-center class="mt-4">
                            <v-btn color="#f9ca42" class="btn-notflight-navigator" @click="beforeDayUrl">
                                <!--<v-icon>arrow_left</v-icon>-->
                                Previous Day
                            </v-btn>
                            <v-btn color="#f9ca42" class="btn-notflight-navigator" @click="afterDayUrl">
                                Next Day
                                <!--<v-icon>arrow_right</v-icon>-->
                            </v-btn>
                        </v-layout>
                    </v-flex>
                </v-layout>

                <img class="not-flight-img mt-4" src="https://www.gstatic.com/flights/app/error_white_1080.png" alt="Apochi" width="650">
            </v-flex>
        </v-layout>
    </v-app>
</template>

<style>

    .btn-notflight-navigator{
        width: 150px !important;
    }

    .attention-text{
        color: #546E7A;
    }

    .noflight-section{
        margin-top: 40px;
    }

    @media (max-width: 767px) {
        .not-flight-img{
            width: 100%;
        }

        .not-flight-content-wrapper{
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .noflight-section{
            margin-top: 0;
        }

    }

</style>

<script>
    import moment from 'moment'

    export default {
        data(){
            return{
                url: {
                    path: '',
                    query: ''
                },
                urlDay: '',
                afterDay: '',
                beforeDay: '',
                newUrl: '',
                theFrom:'',
                theTo:'',
            }
        },

        props:[
            'depCountry',
            'arrCountry'
        ],

        mounted(){
            // console.log('Url is: ', this.$route.params.travel.split('-')[0])
            // this.url.path = this.$route.path;
            // this.url.query = this.$route.query;
            // this.urlDay = moment(this.url.query.departing);
            // this.afterDay = this.urlDay.add(1, 'days');
            // this.beforeDay = this.urlDay.subtract(1, 'days');
            // this.url.query.departing = this.afterDay._i;
            // console.log('After Day: ', this.convert(this.afterDay._d));
            // this.$emit('noFlightEvent');

            // console.log('Dep County: ', this.depCountry)
            // console.log('ret County: ', this.arrCountry)
            this.theFrom = this.$route.params.travel.split('-')[0]
            this.theTo = this.$route.params.travel.split('-')[1]
        },

        methods:{
             convert(str) {
                var date = new Date(str),
                    mnth = ("0" + (date.getMonth()+1)).slice(-2),
                    day  = ("0" + date.getDate()).slice(-2);
                return [ date.getFullYear(), mnth, day ].join("-");
            },

            // After Day Button
            afterDayUrl(){
                let newUrl = '';
                this.url.path = this.$route.path;
                this.url.query = this.$route.query;
                this.urlDay = moment(this.url.query.departing);
                this.afterDay = this.urlDay.add(1, 'days');
                this.afterDay = this.convert(this.afterDay._d);
                this.url.query.departing = this.afterDay;

                // this.newUrl = this.url.path + '?' + 'departing=' + this.afterDay + '&adult=' + this.url.query.adult + '&child=' + this.url.query.child + '&infant=' + this.url.query.infant + '&step=' + this.url.query.step + '&mode=' + this.url.query.mode + '/';
                this.newUrl = this.url.path + '?' + 'departing=' + this.afterDay + '&adult=' + this.url.query.adult + '&child=' + this.url.query.child + '&infant=' + this.url.query.infant + '&step=' + this.url.query.step + '&mode=' + this.url.query.mode;

                let iUrl = this.newUrl;
                // alert(iUrl)
                console.log('URL 1: ', this.newUrl)
                // this.$router.push(this.createUrl());
                // this.$router.push(iUrl);
                window.location.href = iUrl;
                // this.$router.push('/search/THR-MHD?departing=2019-05-25&adult=1&child=0&infant=0&step=1&mode=oneway');
                console.log('URL 2: ', this.$route)
            },

            // Before Day Button
            beforeDayUrl(){
                let newUrl = '';
                this.url.path = this.$route.path;
                this.url.query = this.$route.query;
                this.urlDay = moment(this.url.query.departing);
                this.beforeDay = this.urlDay.subtract(1, 'days');
                this.beforeDay = this.convert(this.beforeDay._d);
                this.url.query.departing = this.beforeDay;

                // this.newUrl = this.url.path + '?' + 'departing=' + this.beforeDay + '&adult=' + this.url.query.adult + '&child=' + this.url.query.child + '&infant=' + this.url.query.infant + '&step=' + this.url.query.step + '&mode=' + this.url.query.mode + '/';
                this.newUrl = this.url.path + '?' + 'departing=' + this.beforeDay + '&adult=' + this.url.query.adult + '&child=' + this.url.query.child + '&infant=' + this.url.query.infant + '&step=' + this.url.query.step + '&mode=' + this.url.query.mode;
                let iUrl = this.newUrl;
                // alert(iUrl)
                console.log('URL 1: ', this.newUrl)
                // this.$router.push(this.createUrl());
                // this.$router.push(iUrl);
                window.location.href = iUrl;
                // this.$router.push('/search/THR-MHD?departing=2019-05-25&adult=1&child=0&infant=0&step=1&mode=oneway');
                console.log('URL 2: ', this.$route)
            },

            // Create Url
            createUrl(){
                return this.newUrl = this.url.path + '?' + 'departing=' + this.beforeDay + '&adult=' + this.url.query.adult + '&child=' + this.url.query.child + '&infant=' + this.url.query.infant + '&step=' + this.url.query.step + '&mode=' + this.url.query.mode;
            },
        },

        watch: {
            // Vue Router Requirement
            //######  Warning  ######
            $route(){
                this.$router.go();
            },
        }
    }
</script>