<template>
    <div id="SearchContent">
        <v-progress-linear class="loading-progress-bar" :indeterminate="true" color="#3f6791" v-if="loading" background-opacity=".5"></v-progress-linear>
        <span>
            <v-snackbar
                    v-model="snackbar"
                    :bottom="y === 'bottom'"
                    :left="x === 'left'"
                    :multi-line="mode === 'multi-line'"
                    :right="x === 'right'"
                    :timeout="timeout"
                    :top="y === 'top'"
                    :vertical="mode === 'vertical'"
            >
                {{ snackbarText }}
                <v-btn
                        color="pink"
                        flat
                        @click="snackbar = false"
                >
                    Close
                </v-btn>
            </v-snackbar>

            <!--######  Search Box Section  ######-->
            <!--<v-container fluid>-->
                <!--<v-layout mt-5 id="search-page-search-box-wrapper">-->
                    <!--&lt;!&ndash;<HomeSearchBox v-on:do-Search="goToSearchResult"></HomeSearchBox>&ndash;&gt;-->
                    <!--<SERPSearchBox v-on:do-Search="goToSearchResult"></SERPSearchBox>-->
                <!--</v-layout>-->
                <SERPSearchBox v-on:do-Search="goToSearchResult"></SERPSearchBox>
            <!--</v-container>-->
            <!--######  /Search Box Section  ######-->

            <v-container style="margin-top:65px" v-if="((this.depCountry=='Iran' && this.arrCountry=='Iran') && (this.from_city_iata=='IKA' || this.to_city_iata=='IKA'))">
                <v-flex x11>
               <v-layout justify-center align-center class="text-md-center" >
                <v-card class="py-3 d-flex justify-center align-center px-2 iran-attention-card">
                    <div class="attention-image-wrapper">

                    </div>
                    <img src="/pics/chart.png" alt="" class="mr-2 attention-image-img" width="25" height="25">
                    <v-flex pl-3 class="attention-text-wrapper">
                        <strong>Attention! </strong><span class="attention-text"> All domestic flights from/to Tehran, depart/arrive from/to Mehrabad airport (THR). IKA airport operates only for international flights.</span>
                    </v-flex>
                </v-card>
            </v-layout>

                </v-flex>
            </v-container>

            <!--######  Stepper Section  ######-->
            <v-container xs10 offset-xs1 style="margin-top: 40px;" v-if="!responsiveStatus && !notFoundedAnyFlights">
                <v-flex xs10 offset-xs1>
                    <Stepper :mode="stepperMode" :state="stepperState"></Stepper>
                </v-flex>
            </v-container>

            <v-container xs12 style="margin-top: 40px;" v-if="responsiveStatus && !notFoundedAnyFlights">
                <v-flex xs12>
                    <Stepper :mode="stepperMode" :state="stepperState"></Stepper>
                </v-flex>
            </v-container>
            <!--######  /Stepper Section  ######-->




            <!-- Filter Box for < 768 px Width -->
            <v-flex v-if="responsiveStatus && searchStatus == 1" d-flex justify-center>

                <!-- Airline Filter (Responsive) -->
                <v-btn
                        color="info"
                        class="iBtn-responsive"
                        @click="filterExpandAirline"
                >
                    Airline
                </v-btn>
                <!-- /Airline Filter (Responsive) -->

                <!-- Stop Filter (Responsive) -->
                <v-btn
                        color="info"
                        class="iBtn-responsive"
                        @click="filterExpandStop"
                >
                    Stop
                </v-btn>
                <!-- /Stop Filter (Responsive) -->

                <!-- Price Filter (Responsive) -->
                <v-btn
                        color="info"
                        class="iBtn-responsive"
                        @click="filterExpandPrice"
                >
                    Price
                </v-btn>
                <!-- /Price Filter (Responsive) -->

                <!-- Time Filter (Responsive) -->
                <v-btn
                        color="info"
                        class="iBtn-responsive"
                        @click="filterExpandTime"
                >
                    Time
                </v-btn>
                <!-- /Time Filter (Responsive) -->

            </v-flex pt-0>

            <v-flex v-if="filterExpand" transition="fade-transition">
                <v-flex class="filter-responsive-modal" mx-1 my-3>
                    <!-- Airline Filter Exapnded (Responsive) -->
                    <span v-if="filterExpandAirlineStatus" class="pa-3">
                        <v-flex px-3 py-2 style="width: 100%">
                            <v-select
                                    :items="airlines"
                                    v-model="airline"
                                    label="Airline"
                                    outline
                                    hide-details
                                    id="airline-filter"
                            ></v-select>
                        </v-flex>
                    </span>
                    <!-- /Airline Filter Exapnded (Responsive) -->

                    <!-- Stop Filter Exapnded (Responsive) -->
                    <span v-if="filterExpandStopStatus" class="pa-3">
                        <v-flex px-3 py-2 style="width: 100%">
                            <v-subheader>Stop</v-subheader>
                            <v-slider
                                    v-model="selectedStop"
                                    :tick-labels="stopsArr"
                                    :value="stopsArr"
                                    min="0"
                                    max="2"
                                    color="#0282ef"
                            ></v-slider>
                        </v-flex>
                    </span>
                    <!-- /Stop Filter Exapnded (Responsive) -->

                    <!-- Price Filter Expanded (Responsive) -->
                    <span v-if="filterExpandPriceStatus">
                        <!-- Price Slider Sort -->
                        <v-flex px-3 py-2 style="width: 100%">
                            <!--<v-range-slider-->
                                    <!--v-model="price"-->
                                    <!--:min="minPrice"-->
                                    <!--:max="maxPrice"-->
                                    <!--thumb-label="always"-->
                            <!--&gt;-->
                            <!--</v-range-slider>-->

                            <v-subheader>Price</v-subheader>
                            <v-range-slider
                                    v-model="price"
                                    :min="minPrice"
                                    :max="maxPrice"
                                    :hint="`€${price[0]} - €${price[1]}`"
                                    persistent-hint
                                    color="#0282ef"
                            >
                            </v-range-slider>
                        </v-flex>

                        <v-flex d-flex justify-center align-center>
                            <v-btn
                                    color="blue-grey"
                                    @click="ascPriceSort"
                                    dark
                            >
                                Ascending Sort
                            </v-btn>

                            <v-btn
                                    color="blue-grey"
                                    @click="descPriceSort"
                                    dark
                            >
                                Descending Sort
                            </v-btn>
                        </v-flex>
                        <!-- /Price Slider Sort -->
                    </span>
                    <!-- /Price Filter Expanded (Responsive) -->

                    <!-- Time Filter Expanded (Responsive) -->
                    <span v-if="filterExpandTimeStatus">
                        <!--<v-range-slider-->
                                <!--v-model="time"-->
                                <!--always-dirty-->
                                <!--min="0"-->
                                <!--max="24"-->
                                <!--thumb-label="always"-->
                                <!--class="pa-3 pt-4"-->
                        <!--&gt;-->
                            <!--<template-->
                                    <!--slot-scope="props"-->
                            <!--&gt;-->
                                  <!--<span>-->
                                    <!--{{ timeMethod(props.value) }}-->
                                  <!--</span>-->
                            <!--</template>-->
                        <!--</v-range-slider>-->


                        <v-flex px-3 py-2 style="width: 100%">
                            <v-subheader>Time</v-subheader>
                            <v-range-slider
                                    v-model="time"
                                    always-dirty
                                    min="0"
                                    max="23"
                                    :hint="`${moment().format('ddd')} ${moment(time[0], 'hh A').format('HH:00 A')} - ${moment(time[1], 'hh A').format('HH:59 A')}`"
                                    persistent-hint
                                    color="#0282ef"
                            >
                                <template
                                        slot-scope="props"
                                >
                                  <span>
                                    {{ timeMethod(props.value) }}
                                  </span>
                                </template>
                            </v-range-slider>
                        </v-flex>
                    </span>
                    <!-- /Time Filter Expanded (Responsive) -->

                </v-flex>
            </v-flex>

            <!-- /Filter Box for < 768 px Width -->



            <v-container pt-0>


                <!--######  Filter Section  ######-->
                <v-layout row mb-3 v-if="!disableMenu && !loading">

                    <!-- Filter Box for >= 768px Width -->
                    <v-flex style="background: rgb(240, 240, 240); box-shadow: none !important; border-radius: 5px; margin-bottom: 30px;" xs10 offset-xs1 elevation-2 pa-4 v-if="!responsiveStatus && searchStatus==1">
                        <v-layout row>

                            <!-- Airline Filter -->
                            <!--<v-flex xs4 pa-1>-->
                                <!--<v-select-->
                                        <!--:items="airlines"-->
                                        <!--v-model="airline"-->
                                        <!--label="Airline"-->
                                        <!--outline-->
                                        <!--hide-details-->
                                        <!--id="airline-filter"-->
                                <!--&gt;</v-select>-->
                            <!--</v-flex>-->
                            <!-- /Airline Filter -->

                            <!-- Price Filter -->
                            <v-flex xs3 pa-1>
                                <!-- Price Slider Sort -->
                                <v-flex px-3 py-2 style="width: 100%;" v-if="priceRangeStatus">
                                    <v-subheader>Price</v-subheader>
                                    <v-range-slider
                                            v-model="price"
                                            :min="minPrice"
                                            :max="maxPrice"
                                            :hint="`€${price[0]} - €${price[1]}`"
                                            persistent-hint
                                            color="#0282ef"
                                    >
                                    </v-range-slider>
                                </v-flex>
                            </v-flex>
                            <!-- /Price Filter -->

                            <!-- Time Filter -->
                            <v-flex xs3 pa-1>
                                <v-flex px-3 py-2>
                                    <v-subheader>Time</v-subheader>
                                    <v-range-slider
                                            v-model="time"
                                            always-dirty
                                            min="0"
                                            max="23"
                                            :hint="this.timeRange"
                                            persistent-hint
                                            color="#0282ef"
                                    >
                                        <template
                                                slot-scope="props"
                                        >
                                          <span>
                                            {{ timeMethod(props.value) }}
                                          </span>
                                        </template>
                                    </v-range-slider>
                                </v-flex>
                            </v-flex>
                            <!-- /Time Filter -->

                            <!-- Stop Filter -->
                            <v-flex xs3 pa-1>
                                <v-flex px-3 py-2>
                                    <v-subheader>Stop</v-subheader>
                                    <!--<v-range-slider-->
                                            <!--:tick-labels="stopsArr"-->
                                            <!--value="1"-->
                                            <!--min="0"-->
                                            <!--max="2"-->
                                            <!--color="#0282ef"-->
                                    <!--&gt;-->
                                        <!--<template-->


                                        <!--&gt;-->
                                        <!--</template>-->
                                      <!--</v-range-slider>-->

                                    <v-flex xs12>
                                        <v-slider
                                                v-model="selectedStop"
                                                :tick-labels="stopsArr"
                                                :value="stopsArr"
                                                min="0"
                                                max="2"
                                                color="#0282ef"
                                        ></v-slider>
                                    </v-flex>
                                </v-flex>
                            </v-flex>
                            <!-- /Stop Filter -->

                            <!-- Sort Filter -->
                            <v-flex xs3 pa-1>
                                <v-flex px-3 py-2>
                                    <v-select
                                            v-model="selectSortArr"
                                            :items="sortArr"
                                            item-text="label"
                                            item-value="value"
                                            label="Sort By"
                                            persistent-hint
                                            return-object
                                            single-line

                                            height="20"
                                            class="pt-3"
                                    ></v-select>
                                </v-flex>
                            </v-flex>
                            <!-- /Sort Filter -->





                            <!-- Stops Filter -->
                            <!--<v-flex xs4 pa-1>-->
                                <!--<v-select-->
                                        <!--:items="stopType"-->
                                        <!--v-model="stop"-->
                                        <!--label="Stops"-->
                                        <!--outline-->
                                        <!--hide-details-->
                                <!--&gt;</v-select>-->
                            <!--</v-flex>-->
                            <!-- /Stops Filter -->

                            <!-- Price Filter -->
                            <!--<v-flex xs2 pa-1 d-flex align-center justify-center>-->
                                <!--<div class="text-xs-center">-->
                                    <!--<v-dialog-->
                                            <!--v-model="dialogPrice"-->
                                            <!--width="500"-->
                                    <!--&gt;-->
                                        <!--<v-btn-->
                                                <!--slot="activator"-->
                                                <!--color="blue-grey"-->
                                                <!--class="filter-btn"-->
                                        <!--&gt;-->
                                            <!--Price-->
                                        <!--</v-btn>-->

                                        <!--<v-card>-->
                                            <!--<v-card-title-->
                                                    <!--class="headline grey lighten-2"-->
                                                    <!--primary-title-->
                                            <!--&gt;-->
                                                <!--Price Filter-->
                                            <!--</v-card-title>-->

                                            <!--<v-card-text>-->
                                                <!--<v-layout column>-->
                                                    <!--<v-subheader class="pl-2">Price Range</v-subheader>-->
                                                    <!--&lt;!&ndash; Price Slider Sort &ndash;&gt;-->
                                                    <!--<v-flex px-3 py-2 style="width: 100%;" v-if="priceRangeStatus">-->
                                                        <!--<v-range-slider-->
                                                                <!--v-model="price"-->
                                                                <!--:min="minPrice"-->
                                                                <!--:max="maxPrice"-->
                                                                <!--thumb-label="always"-->
                                                        <!--&gt;-->
                                                        <!--</v-range-slider>-->
                                                    <!--</v-flex>-->
                                                    <!--&lt;!&ndash; /Price Slider Sort &ndash;&gt;-->

                                                    <!--<v-flex d-flex justify-center align-center>-->
                                                        <!--<v-btn-->
                                                                <!--color="blue-grey"-->
                                                                <!--@click="ascPriceSort"-->
                                                                <!--dark-->
                                                        <!--&gt;-->
                                                            <!--Ascending Sort-->
                                                        <!--</v-btn>-->

                                                        <!--<v-btn-->
                                                            <!--color="blue-grey"-->
                                                            <!--@click="descPriceSort"-->
                                                            <!--dark-->
                                                        <!--&gt;-->
                                                            <!--Descending Sort-->
                                                        <!--</v-btn>-->
                                                    <!--</v-flex>-->

                                                <!--</v-layout>-->
                                            <!--</v-card-text>-->

                                            <!--<v-divider></v-divider>-->

                                            <!--<v-card-actions>-->
                                                <!--<v-spacer></v-spacer>-->
                                                <!--<v-btn-->
                                                        <!--color="primary"-->
                                                        <!--flat-->
                                                        <!--@click="dialogPrice = false"-->
                                                <!--&gt;-->
                                                    <!--Done-->
                                                <!--</v-btn>-->
                                            <!--</v-card-actions>-->
                                        <!--</v-card>-->
                                    <!--</v-dialog>-->
                                <!--</div>-->
                            <!--</v-flex>-->
                            <!-- /Price Filter -->

                            <!-- Time Filter -->
                            <!--<v-flex xs2 pa-1 d-flex align-center justify-center>-->
                                <!--<div class="text-xs-center">-->
                                    <!--<v-dialog-->
                                            <!--v-model="dialogTime"-->
                                            <!--width="500"-->
                                    <!--&gt;-->
                                        <!--<v-btn-->
                                                <!--slot="activator"-->
                                                <!--color="blue-grey"-->
                                                <!--class="filter-btn"-->
                                        <!--&gt;-->
                                            <!--Time-->
                                        <!--</v-btn>-->

                                        <!--<v-card>-->
                                            <!--<v-card-title-->
                                                    <!--class="headline grey lighten-2"-->
                                                    <!--primary-title-->
                                            <!--&gt;-->
                                                <!--Time Filter-->
                                            <!--</v-card-title>-->

                                            <!--<v-card-text>-->
                                                <!--<v-layout px-3 column>-->
                                                    <!--<v-subheader class="pl-0">Time Range</v-subheader>-->
                                                    <!--<v-flex pt-1>-->
                                                        <!--<v-range-slider-->
                                                                <!--v-model="time"-->
                                                                <!--always-dirty-->
                                                                <!--min="0"-->
                                                                <!--max="24"-->
                                                                <!--thumb-label="always"-->
                                                        <!--&gt;-->
                                                            <!--<template-->
                                                                    <!--slot-scope="props"-->
                                                            <!--&gt;-->
                                                              <!--<span>-->
                                                                <!--{{ timeMethod(props.value) }}-->
                                                              <!--</span>-->
                                                            <!--</template>-->
                                                        <!--</v-range-slider>-->
                                                    <!--</v-flex>-->
                                                <!--</v-layout>-->
                                            <!--</v-card-text>-->

                                            <!--<v-divider></v-divider>-->

                                            <!--<v-card-actions>-->
                                                <!--<v-spacer></v-spacer>-->
                                                <!--<v-btn-->
                                                        <!--color="primary"-->
                                                        <!--flat-->
                                                        <!--@click="dialogTime = false"-->
                                                <!--&gt;-->
                                                    <!--Done-->
                                                <!--</v-btn>-->
                                            <!--</v-card-actions>-->
                                        <!--</v-card>-->
                                    <!--</v-dialog>-->
                                <!--</div>-->
                            <!--</v-flex>-->
                            <!-- /Time Filter -->

                        </v-layout>
                    </v-flex>
                    <!-- /Filter Box for >= 768px Width -->

                </v-layout>
                <!--######  /Filter Section  ######-->



                <!--######  Selected Filter Section  ######-->
                <v-layout mt-3 mb-5 v-if="filterWrapperStatus && !loading && !disableMenu && searchStatus==1 && false">
                    <v-flex xs10 offset-xs1>
                        <v-card>
                            <v-flex px-2 pt-2>
                                <h3>Filters selected:</h3>
                            </v-flex>
                            <v-flex pa-2>
                                <v-btn outline color="secondary" @click="resetAirline" v-if="airline != '' && airline != 'All'">Airline</v-btn>
                                <v-btn outline color="secondary" @click="resetStop" v-if="stop != ''">Stop</v-btn>
                                <v-btn outline color="secondary" @click="resetPrice" v-if="price[0] != minPrice || price[1] != maxPrice">Price</v-btn>
                                <v-btn outline color="secondary" @click="resetTime" v-if="time[0] != 0 || time[1] != 24">Time</v-btn>
                            </v-flex>
                        </v-card>
                    </v-flex>
                </v-layout>
                <!--######  /Selected Filter Section  ######-->

                <!--######  Countdown Section  ######-->
                <v-layout mt-3 mb-5 class="count-down-timer">
                    <v-flex xs1>

                    </v-flex>
                    <v-flex xs10 offest-xs1>
                        <v-card class="pa-3 count-down-timer-card">
                            <h2 id="count-down-time" class="mb-0 text-xs-center font-weight-light">00:00</h2>
                        </v-card>
                    </v-flex>
                </v-layout>
                <!--######  /Countdown Section  ######-->


                <!--<v-layout>-->
                    <!--<v-flex xs10 xs-offset1>-->

                    <!--</v-flex>-->
                <!--</v-layout>-->

                <v-layout row v-if="loading">
                    <v-flex sm10 offset-sm1 mb-4>
                        <LoadingFilter></LoadingFilter>
                    </v-flex>
                </v-layout>

                <!-- Roundtrip Loading -->
                <v-layout row v-if="stepperMode == 'roundtrip' && loading">
                    <v-flex sm10 offset-sm1>
                        <LoadingRoundtrip v-if="loading && stepperMode == 'roundtrip'"></LoadingRoundtrip>
                    </v-flex>
                </v-layout>
                <!-- Roundtrip Loading -->

                <!-- Attention for Roundtrip -->
                <v-layout row v-if="stepperMode == 'roundtrip' && !loading">
                    <v-flex sm10 offset-sm1>
                        <v-card class="py-3 d-flex justify-center align-center px-2 iran-attention-card" style="position: relative; margin-bottom: 10px; padding-left: 15px; position: relative; margin-bottom: 10px; padding-left: 15px !important; border-radius: 8px; box-shadow: 4px 5px 6px rgba(0, 0, 0, .1); border: 1px solid rgba(0, 0, 0, .1);">
                            <v-flex class="select-departure-return-trip-attention">
                                <h4 v-if="stepperMode == 'roundtrip' && stepperState == 1"><i class="material-icons">flight_takeoff</i> Select your departure to {{ this.city }} <span class="select-departure-return-trip-attention__date">{{ moment(this.flights[0].depDate).format('ddd, MMM D') }}</span></h4>
                                <h4 v-if="stepperMode == 'roundtrip' && stepperState == 2"><i class="material-icons">flight_land</i> Select your return to {{ this.city }} <span class="select-departure-return-trip-attention__date">{{ moment(this.flights[0].depDate).format('ddd, MMM D') }}</span></h4>
                            </v-flex>
                        </v-card>
                    </v-flex>
                </v-layout>
                <!-- Attention for Roundtrip -->


                <!--######  Flight Cards Section  ######-->
                <v-layout row pb-4>
                    <v-flex sm10 offset-sm1>
                        <div id="flight-cards-wrapper">
                            <v-flex xs12>

                                <!--<v-flex style="text-transform: uppercase; background: #dedede; margin: 17px 0; padding: 5px; width: -moz-max-content; border-radius: 5px;" v-if="stepperMode == 'roundtrip'">-->
                                    <!--<h2 style="text-transform: uppercase;" v-if="stepperMode == 'roundtrip' && stepperState == 1">select departure flight</h2>-->
                                    <!--<h2 style="text-transform: uppercase;" v-if="stepperMode == 'roundtrip' && stepperState == 2">select return flight</h2>-->
                                <!--</v-flex>-->

                                <!-- Flight Card -->

                                <NotFlight v-if="notFoundedAnyFlights" v-on:noFlightEvent="DisableMenus" :dep-country="depCountry" :arr-country="arrCountry"></NotFlight>

                                <Loading v-if="loading"></Loading>

                                <!--<FlightCard v-for="item in flights" :infoData="item" :key="item.id" v-if="!responsiveStatus && !loading && parseInt(item.stopCount) == 2"></FlightCard>-->
                                <FlightCard v-for="item in flights" :infoData="item" :key="item.id" :minPrice="minPrice" :ikaMode="ikaMode" v-if="!responsiveStatus && !loading && item.Tstops != '3Stops' && item.Tstops != '4Stops' "></FlightCard>

                                <FlightCardResponsive v-for="item in flights" :infoData="item" :key="item.id" v-if="responsiveStatus && !loading && item.Tstops != '3Stops' && item.Tstops != '4Stops' "></FlightCardResponsive>
                                <!-- /Flight Card -->

                                <!-- Select Loading -->
                                <!--<img src="https://cdn-images-1.medium.com/max/1600/0*cWpsf9D3g346Va20.gif" alt="">-->

                            </v-flex>
                            <v-flex xs12>

                            </v-flex>
                        </div>
                    </v-flex>
                </v-layout>
                <!--######  /Flight Cards Section  ######-->


            </v-container>
        </span>


    </div>
</template>


<style>
    .filter-btn{
        color: #fff !important;
    }

    /*
        Responsive
     */
    .filter-responsive-modal{
        background: #fff;
        padding: 5px;
        border: 1px solid #dedede;
    }

    .iBtn-responsive{
        margin: 2px;
    }

    .desWrapper{
        margin-top: 70px;
        margin-bottom: 0px !important;
    }

    #HomeSearchBox{
        /*margin-top: 0;*/
    }

    #search-page-search-box-wrapper{
        width: 100%;
        margin-top: 55vh !important;
    }

    #search-page-search-box-wrapper > div{
        width: 100%;
    }

    .search-page-search-box-outer{
        background: #10355c;
        padding: 10px !important;
    }

    @media (max-width: 767px) {
        .desWrapper{
            margin-bottom: 15px !important;
        }

        .choose-title-span{
            font-size: 15px;
        }

        .select-departure-return-trip-attention h4{
            flex-direction: column !important;
            line-height: 27px;
        }

        .loading-progress-bar{
            top: 42px !important;
        }
    }

    .swal2-container.swal2-shown{
        font-family: Roboto;
        z-index: 9999;
    }

    .btn-search:before{
        background: #00355f;
    }

    .count-down-timer{
        position: sticky;
        top: 70px;
        z-index: 7;
    }

    #count-down-time{
        letter-spacing: 2px;
    }

    .count-down-timer-card{
        background: linear-gradient(to right, #607D8B, #cfd8dc);
        color: #fff !important;
    }

    .v-navigation-drawer--open{
        z-index: 8;
    }

    .v-slider__ticks > span{
        font-size: 13px;
    }

    .v-input--slider{
        margin-top: 0;
    }

    .theme--light.v-subheader{
        padding: 0;
        height: auto;
        margin-left: -7px;
        font-size: 16px;
        color: #2b4051;
    }

    .v-input__slot{
        margin-bottom: 0 !important;
    }

    .swal2-image{
        filter: grayscale(1);
    }

    .ika-mode__text{
        color: red;
    }

    danger-icon-ika-mode{
        position: relative;
        bottom: -4px;
        font-size: 19px;
    }

    .select-departure-return-trip-attention h4{
        font-size: 18px;
        font-weight: 400;
        display: flex;
        flex-direction: row;
        align-items: center;
    }

    .select-departure-return-trip-attention i{
        padding-right: 8px;
    }

    .select-departure-return-trip-attention__date{
        font-size: 15px;
        color: rgba(0, 0, 0, 0.56);
        position: relative;
        top: 2px;
        left: 6px;
    }

    .loading-progress-bar{
        position: fixed;
        top: 50px;
        z-index: 99999;
    }

    .attention-image-wrapper{
        width: 25px;
        height: 25px;
        border-radius: 50% !important;
        border: 1px solid #4285F4;
        animation: 2s infinite attention;
        position: absolute;
        left: 20px;
    }

    .attention-image-img{
        width: 25px !important;
        height: 25px !important;
        position: absolute;
        left: 20px;
    }

    @keyframes attention {
        from{
            transform: scale(1);
        }

        to{
            transform: scale(1.5);
        }
    }

    .iran-attention-card{
        padding-left: 20px !important;
        padding-right: 20px !important;
        position: relative;
        top: 0;
    }

    @media screen and (max-width: 768px) {
        .attention-text-wrapper{
            padding-left: 40px !important;
        }
    }
</style>

<script>
    import axios from 'axios'
    import moment from 'moment'
    import lodash from 'lodash'
    import Swal from 'sweetalert2'

    import FlightCard from './FlightCard'
    import FlightCardResponsive from './FlightCardResponsive'
    import NotFlight from './NotFlight'
    import LoadingRoundtrip from './LoadingRoundtrip'
    import LoadingFilter from './LoadingFilter'
    // import HomeSearchBox from '../Home/HomeSearchBox'
    import SERPSearchBox from './SERPSearchBox'
    import Loading from './Loading'
    import Stepper from './Stepper'

    var _ =  require('lodash')

    export default {
        components: {
            FlightCard,
            FlightCardResponsive,
            Loading,
            LoadingRoundtrip,
            LoadingFilter,
            // HomeSearchBox,
            SERPSearchBox,
            NotFlight,
            Stepper
        },


        data: () => ({

            timeRange : "00:00 AM - 23:59 PM",

            // Filters
            slider: 45,
            price: [],
            dialogTime: false,
            dialogPrice: false,
            times: [
                0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24
            ],
            time: [0, 24],
            ascPrice: false,
            descPrice: false,

            // Round Trip Status
            roundTripStatus: false,
            packageStatus: false,

            // Responsive Status
            window:{
                width: 0,
                height: 0
            },
            responsiveStatus: false,
            filterExpand: false,
            filterExpandAirlineStatus: false,
            filterExpandStopStatus: false,
            filterExpandPriceStatus: false,
            filterExpandTimeStatus: false,
            filterExpandCounter: 0,
            filterExpandAirlineFlag: false,
            filterExpandStopFlag: false,
            filterExpandPriceFlag: false,
            filterExpandTimeFlag: false,

            notFound: false,
            loading:true,
            items_temp:[],
            items:[],

            // Airline Filter
            airline: '',
            airlines: ['All'],

            // Price Filter
            maxSelectedPrice: 0,
            maxPrice: 0,
            minPrice: 0,
            prices: [],
            sortedFlights: [],

            // Time Filter
            times: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24],
            startTime: 1,
            endTime: 24,
            value: [0, 10],

            // Stop Filter
            stop: 0,
            selectedStop: 0,
            stopType: ['Nonstop', '1Stop', '2Stops', '3Stops', 'Any'],
            // stopsArr: ['Any', 'One Stop', 'Two Stop'],
            stopsArr: ['Any', 'Nonstop', '1 or More'],

            // Sort Filter
            sortArr: [
                { label: 'Cheapest',        value: 'priceAsc' },
                { label: 'Quickest',        value: 'quickest' },
                { label: 'Earliest Time',   value: 'timeEarly' },
                { label: 'Highest Price',   value: 'priceDesc' },
                { label: 'Latest Time',     value: 'timeLast' },
                { label: 'Slowest',         value: 'slowest' },
            ],
            selectSortArr: { label: '', value: '' },


            // Flights
            flights: [],
            orgFlights: [],

            // City
            city: '',

            // Flags
            flagAirline: 0,
            flagPrice: 0,
            flagStartTime: 0,
            flagEndTime: 0,
            flagSortPrice: 0,
            flagOrgData: true,
            flagPriceCounter: 0,
            notFoundedAnyFlights: false,
            flagFlightsEdit: 0,
            flagStop: 0,

            // Before Arrays
            beforeFilterAirline: [],
            beforeFilterPrice: [],
            beforeFilterStartTime: [],
            beforeFilterEndTime: [],
            beforeFilterStop: [],

            // Route Address
            routeUrl: '',

            // Snackbar
            snackbar: false,
            y: 'top',
            x: null,
            mode: '',
            timeout: 3000,
            snackbarText: 'Hello, I\'m a snackbar',

            // Flight Mode
            flightMode: '',

            // Price Filter Range
            priceRangeStatus: false,

            // New Stop Filter
            stopCount: 0,

            // Disable Menu for No Flights Mode
            disableMenu: false,

            // Stepper
            stepperMode: '',
            stepperState: '',

            // Search Status
            searchStatus: 0, // 0: no searched, 1: searched with results

            // Countries
            depCountry: '',
            arrCountry: '',

            // IKA to THR Mode
            ikaMode: false,

            // Test Array
            testItems: [
                'test1', 'test2', 'test3', 'test4'
            ],


            //the iatas
            from_city_iata:'',
            to_city_iata:'',

        }),

        computed: {
            filterWrapperStatus(){
                if((this.airline != '' && this.airline != 'All') || this.stop != 0 || (this.time[0] != 0 && this.time[1] != 24) || (this.price[0] != this.minPrice && this.price[1] != this.maxPrice)){
                    return true
                } else{
                    return false
                }
            },

        },
        props: ['company_info'],
        mounted(){

            // console.log('Date: ', moment().format('ddd'));

            this.flightMode = this.$route.query.mode;

            this.showResults();

            this.addPrice();

            // Responsive Calculations
            this.window.width = window.innerWidth;
            this.window.height = window.innerHeight;
            if(this.window.width < 1025){
                this.responsiveStatus = true;
            }

            this.setStepper();

            if((this.depCountry=='Iran' && this.arrCountry=='Iran') && (this.from_city_iata=='IKA' || this.to_city_iata=='IKA'))
                this.ikaMode = true;

            // window.setInterval(this.addPrice, 9000)
        },


        methods: {
            addPrice(){
                this.price[0]++;
                // console.log('Price Added!');
            },

            timeMethod (val) {
                return this.times[val]
            },

            filterExpandAirline(){
                if(this.filterExpandAirlineFlag == true){
                    this.filterExpand = false;
                    this.filterExpandAirlineStatus = false;
                    this.filterExpandAirlineFlag = false;
                }
                else{
                    this.filterExpandStopStatus = false;
                    this.filterExpandTimeStatus = false;
                    this.filterExpandPriceStatus = false;

                    this.filterExpand = true;
                    this.filterExpandAirlineStatus = true;

                    this.filterExpandAirlineFlag = true;
                    this.filterExpandStopFlag = false;
                    this.filterExpandPriceFlag = false;
                    this.filterExpandTimeFlag = false;
                }
            },

            filterExpandStop(){
                if(this.filterExpandStopFlag == true){
                    this.filterExpand = false;
                    this.filterExpandStopStatus = false;
                    this.filterExpandStopFlag = false;
                }
                else{
                    this.filterExpandAirlineStatus = false;
                    this.filterExpandTimeStatus = false;
                    this.filterExpandPriceStatus = false;

                    this.filterExpand = true;
                    this.filterExpandStopStatus = true;

                    this.filterExpandAirlineFlag = false;
                    this.filterExpandStopFlag = true;
                    this.filterExpandPriceFlag = false;
                    this.filterExpandTimeFlag = false;
                }
            },

            filterExpandPrice(){
                if(this.filterExpandPriceFlag == true){
                    this.filterExpand = false;
                    this.filterExpandPriceStatus = false;
                    this.filterExpandPriceFlag = false;
                }
                else{
                    this.filterExpandStopStatus = false;
                    this.filterExpandTimeStatus = false;
                    this.filterExpandAirlineStatus = false;

                    this.filterExpand = true;
                    this.filterExpandPriceStatus = true;

                    this.filterExpandAirlineFlag = false;
                    this.filterExpandStopFlag = false;
                    this.filterExpandPriceFlag = true;
                    this.filterExpandTimeFlag = false;
                }
            },

            filterExpandTime(){
                if(this.filterExpandTimeFlag == true){
                    this.filterExpand = false;
                    this.filterExpandTimeStatus = false;
                    this.filterExpandTimeFlag = false;
                }
                else{
                    this.filterExpandStopStatus = false;
                    this.filterExpandAirlineStatus = false;
                    this.filterExpandPriceStatus = false;

                    this.filterExpand = true;
                    this.filterExpandTimeStatus = true;

                    this.filterExpandAirlineFlag = false;
                    this.filterExpandStopFlag = false;
                    this.filterExpandPriceFlag = false;
                    this.filterExpandTimeFlag = true;
                }
            },

            tesFilter: function () {
                // console.log('testAfilterClicked', this.items_temp);

                const result = this.items_temp.filter(item => item.totalPrice == 52)

                this.items_temp = result;

                // console.log('testAfilterClicked-After func', result);

            },

            showFlights(items){
                this.flights = items;

                // Healthy Alibaba Data Test
                this.flights = this.flights.filter(flight => flight.arrDate != null && flight.depDate != null)

                // console.log('all-flights', this.flights)
                this.orgFlights = items;
                // console.log('show flights', this.flights);

                // If not exist any flights
                if(this.flights.length == 0){
                    this.loading = false;
                    this.disableMenu = true;

                    // this.snackbarText = 'Not founded any flights in this day';
                    // this.snackbar = true;
                } else{
                    this.searchStatus = 1; // Searched with result
                    this.disableMenu = false;
                }

                // Sort Flights by Cheapest of them
                this.ascPriceSort();

            },

            setCity(city){
                this.city = city;
            },

            setCountry(country, mode){
                if(mode == 'dep'){
                    this.depCountry = country;
                }
                if(mode == 'ret') {
                    this.arrCountry = country;
                }
            },

            setDepCity(city){
                this.depCity = city;
            },

            setArrCity(city){
                this.depCity = city;
            },

            showResults: function () {

                // Vue Router Requirement
                //######  Warning  ######
                var urlParams = this.$route.params;
                var urlQueries = this.$route.query;




                let header = {
                    'Accept': 'application/json',
                    'Authorization': 'Bearer ' + this.$tookenaccess,
                };
                let data = {
                    urlParams: urlParams,
                    urlQueries: urlQueries,
                };

                // Get Counties
                let depIata = this.$route.params.travel.split('-')[0];
                this.from_city_iata = depIata
                axios.get( this.$hostname + 'iata-to-city/' + depIata)
                    .then(response => {
                        this.setCity(response.data.city);
                        this.city = response.data.city;
                        this.setCity(response.data.city);
                        this.setCountry(response.data.country, 'dep');
                        // console.log('City: ', response.data.city)
                        // console.log('Query: ', this.$route.query.step)
                    })
                    .catch(e => {
                        // console.log('City Error', e.message)
                    });

                let arrIata = this.$route.params.travel.split('-')[1];
                this.to_city_iata = arrIata
                axios.get( this.$hostname + 'iata-to-city/' + arrIata)
                    .then(response => {
                        this.setCity(response.data.city);
                        this.city = response.data.city;
                        this.setCity(response.data.city);
                        this.setCountry(response.data.country, 'ret');
                        // console.log('City: ', response.data.city)
                        // console.log('Query: ', this.$route.query.step)
                    })
                    .catch(e => {
                        // console.log('City Error', e.message)
                    });

                axios.post( this.$hostname + 'flight/search', data ,{ headers: header, timeout: 180000})
                    .then(response => {

                        // console.log('Axios Search Post Results: ', response.data)

                        this.items_temp = response.data
                        this.items = response.data
                        this.loading = false

                        // console.log('#############');
                        // console.log('this.items 1',this.items)
                        this.showFlights(this.items_temp)

                        //Create Unique Airlines Array
                        for(let i = 0; i < this.items_temp.length; i++){
                            this.airlines.push(this.items_temp[i].leaveOptions.flightSegments[0].operatingAirLine.name)
                        }
                        this.airlines = _.uniq(this.airlines)

                        // Create Array for Input Price Range
                        for(let i = 0; i < this.items_temp.length; i++){
                            this.prices.push(this.items_temp[i].totalPrice)
                        }
                        this.maxPrice = _.max(this.prices)
                        this.minPrice = _.min(this.prices)
                        this.setMaxPrice(_.max(this.prices));
                        this.setMinPrice(_.min(this.prices));
                        this.maxSelectedPrice = this.maxPrice

                        this.setLoading(false);

                        this.iCountDown();
                    })
                    .catch(e => {

                        this.notFound = true
                        this.loading = false

                        this.notFoundedAnyFlights = true;
                        // this.snackbarText = 'Catch Error' + e.message;
                        // this.snackbar = true;
                    });
                // this.price[0]++;
            },

            showReturnResults: function (urlParams, urlQueries) {

                // var urlParams = this.$route.params;
                // var urlQueries = this.$route.query;


                let header = {
                    'Accept': 'application/json',
                    'Authorization': 'Bearer ' + this.$tookenaccess,
                };
                let data = {
                    urlParams: urlParams,
                    urlQueries: urlQueries,
                };

                // console.log('SearchContent.vue - showResults() => urlQueries: ', data.urlQueries);

                //######  Warning  ######
                var desIata = data.urlParams.travel.split("-", 2)[1];

                axios.post( this.$hostname + 'flight/search', data ,{ headers: header, timeout: 180000})
                    .then(response => {

                        this.items_temp = response.data
                        this.items = response.data
                        this.loading = false

                        this.showFlights(this.items_temp)

                        //Create Unique Airlines Array
                        for(let i = 0; i < this.items_temp.length; i++){
                            this.airlines.push(this.items_temp[i].flightSegments[0].operatingAirLine.name)
                        }
                        this.airlines = _.uniq(this.airlines)

                        // Create Array for Input Price Range
                        for(let i = 0; i < this.items_temp.length; i++){
                            this.prices.push(this.items_temp[i].totalPrice)
                        }
                        this.maxPrice = _.max(this.prices)
                        this.minPrice = _.min(this.prices)
                        this.maxSelectedPrice = this.maxPrice

                        // Vue Router Requirement
                        //######  Warning  ######
                        // console.log(this.$route)

                        // console.log('this.items',this.items)
                        //
                        // console.log('lodash', _.uniq(this.airlines))
                        //
                        // console.log('prices', this.prices)
                        //
                        // console.log('max price', this.maxPrice)
                    })
                    .catch(e => {

                        this.notFound = true
                        this.loading = false

                        this.notFoundedAnyFlights = true;
                        // this.snackbarText = 'Catch Error' + e.message;
                        // this.snackbar = true;

                        // alert('Response Error (Axios): ', e.message);

                        // console.log('EE', e.message);
                    });
            },

            sortPrice(){
                this.sortedFlights = _.sortBy(this.flights, 'totalPrice')
                this.flights = this.sortedFlights

                // console.log('new items_temp', this.flights)
            },

            filter(){
                // this.flagOrgData = true;
            },

            resetFlights(){

                this.flights = this.orgFlights;
                this.airline = '';
                this.startTime = 1;
                this.endTime = 24;
                this.maxSelectedPrice = this.maxPrice;
            },

            // Setter
            setLoading(val){
                this.loading = val;
            },

            setMaxPrice(val){
                this.maxPrice = val;
                this.price[1] = val;
            },

            setMinPrice(val){
                this.minPrice = val;
                this.price[0] = val;
                this.priceRangeStatus = true;
            },

            resetAirline(){
                this.airline = ''
            },

            resetStop(){
                this.stop = 'Nonstop'
            },

            resetPrice(){
                this.price[0] = this.minPrice
                this.price[1] = this.maxPrice
            },

            resetTime(){
                this.time[0] = 0
                this.time[1] = 24
            },

            goToSearchResult(params){

                var fromHomeToSearchUrl

                fromHomeToSearchUrl = '/search/' + params.from + '-' + params.to ;

                (params.departing !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'?departing='+params.departing : fromHomeToSearchUrl = fromHomeToSearchUrl + '?departing=' + moment().format('Y-MM-DD'),
                    (params.returning !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&returning='+params.returning : fromHomeToSearchUrl = fromHomeToSearchUrl,
                    (params.adult !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&adult='+params.adult : fromHomeToSearchUrl+'&adult=0',
                    (params.Child !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&child='+params.Child : fromHomeToSearchUrl+'&child=0',
                    (params.infant !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&infant='+params.infant : fromHomeToSearchUrl+'&infant=0',
                    (this.company_info.id !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&agent='+this.company_info.id : fromHomeToSearchUrl+'&agent=1',
                    (params.flightClass !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&flightClass='+params.flightClass : fromHomeToSearchUrl = fromHomeToSearchUrl,
                    (params.step !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&step='+params.step : fromHomeToSearchUrl+'&step=1',
                    (params.mode !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&mode='+params.mode : true,
                    // (params.mode !== null && params.returning == null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&mode=oneway' : true,
                    // (params.mode !== null && params.returning !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&mode=roundtrip' : true,


                    this.$router.push(fromHomeToSearchUrl)


            },

            // Count Down
            iCountDown(){
                // Set the date we're counting down to
                // var countDownDate = new Date('2018-12-22').getTime();
                var countDownDate = moment().add(5, 'm');
                // var countDownDate = moment().add(10, 's');

                // Update the count down every 1 second
                var x = setInterval(function() {

                    // Get todays date and time
                    var now = new Date().getTime();

                    // Find the distance between now and the count down date
                    var distance = countDownDate - now;

                    // Time calculations for days, hours, minutes and seconds
                    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
                    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                    var seconds = Math.floor((distance % (1000 * 60)) / 1000);

                    // Output the result in an element with id="demo"
                    try{
                    document.getElementById("count-down-time").innerHTML =
                        'Time Left ' + minutes + ":" + seconds;

                    // If the count down is over, write some text
                    if (distance < 0) {
                        clearInterval(x);
                        document.getElementById("count-down-time").innerHTML = "Time is over, Please try again.";
                        Swal({
                            title: 'Time is Over',
                            text: 'Time is over, please try again.',
                            // type: 'error',
                            // imageUrl: 'https://centralwellness.com/wp-content/uploads/2018/01/Hourglass-Icon-01.png',
                            imageUrl: '/pics/hourglass.png',
                            imageWidth: '100',
                            confirmButtonText: 'Try Again'
                        }).then((result) => {
                            if (result.value) {
                                window.location.reload();
                            }
                        })
                    }
                    }catch(ex){}
                }, 1000);
            },

            ascPriceSort(){
                this.flights = _.sortBy(this.flights, 'totalPrice')
            },

            descPriceSort(){
                this.flights = _.sortBy(this.flights, 'totalPrice').reverse();
            },

            earlyTimeSort(){
                this.flights = _.sortBy(this.flights, 'depDate');
            },

            lastTimeSort(){
                this.flights = _.sortBy(this.flights, 'depDate').reverse();
            },

            quickest(){
                this.flights = _.sortBy(this.flights, 'depFlightDuration');
            },

            slowest(){
                this.flights = _.sortBy(this.flights, 'depFlightDuration').reverse();
            },

            DisableMenus(){
                this.disableMenu = true;
                // console.log('Fire!'));
            },

            setStepper(){
                this.stepperState = this.$route.query.step;
                this.stepperMode = this.flightMode;
                if(this.stepperState == 2){
                    this.stepperMode = 'roundtrip';
                }
                // console.log('StepperMode: ', this.stepperMode)
                // console.log('StepperStep: ', this.stepperState)
            },

            getStop(val){
                return this.stopsArr[val];
            },
        },


        watch:{


            // Vue Router Requirement
            //######  Warning  ######
            $route(){
                this.$router.go();
            },

            flights: function (newVal, oldVal) {
                let help = this.flights;
                this.flights = null;
                this.flights = help;
                // console.log('Flights Watch: ', this.flights);

            },

            airline(){
                let newFlight;
                // console.log('Airline Filter: ', this.flights);
                // console.log('Original Flights: ', this.orgFlights);

                if(this.airline == 'All' || this.airline == ''){
                    if(this.stop != ''){
                        newFlight = this.orgFlights.filter(
                            flight => flight.totalPrice <= this.price[1] &&
                                flight.totalPrice >= this.price[0] &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() >= this.time[0] &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() <= this.time[1] &&
                                flight.Tstops == this.stop
                        )
                    }
                    if(this.stop == ''){
                        newFlight = this.orgFlights.filter(
                            flight => flight.totalPrice <= this.price[1] &&
                                flight.totalPrice >= this.price[0] &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() >= this.time[0] &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() <= this.time[1]
                        )
                    }
                } else{
                    if(this.stop != ''){
                        newFlight = this.orgFlights.filter(
                            flight => flight.totalPrice <= this.price[1] &&
                                flight.totalPrice >= this.price[0] &&
                                flight.leaveOptions.flightSegments[0].operatingAirLine.name == this.airline &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() >= this.time[0] &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() <= this.time[1] &&
                                flight.Tstops == this.stop
                        )
                    }
                    if(this.stop == ''){
                        newFlight = this.orgFlights.filter(
                            flight => flight.totalPrice <= this.price[1] &&
                                flight.totalPrice >= this.price[0] &&
                                flight.leaveOptions.flightSegments[0].operatingAirLine.name == this.airline &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() >= this.time[0] &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() <= this.time[1]
                        )
                    }

                }
                this.flights = newFlight;
            },

            price(){
                let newFlight;
                if(this.airline == '' || this.airline == 'All'){
                    if(this.stop != ''){
                        newFlight = this.orgFlights.filter(
                            flight => flight.totalPrice <= this.price[1] &&
                                flight.totalPrice >= this.price[0] &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() >= this.time[0] &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() <= this.time[1] &&
                                flight.Tstops == this.stop
                        )
                    }
                    if(this.stop == ''){
                        newFlight = this.orgFlights.filter(
                            flight => flight.totalPrice <= this.price[1] &&
                                flight.totalPrice >= this.price[0] &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() >= this.time[0] &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() <= this.time[1]
                        )
                    }
                } else{
                    if(this.stop != ''){
                        newFlight = this.orgFlights.filter(
                            flight => flight.totalPrice <= this.price[1] &&
                                flight.totalPrice >= this.price[0] &&
                                flight.leaveOptions.flightSegments[0].operatingAirLine.name == this.airline &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() >= this.time[0] &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() <= this.time[1] &&
                                flight.Tstops == this.stop
                        )
                    }
                    if(this.stop == ''){
                        newFlight = this.orgFlights.filter(
                            flight => flight.totalPrice <= this.price[1] &&
                                flight.totalPrice >= this.price[0] &&
                                flight.leaveOptions.flightSegments[0].operatingAirLine.name == this.airline &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() >= this.time[0] &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() <= this.time[1]
                        )
                    }
                }
                this.flights = newFlight;
            },

            time(){
                // this.timeRange = `${moment().format('ddd')} ${moment(this.time[0], 'hh A').format('HH:00 A')} - ${moment(this.time[1], 'hh A').format('HH:59 A')}`
                this.timeRange = `${moment(this.time[0], 'hh A').format('HH:00 A')} - ${moment(this.time[1], 'hh A').format('HH:59 A')}`

                let newFlight;
                if(this.airline == '' || this.airline == 'All'){
                    if(this.stop != ''){
                        newFlight = this.orgFlights.filter(
                            flight => moment(flight.leaveOptions.flightSegments[0].departureDate).hour() >= this.time[0] &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() <= this.time[1] &&
                                flight.totalPrice <= this.price[1] &&
                                flight.totalPrice >= this.price[0] &&
                                flight.Tstops == this.stop
                        )
                    }
                    if(this.stop == ''){
                        newFlight = this.orgFlights.filter(
                            flight => moment(flight.leaveOptions.flightSegments[0].departureDate).hour() >= this.time[0] &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() <= this.time[1] &&
                                flight.totalPrice <= this.price[1] &&
                                flight.totalPrice >= this.price[0]
                        )
                    }
                } else{
                    if(this.stop != ''){
                        newFlight = this.orgFlights.filter(
                            flight => moment(flight.leaveOptions.flightSegments[0].departureDate).hour() >= this.time[0] &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() <= this.time[1] &&
                                flight.totalPrice <= this.price[1] &&
                                flight.totalPrice >= this.price[0] &&
                                flight.leaveOptions.flightSegments[0].operatingAirLine.name == this.airline &&
                                flight.Tstops == this.stop
                        )
                    }
                    if(this.stop == ''){
                        newFlight = this.orgFlights.filter(
                            flight => moment(flight.leaveOptions.flightSegments[0].departureDate).hour() >= this.time[0] &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() <= this.time[1] &&
                                flight.totalPrice <= this.price[1] &&
                                flight.totalPrice >= this.price[0] &&
                                flight.leaveOptions.flightSegments[0].operatingAirLine.name == this.airline
                        )
                    }
                }

                this.flights = newFlight;
            },

            stop(){
                // let newFlight;
                // if(this.airline == '' || this.airline == 'All') {
                //     newFlight = this.orgFlights.filter(
                //         flight => moment(flight.leaveOptions.flightSegments[0].departureDate).hour() >= this.time[0] &&
                //             moment(flight.leaveOptions.flightSegments[0].departureDate).hour() <= this.time[1] &&
                //             flight.totalPrice <= this.price[1] &&
                //             flight.totalPrice >= this.price[0] &&
                //             flight.Tstops == this.stop
                //     )
                // } else{
                //     newFlight = this.orgFlights.filter(
                //         flight => moment(flight.leaveOptions.flightSegments[0].departureDate).hour() >= this.time[0] &&
                //             moment(flight.leaveOptions.flightSegments[0].departureDate).hour() <= this.time[1] &&
                //             flight.totalPrice <= this.price[1] &&
                //             flight.totalPrice >= this.price[0] &&
                //             flight.Tstops == this.stop &&
                //             flight.leaveOptions.flightSegments[0].operatingAirLine.name == this.airline
                //     )
                // }


                let newFlight;
                if(this.airline == '' || this.airline == 'All') {
                    if(this.selectedStop == 0){
                        newFlight = this.orgFlights.filter(
                            flight => moment(flight.leaveOptions.flightSegments[0].departureDate).hour() >= this.time[0] &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() <= this.time[1] &&
                                flight.totalPrice <= this.price[1] &&
                                flight.totalPrice >= this.price[0]
                        )
                    } else if(this.selectedStop == 1){
                        newFlight = this.orgFlights.filter(
                            flight => moment(flight.leaveOptions.flightSegments[0].departureDate).hour() >= this.time[0] &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() <= this.time[1] &&
                                flight.totalPrice <= this.price[1] &&
                                flight.totalPrice >= this.price[0] &&
                                flight.Tstops == 'Nonstop'
                        )
                    } else if(this.selectedStop == 2){
                        newFlight = this.orgFlights.filter(
                            flight => moment(flight.leaveOptions.flightSegments[0].departureDate).hour() >= this.time[0] &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() <= this.time[1] &&
                                flight.totalPrice <= this.price[1] &&
                                flight.totalPrice >= this.price[0] &&
                                flight.Tstops == '1Stop' || flight.Tstops == '2Stops' || flight.Tstops == '3Stop' || flight.Tstops == '4Stops'
                        )
                    }
                } else{
                    if(this.selectedStop == 0){
                        newFlight = this.orgFlights.filter(
                            flight => moment(flight.leaveOptions.flightSegments[0].departureDate).hour() >= this.time[0] &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() <= this.time[1] &&
                                flight.totalPrice <= this.price[1] &&
                                flight.totalPrice >= this.price[0] &&
                                flight.leaveOptions.flightSegments[0].operatingAirLine.name == this.airline
                        )
                    } else if(this.selectedStop == 1){
                        newFlight = this.orgFlights.filter(
                            flight => moment(flight.leaveOptions.flightSegments[0].departureDate).hour() >= this.time[0] &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() <= this.time[1] &&
                                flight.totalPrice <= this.price[1] &&
                                flight.totalPrice >= this.price[0] &&
                                flight.Tstops == 'Nonstop' &&
                                flight.leaveOptions.flightSegments[0].operatingAirLine.name == this.airline
                        )
                    } else if(this.selectedStop == 2){
                        newFlight = this.orgFlights.filter(
                            flight => moment(flight.leaveOptions.flightSegments[0].departureDate).hour() >= this.time[0] &&
                                moment(flight.leaveOptions.flightSegments[0].departureDate).hour() <= this.time[1] &&
                                flight.totalPrice <= this.price[1] &&
                                flight.totalPrice >= this.price[0] &&
                                flight.Tstops == '1Stop' || flight.Tstops == '2Stops' || flight.Tstops == '3Stop' || flight.Tstops == '4Stops' &&
                                flight.leaveOptions.flightSegments[0].operatingAirLine.name == this.airline
                        )
                    }
                }


                this.flights = newFlight;
            },

            selectedStop(){
                if(this.selectedStop == 0)
                    // this.stop = 'Nonstop';
                    this.stop = '';
                else if(this.selectedStop == 1)
                    this.stop = '1Stop';
                else if(this.selectedStop == 2)
                    this.stop = '2Stops';
            },

            flights(){
                // console.log('Flights changed');
                // console.log('New Flights: ', this.flights);
                this.flagFlightsEdit++;
                // console.log('Flag Flights Edit: ', this.flagFlightsEdit);

                if(this.flights.length == 0){
                    this.notFoundedAnyFlights = true;
                    // console.log('Not founded any flights');
                } else{
                    this.notFoundedAnyFlights = false;
                    // console.log('Founded some flights');
                }
            },

            selectSortArr(){
                if(this.selectSortArr.value == 'priceDesc'){
                    this.descPriceSort();
                }

                if(this.selectSortArr.value == 'priceAsc'){
                    this.ascPriceSort();
                }

                if(this.selectSortArr.value == 'timeEarly'){
                    this.earlyTimeSort();
                }

                if(this.selectSortArr.value == 'timeLast'){
                    this.lastTimeSort();
                }

                if(this.selectSortArr.value == 'quickest'){
                    this.quickest();
                }

                if(this.selectSortArr.value == 'slowest'){
                    this.slowest();
                }
            },
        }

    }
</script>