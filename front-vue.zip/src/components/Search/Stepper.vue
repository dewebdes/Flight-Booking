<template>
            <v-layout row style="padding-left: 40px" class="iStepper-inner">
                <div class="iStepper-wrapper">
                    <div class="iStepper-icon-wrapper">
                        <div class="iStepper-icon iStepper-icon-active">
                            <i aria-hidden="true" class="v-icon material-icons theme--light">search</i>
                        </div>
                        <div class="iStepper-line " :class="[state>=1 ? 'iStepper-line-active' : '']"></div>
                    </div>
                    <div style="margin-left: -25px;" class="iStepper-text">Search Flights</div>
                </div>

                <div class="iStepper-wrapper">
                    <div class="iStepper-icon-wrapper">
                        <div class="iStepper-icon" :class="[state>=1 ? 'iStepper-icon-active' : '']">
                            <i aria-hidden="true" class="v-icon material-icons theme--light">flight_takeoff</i>
                        </div>
                        <div class="iStepper-line" :class="[state>=2 ? 'iStepper-line-active' : '']"></div>
                    </div>
                    <div style="margin-left: -25px;" v-if="mode=='oneway'" class="iStepper-text">Select Flight</div>
                    <div style="margin-left: -25px;" v-if="mode=='roundtrip'" class="iStepper-text">Departure Flight</div>
                    <div style="margin-left: -25px;" v-if="mode=='package'" class="iStepper-text">Select Flights</div>
                </div>

                <div class="iStepper-wrapper" v-if="mode=='roundtrip'">
                    <div class="iStepper-icon-wrapper">
                        <div class="iStepper-icon" :class="[state>=2 ? 'iStepper-icon-active' : '']">
                            <i aria-hidden="true" class="v-icon material-icons theme--light">flight_land</i>
                        </div>
                        <div class="iStepper-line" :class="[state==3 ? 'iStepper-line-active' : '']"></div>
                    </div>
                    <div style="margin-left: -25px;" class="iStepper-text">Return Flight</div>
                </div>

                <div class="iStepper-wrapper">
                    <div class="iStepper-icon-wrapper">
                        <div class="iStepper-icon" :class="[state==3 ? 'iStepper-icon-active' : '']">
                            <i aria-hidden="true" class="v-icon material-icons theme--light">person</i>
                        </div>
                        <div class="iStepper-line"></div>
                    </div>
                    <div style="margin-left: -25px;" class="iStepper-text">Guest Details</div>
                </div>

                <div>
                    <div class="iStepper-icon-wrapper">
                        <div class="iStepper-icon" style="margin-left: -15px;">
                            <i aria-hidden="true" class="v-icon material-icons theme--light">attach_money</i>
                        </div>
                    </div>
                    <div style="margin-left: -10px;" class="iStepper-text">Payment</div>
                </div>

            </v-layout>
</template>


<style>
    .iStepper-wrapper{
        /*width: 23%;*/
        width: 100%;
    }

    .iStepper-icon{
        /*background: #4CAF50;*/
        background: #d3d3d3;
        color: #fff !important;
        height: 30px;
        width: 30px;
        display: flex;
        text-align: center;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        border-radius: 50%;
    }

    .iStepper-icon-active{
        background: #4CAF50 !important;
    }

    .iStepper-icon-wrapper{
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
    }

    .iStepper-icon i{
        color: #fff !important;
        font-size: 20px;
    }

    .iStepper-line{
        width: calc(100% - 30px);
        background: #d3d3d3;
        height: 2px;
    }

    .iStepper-line-active{
        background: #4CAF50;
    }

    .iStepper-text{
        padding-top: 10px;
    }

    @media screen and (max-width:768px){
        .iStepper-text{
            display: none;
        }

        .iStepper-inner{
            padding-left: 0 !important;
        }
    }
</style>


<script>
    export default{
        props: [
            'mode',
            'state'
        ],

        mounted(){
            // console.log('Mode is ', this.mode);
            // console.log('State is ', this.state);
        },
    }
</script>