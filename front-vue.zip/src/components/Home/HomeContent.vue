<template>
    <div>
        <div class="md-layout top-image-header"></div>
        <v-content>

            <v-container fluid fill-height>
                <v-layout
                        justify-center
                        align-center
                >


                    <v-container grid-list-md text-xs-center text-md-left>
                        <v-layout row wrap>



                            <v-flex md1></v-flex>
                            <v-flex md10 xs12>
                                <HomeSearchBox v-on:do-Search="goToSearchResult"></HomeSearchBox>
                            </v-flex>
                        </v-layout>
                        <v-layout row wrap>
                            <v-flex md1></v-flex>
                            <v-flex layout wrap md10>
                                <v-flex md4 xs12>
                                    <v-card>
                                        <v-img
                                                src="https://ww2.apochi.com/img/cities/tehran.jpg"
                                                aspect-ratio="1.75"
                                        ></v-img>

                                        <v-card-title primary-title>
                                            <div>
                                                <h3 class="headline mb-0">Tehran</h3>
                                                <div>Tehran is the capital of Iran, in the north of the country. Its central Golestan Palace complex, with its ornate rooms and marble throne, was the seat of power of the Qajar dynasty ...
                                                </div>
                                            </div>
                                        </v-card-title>

                                        <v-card-actions>
                                            <v-btn flat color="orange">Search now</v-btn>
                                        </v-card-actions>
                                    </v-card>
                                </v-flex>
                                <v-flex md4 xs12>
                                    <v-card>
                                        <v-img
                                                src="https://ww2.apochi.com/img/cities/isfahan.jpg"
                                                aspect-ratio="1.75"
                                        ></v-img>

                                        <v-card-title primary-title>
                                            <div>
                                                <h3 class="headline mb-0">Isfahan</h3>
                                                <div>Isfahan (Esfahan) may be well known for its beautiful historic architecture. In fact Isfahan is capital of art in Iran. A river called Zayandeh Rood (life-giving river) runs through Isfahan giving the city ...
                                                </div>
                                            </div>
                                        </v-card-title>

                                        <v-card-actions>
                                            <v-btn flat color="orange">Search now</v-btn>
                                        </v-card-actions>
                                    </v-card>
                                </v-flex>
                                <v-flex md4 xs12>
                                    <v-card>
                                        <v-img
                                                src="https://ww2.apochi.com/img/cities/mashhad.jpg"
                                                aspect-ratio="1.75"
                                        ></v-img>

                                        <v-card-title primary-title>
                                            <div>
                                                <h3 class="headline mb-0">Mashhad</h3>
                                                <div>Mashhad city is most famous and revered for housing the tomb of Imam Reza, the eighth Shia Imam. Every year, millions of pilgrims visit the Imam Reza shrine and pay their tributes to Imam Reza...
                                                </div>
                                            </div>
                                        </v-card-title>

                                        <v-card-actions>
                                            <v-btn flat color="orange">Search now</v-btn>
                                        </v-card-actions>
                                    </v-card>
                                </v-flex>
                                <v-flex md4 xs12>
                                    <v-card>
                                        <v-img
                                                src="https://ww2.apochi.com/img/cities/shiraz.jpg"
                                                aspect-ratio="1.75"
                                        ></v-img>

                                        <v-card-title primary-title>
                                            <div>
                                                <h3 class="headline mb-0">Shiraz</h3>
                                                <div>
                                                    Celebrated as the heartland of Persian culture for more than 2000 years, Shiraz has become synonymous with education, nightingales, poetry and history of earth. Vakil Bazaar, Nasir ol Molk mosque...
                                                </div>
                                            </div>
                                        </v-card-title>

                                        <v-card-actions>
                                            <v-btn flat color="orange">Search now</v-btn>
                                        </v-card-actions>
                                    </v-card>
                                </v-flex>
                                <v-flex md4 xs12>
                                    <v-card>
                                        <v-img
                                                src="https://ww2.apochi.com/img/cities/tabriz.jpg"
                                                aspect-ratio="1.75"
                                        ></v-img>

                                        <v-card-title primary-title>
                                            <div>
                                                <h3 class="headline mb-0">Tabriz</h3>
                                                <div>
                                                    A fascinating bazaar and very friendly people in Tabriz. Sometimes stiflingly smoggy and hot in summer, it can be freezing cold in winter, but the Azari welcome is generally ...
                                                </div>
                                            </div>
                                        </v-card-title>

                                        <v-card-actions>
                                            <v-btn flat color="orange">Search now</v-btn>
                                        </v-card-actions>
                                    </v-card>
                                </v-flex>
                                <v-flex md4 xs12>
                                    <v-card>
                                        <v-img
                                                src="https://ww2.apochi.com/img/cities/kish.jpg"
                                                aspect-ratio="1.75"
                                        ></v-img>

                                        <v-card-title primary-title>
                                            <div>
                                                <h3 class="headline mb-0">Kish Island</h3>
                                                <div>
                                                    Kish is an island in the Persian (Arabian) Gulf, off the southern coast of Iran. On the east side, known for offshore coral reefs, beaches include Marjan Beach Park. Dolphin Park features dolphins, seals and ...
                                                </div>
                                            </div>
                                        </v-card-title>

                                        <v-card-actions>
                                            <v-btn flat color="orange">Search now</v-btn>
                                        </v-card-actions>
                                    </v-card>
                                </v-flex>
                            </v-flex>
                            <v-flex md1></v-flex>

                        </v-layout>
                    </v-container>
                </v-layout>
            </v-container>
        </v-content>
    </div>
</template>

<style>
    .top-image-header{
        background-image: url(//t0.gstatic.com/images?q=tbn:ANd9GcRDNees9RW3z9NNN-IDw8X8dSJKyfmaFdc0Q9VLdGQr1jlMkYLi);
        background-position: center;
        background-repeat: no-repeat;
        background-size: 100%;
        border-radius: 2px;
        /*height: calc(100vh/3);*/
        height: calc(20vw);
        margin: 0 auto;
        min-height: 170px;
        /*min-width: 1000px;*/
        max-height: 480px;
        max-width: 1440px;
        -webkit-transition: opacity 200ms ease-in;
        width: 100%;
    }
</style>

<script>

    import Vue from 'vue'


    import HomeSearchBox from '@/components/Home/HomeSearchBox'
    import moment from 'moment'
    Vue.prototype.moment = moment


    export default {
        name: 'HomeContent',
        components:{
            HomeSearchBox
        },
        props: ['company_info','source'],
        mounted(){
        },
        data(){
            return{
                items:[{'id':'1','name':'ali'},{'id':'2','name':'reza'},{'id':'3','name':'shahin'}],
            }
        },
        methods:{
            goToSearchResult(params){

                var fromHomeToSearchUrl

                fromHomeToSearchUrl = '/search/' + params.from + '-' + params.to ;

                (params.departing !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'?departing='+params.departing : fromHomeToSearchUrl = fromHomeToSearchUrl + '?departing=' + moment().format('Y-MM-DD'),
                    (params.returning !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&returning='+params.returning : fromHomeToSearchUrl = fromHomeToSearchUrl,
                    (params.adult !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&adult='+params.adult : fromHomeToSearchUrl+'&adult=0',
                    (params.Child !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&child='+params.Child : fromHomeToSearchUrl+'&child=0',
                    (params.infant !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&infant='+params.infant : fromHomeToSearchUrl+'&infant=0',
                    (params.flightClass !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&flightClass='+params.flightClass : fromHomeToSearchUrl = fromHomeToSearchUrl,
                    (params.step !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&step='+params.step : fromHomeToSearchUrl+'&step=1',
                    (this.company_info.id !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&agent='+this.company_info.id : fromHomeToSearchUrl+'&agent=1',
                    (params.mode !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&mode='+params.mode : true,
                    // (params.mode !== null && params.returning == null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&mode=oneway' : true,
                    // (params.mode !== null && params.returning !== null) ? fromHomeToSearchUrl = fromHomeToSearchUrl+'&mode=roundtrip' : true,
                    this.$router.push(fromHomeToSearchUrl)


            }
        },

    }
</script>


