<template>
    <div>
        <v-app id="inspire">

            <v-navigation-drawer
                    v-model="drawer"
                    fixed
                    app
            >
                <v-list dense>

                    <MenuItems :company_info="this.company"></MenuItems>

                </v-list>
            </v-navigation-drawer>

            <v-toolbar color="indigo" dark fixed app>
                <v-toolbar-side-icon @click.stop="drawer = !drawer"></v-toolbar-side-icon>
                <v-toolbar-title>
                    <a :href="this.company.url">
                        <img :src="this.company.white_logo_address" class="header_logo" alt="">
                    </a>
                </v-toolbar-title>
            </v-toolbar>
            <HomeContent :company_info="this.company"></HomeContent>
            <v-footer color="indigo" app>
                <span class="white--text">Copyright &copy; Apochi 2019</span>
            </v-footer>
        </v-app>

    </div>
</template>


<style>
    .header_logo{
        max-width: 140px;
        padding-top: 10px;
    }
</style>


<script>

    import Vue from 'vue'


    import HomeContent from '@/components/Home/HomeContent';
    import MenuItems from '@/components/Inc/MenuItems';


    import axios from 'axios'
    Vue.prototype.$axios = axios


    export default {
        name: 'HomeHeader',
        components:{
            HomeContent,
            MenuItems
        },
        data(){
            return{
                menuVisible: false,
                company:{},
                drawer: false
            }
        },
        props: {
            source: String
        },
        mounted(){
            this.getCompany();

        },
        methods:{
            getCompany: function () {


                var id = 1
                if(this.$route.query.agent){
                    id = this.$route.query.agent
                }

                let header = {
                    'Accept': 'application/json',
                    'Authorization': 'Bearer ' + this.$tookenaccess,
                };
                let data = {
                    id: id,
                };

                axios.post( this.$hostname + 'company-info', data ,{ headers: header, timeout: 180000})
                    .then(response => {

                        this.company = response.data

                    })
                    .catch(e => {
                        // console.log('e',e)

                    });
            }
        },

    }
</script>