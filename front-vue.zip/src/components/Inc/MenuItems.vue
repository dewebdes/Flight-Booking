<template>

    <div class="menueItams">
        <v-list-tile>
            <v-list-tile-action>
                <a :href="this.company_info.url">
                    <img :src="this.company_info.logo_address" alt="">
                </a>
            </v-list-tile-action>
            <v-list-tile-content>
                <v-list-tile-title>
                </v-list-tile-title>
            </v-list-tile-content>
        </v-list-tile>
        <v-list-tile>
            <v-list-tile-action>
                <v-icon>home</v-icon>
            </v-list-tile-action>
            <v-list-tile-content>
                <v-list-tile-title><a href="https://apochi.com">Home</a></v-list-tile-title>
            </v-list-tile-content>
        </v-list-tile>
        <v-list-tile>
            <v-list-tile-action>
                <v-icon>hotel</v-icon>
            </v-list-tile-action>
            <v-list-tile-content>
                <v-list-tile-title><a href="https://apochi.com/hotels/">Hotels</a></v-list-tile-title>
            </v-list-tile-content>
        </v-list-tile>
        <v-list-tile>
            <v-list-tile-action>
                <v-icon>portrait</v-icon>
            </v-list-tile-action>
            <v-list-tile-content>
                <v-list-tile-title><a href="https://apochi.com/online-iran-visa-services/">Visa</a></v-list-tile-title>
            </v-list-tile-content>
        </v-list-tile>
        <v-list-tile>
            <v-list-tile-action>
                <v-icon>place</v-icon>
            </v-list-tile-action>
            <v-list-tile-content>
                <v-list-tile-title><a href="https://apochi.com/all-tours/">Tours</a></v-list-tile-title>
            </v-list-tile-content>
        </v-list-tile>
        <v-list-tile>
            <v-list-tile-action>
                <v-icon>directions_bus</v-icon>
            </v-list-tile-action>
            <v-list-tile-content>
                <v-list-tile-title><a href="https://bus.apochi.com">Bus</a></v-list-tile-title>
            </v-list-tile-content>
        </v-list-tile>
        <v-list-tile>
            <v-list-tile-action>
                <v-icon>directions_car</v-icon>
            </v-list-tile-action>
            <v-list-tile-content>
                <v-list-tile-title><a href="https://transfer.apochi.com">Transfer</a></v-list-tile-title>
            </v-list-tile-content>
        </v-list-tile>
    </div>


</template>
<style>
.menueItams a{
    text-decoration: none;
    color: #000;
}



</style>


<script>
    export default {
        name: 'MenuItems',

        data(){
            return{
                menuVisible: false,
                company:{},
                drawer: false,
            }
        },
        props: ['company_info'],
        mounted(){

        },
        methods:{
        },

    }
</script>