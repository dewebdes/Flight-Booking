<template>
    <div>
        <v-content>




            <v-container fluid fill-height>
                <v-layout
                        justify-center
                        align-center
                >


                    <v-container grid-list-md text-xs-center text-md-left>
                        <v-layout row wrap>

                            <v-container xs12>
                                <v-flex xs12>
                                    <Stepper :mode="stepperMode" :state="stepperState" style="margin-bottom: 20px; margin-top: -15px;"></Stepper>
                                </v-flex>
                            </v-container>


                            <v-flex roundtripsmltkt xs12 v-if="this.return_flight !== null && !loading">




                                <v-flex xs12>
                                    <v-layout row wrap>

                                        <v-flex md6 sm6 xs12 white>

                                            <v-layout row wrap>
                                                <v-flex xs12 boardinghead>
                                                    <v-flex xs12>
                                                        <v-layout>
                                                            <v-flex xs12>
                                                                <img class="smalllogoonboard" :src="this.departuresmallinfo.logo" alt="">

                                                                <span class="smlbrdtxt">
                                            {{ this.departuresmallinfo.AirLine }}<v-icon class="tktflico">flight_takeoff</v-icon>

                                        </span>
                                                            </v-flex>
                                                        </v-layout>
                                                    </v-flex>
                                                </v-flex>
                                                <v-flex xs12>
                                                    <v-layout>
                                                        <v-flex md2 sm3 xs3>
                                                            <v-flex xs12 flbl1>{{ this.flightInfo.from_city_label }}</v-flex>
                                                            <v-flex xs12 flbl2>{{ this.flightInfo.from }}</v-flex>
                                                            <v-flex xs12 flbl3>DATE</v-flex>
                                                            <v-flex xs12 flbl4>{{ flightInfo.departureDate | changetodate }}</v-flex>
                                                        </v-flex>

                                                        <v-flex md4 sm5 xs5 mdldvdsml>
                                                            <v-flex xs12 flbl1></v-flex>
                                                            <v-flex xs12 flbl2><img src="https://apochi.com/img/dividerplain-bg.png" class="dvdsmlpic" alt=""></v-flex>
                                                            <v-flex xs12 flbl3>BOARDING</v-flex>
                                                            <v-flex xs12 flbl4>{{ flightInfo.departureDate | changetoboarding }}</v-flex>
                                                        </v-flex>

                                                        <v-flex md2 sm4  xs4>
                                                            <v-flex xs12 flbl1>{{ this.flightInfo.to_city_label }}</v-flex>
                                                            <v-flex xs12 flbl2>{{ this.flightInfo.to}}</v-flex>
                                                            <v-flex xs12 flbl3>DEPARTURE</v-flex>
                                                            <v-flex xs12 flbl4>{{ flightInfo.departureDate | changetodeparture }}</v-flex>
                                                        </v-flex>

                                                        <v-flex md3 hiddenunder9600 xs3 lastsmltkt>
                                                            <v-flex xs12 llbl1 class="font-weight-bold">OPERATED BY :</v-flex>
                                                            <v-flex xs12 lbl2>{{ this.departuresmallinfo.AirLine }} {{ this.flightInfo.flightNumber }}</v-flex>
                                                            <v-flex xs12 flbl3>ARRIVAL</v-flex>
                                                            <v-flex xs12 llbl4>{{ this.flightInfo.arrivalDate | changetodeparture }}</v-flex>
                                                        </v-flex>
                                                    </v-layout>
                                                </v-flex>
                                            </v-layout>



                                        </v-flex>






























                                        <v-flex md6 sm6 xs12 white>
                                            <v-layout row wrap>
                                                <v-flex xs12 boardinghead leftdashed>
                                                    <v-flex xs12>
                                                        <v-layout>
                                                            <v-flex xs12>
                                                                <img class="smalllogoonboard" :src="this.returnsmallinfo.logo" alt="">

                                                                <span class="smlbrdtxt">
                                            {{ this.returnsmallinfo.AirLine }}<v-icon class="tktflico" style="-webkit-transform: scaleX(-1);transform: scaleX(-1);">flight_land</v-icon>
                                        </span>
                                                            </v-flex>
                                                        </v-layout>
                                                    </v-flex>
                                                </v-flex>
                                                <v-flex xs12 leftdashed>
                                                    <v-layout >
                                                        <v-flex md2 sm3 xs3>
                                                            <v-flex xs12 flbl1>{{ this.return_flight.from_city_label }}</v-flex>
                                                            <v-flex xs12 flbl2>{{ this.return_flight.from }}</v-flex>
                                                            <v-flex xs12 flbl3>DATE</v-flex>
                                                            <v-flex xs12 flbl4>{{ this.return_flight.departureDate | changetodate }}</v-flex>
                                                        </v-flex>

                                                        <v-flex md4 sm5 xs5 mdldvdsml>
                                                            <v-flex xs12 flbl1></v-flex>
                                                            <v-flex xs12 flbl2><img src="https://apochi.com/img/dividerplain-bg.png" class="dvdsmlpic" alt=""></v-flex>
                                                            <v-flex xs12 flbl3>BOARDING</v-flex>
                                                            <v-flex xs12 flbl4>{{ this.return_flight.departureDate | changetoboarding }}</v-flex>
                                                        </v-flex>

                                                        <v-flex md2 sm4 xs4>
                                                            <v-flex xs12 flbl1>{{ this.return_flight.to_city_label }}</v-flex>
                                                            <v-flex xs12 flbl2>{{ this.return_flight.to}}</v-flex>
                                                            <v-flex xs12 flbl3>DEPARTURE</v-flex>
                                                            <v-flex xs12 flbl4>{{ this.return_flight.departureDate | changetodeparture }}</v-flex>
                                                        </v-flex>

                                                        <v-flex md3 hiddenunder9600 xs3 lastsmltkt>
                                                            <v-flex xs12 llbl1 class="font-weight-bold">OPERATED BY :</v-flex>
                                                            <v-flex xs12 lbl2>{{ this.returnsmallinfo.AirLine }} {{ this.return_flight.flightNumber }}</v-flex>
                                                            <v-flex xs12 flbl3>ARRIVAL</v-flex>
                                                            <v-flex xs12 llbl4>{{ this.return_flight.arrivalDate | changetodeparture }}</v-flex>
                                                        </v-flex>
                                                    </v-layout>
                                                </v-flex>
                                            </v-layout>



                                        </v-flex>

                                    </v-layout>
                                </v-flex>
                            </v-flex>


                            <v-layout wrap onewaysmltkt xs12 v-if="this.return_flight == null && !loading" style="box-shadow: 0px 1px 1px 0px #607D8B;border-radius: 10px;background: #ffffff;max-width: 99%;margin: 0 auto;">
                                <v-flex xs12 boardinghead>
                                    <v-layout>
                                        <v-flex lg9 xs12>
                                            <v-layout>
                                                <v-flex xs12>
                                                    <img class="smalllogoonboard" :src="this.departuresmallinfo.logo" alt="">

                                                    <span class="smlbrdtxt">
                                            {{ this.departuresmallinfo.AirLine }}<v-icon class="tktflico">flight_takeoff</v-icon>

                                        </span>
                                                </v-flex>
                                            </v-layout>
                                        </v-flex>
                                        <v-flex md3 leftdashed hiddenunder1024>
                                            <v-layout>
                                                <v-flex xs12>
                                                    <h2 v-if="!(this.discoundisActive == true && this.priceAfterDiscount !== null)" style="color:#ffffff">Total: &euro;{{ this.returnTotalPrice + this.totalPrice }}</h2>
                                                    <h2 v-if="this.discoundisActive == true && this.priceAfterDiscount !== null" style="color:#ffffff">Total: &euro;{{ this.priceAfterDiscount }}</h2>
                                                </v-flex>
                                            </v-layout>
                                        </v-flex>
                                    </v-layout>

                                </v-flex>
                                <v-flex xs12>
                                    <v-layout>
                                        <v-flex lg9 xs12 isonesmltkt white>
                                            <v-layout>
                                                <v-flex sm2 xs2 firstxxsm>
                                                    <v-flex xs12 flbl1>{{ this.flightInfo.from_city_label }}</v-flex>
                                                    <v-flex xs12 flbl2>{{ this.flightInfo.from }}</v-flex>
                                                    <v-flex xs12 flbl3>DATE</v-flex>
                                                    <v-flex xs12 flbl4>{{ flightInfo.departureDate | changetodate }}</v-flex>
                                                </v-flex>

                                                <v-flex sm4 xs4 mdldvdsml>
                                                    <v-flex xs12 flbl1></v-flex>
                                                    <v-flex xs12 flbl2><img src="https://apochi.com/img/dividerplain-bg.png" class="dvdsmlpic" alt=""></v-flex>
                                                    <v-flex xs12 flbl3>BOARDING</v-flex>
                                                    <v-flex xs12 flbl4>{{ flightInfo.departureDate | changetoboarding }}</v-flex>
                                                </v-flex>

                                                <v-flex sm2 xs2>
                                                    <v-flex xs12 flbl1>{{ this.flightInfo.to_city_label }}</v-flex>
                                                    <v-flex xs12 flbl2>{{ this.flightInfo.to}}</v-flex>
                                                    <v-flex xs12 flbl3>DEPARTURE</v-flex>
                                                    <v-flex xs12 flbl4>{{ flightInfo.departureDate | changetodeparture }}</v-flex>
                                                </v-flex>

                                                <v-flex sm4 xs4 hiddenunder350 lastsmltkt>
                                                    <v-flex xs12 llbl1 class="font-weight-bold">OPERATED BY :</v-flex>
                                                    <v-flex xs12 lbl2>{{ this.departuresmallinfo.AirLine }} {{ this.flightInfo.flightNumber }}</v-flex>
                                                    <v-flex xs12 flbl3>ARRIVAL</v-flex>
                                                    <v-flex xs12 llbl4>{{ this.flightInfo.arrivalDate | changetodeparture }}</v-flex>
                                                </v-flex>


                                                <v-flex sm2 xs1 hiddenunder600 >
                                                    <v-flex xs12 flbl2 qrsmltkt><img  src="https://ww2.apochi.com/img/qr-code.png" alt=""></v-flex>
                                                    <v-flex xs12 flbl3>CLASS</v-flex>
                                                    <v-flex xs12 flbl4>{{ flightInfo.bookingClassAvail }}</v-flex>
                                                </v-flex>


                                            </v-layout>
                                        </v-flex>
                                        <v-flex md3 hiddenunder1024 leftdashed white>
                                            <v-layout>
                                                <v-flex xs12 tktsmlright>

                                                    <p>{{ this.adult_number }} X Adult &euro;{{ this.adult_pack }} </p>
                                                    <p v-if="this.child_number > 0">{{ this.child_number }} X  Child &euro;{{ this.child_pack }} </p>
                                                    <p v-if="this.infant_number > 0">{{ this.infant_number }} X  Infant &euro;{{ this.infant_pack }} </p>
                                                    <p v-if="this.departure_from_pickup">{{ this.car }} X {{ this.airport_pickup_label_origin }}</p>
                                                    <p v-if="this.departure_to_pickup">{{ this.car }} X {{ this.airport_pickup_label_destination }}</p>
                                                    <p v-if="this.departure_from_tour">{{ parseInt(this.child_number) + parseInt(this.adult_number) }} X {{ this.city_tour_label_dep_orogin }}</p>
                                                    <p v-if="this.departure_to_tour">{{ parseInt(this.child_number) + parseInt(this.adult_number) }} X {{ this.city_tour_label_dep_destination }}</p>
                                                    <p>{{ (this.adult_number + this.child_number + this.infant_number) }} X Booking Fee &euro;{{ this.booking_fee }} </p>
                                                    <p v-if="this.departure_from_health">{{ parseInt(this.infant_number) + parseInt(this.child_number) + parseInt(this.adult_number) }} X {{ this.mediacl_insurance_label_origin }}</p>
                                                    <p v-if="this.education_donation">Education donation: &euro;{{ parseInt(this.educationPrice) * parseInt(this.education_donation_unit) }}</p>

                                                </v-flex>
                                            </v-layout>
                                        </v-flex>
                                    </v-layout>
                                </v-flex>
                            </v-layout>

                            <LoadingTicketCard class="reserve-loading-ticket-component" v-if="loading"></LoadingTicketCard>


                            <!-- Contact Details -->
                            <v-flex xs12 class="mt-3" v-if="!loading">
                                <v-card>
                                    <v-toolbar
                                            card
                                            color="amber accent-4"
                                            dark
                                    >
                                        <v-icon>assignment_ind</v-icon>

                                        <v-toolbar-title>Contact Details</v-toolbar-title>
                                        <v-spacer></v-spacer>
                                    </v-toolbar>

                                    <v-form class="reserveform">
                                        <v-flex x12>
                                            <v-layout row wrap>
                                                <v-flex xs12 md4 class="pr-1">                                        <v-text-field
                                                        v-model="general_info.emailAddress"
                                                        :rules="[rules.required, rules.email]"
                                                        label="E-mail" id="dmail"
                                                        required
                                                ></v-text-field></v-flex>
                                                <v-flex xs12 md4 class="pr-1">
                                                    <v-text-field
                                                            v-model="general_info.MobileNumber"
                                                            :rules="[rules.confirmEmail]"
                                                            label="Confirm Email Address" id="dmail2"
                                                            required
                                                    ></v-text-field>
                                                </v-flex>
                                                <v-flex xs12 md4 class="pr-1">
                                                    <v-text-field
                                                            v-model="general_info.PhoneNumber"
                                                            ref="akbar"
                                                            label="Mobile Number" id="dmob"
                                                            required
                                                    ></v-text-field>
                                                </v-flex>
                                            </v-layout>
                                        </v-flex>
                                        <v-layout>






                                        </v-layout>
                                    </v-form>
                                </v-card>
                            </v-flex>

                            <LoadingContactDetails class="reserve-loading-contact-component" v-if="loading"></LoadingContactDetails>


                            <v-flex xs12 class="mt-3" v-if="this.adults_info[0] && !loading">
                                <v-card class="mt-2" v-for="(adult ,index) in this.adults_info" :key="index">
                                    <v-toolbar
                                            card
                                            color="indigo"
                                            dark
                                    >
                                        <v-icon>account_box</v-icon>
                                        <v-toolbar-title>Adult Passenger {{ index + 1 }}</v-toolbar-title>
                                        <v-spacer></v-spacer>
                                    </v-toolbar>

                                    <v-form class="reserveform">
                                        <!-- Name Row -->
                                        <v-flex x12>
                                            <v-layout row wrap>


                                                <v-flex xs12 md1 lg1 class="pr-1">
                                                    <v-select
                                                            v-model="adult.gender"
                                                            :items="genders"
                                                            label="Gender" id="dgen"
                                                            required
                                                    ></v-select>
                                                </v-flex>
                                                <v-flex xs12 md3 lg3 class="px-2">
                                                    <v-text-field
                                                            v-model="adult.name"
                                                            label="First Name" id="dname"
                                                            required
                                                    ></v-text-field>
                                                </v-flex>
                                                <v-flex xs12 md4 lg4 class="pl-2">
                                                    <v-text-field
                                                            v-model="adult.family"
                                                            label="Last Name" id="dfamil"
                                                            required
                                                    ></v-text-field>
                                                </v-flex>
                                                <v-flex xs12 md4 lg4 mb-4>
                                                    <v-autocomplete
                                                            v-model="adult.nationality"
                                                            :items="nationalityStates"
                                                            label="Nationality" id="dnational"
                                                            persistent-hint
                                                    ></v-autocomplete>
                                                </v-flex>


                                            </v-layout>
                                        </v-flex>

                                        <!-- /Nationality -->



                                        <v-layout row wrap>
                                            <!-- Passport for Foreign People -->
                                            <v-flex xs-12 md4 lg4 v-if="adult.nationality!='Iranian' || isDomestic==false">
                                                <v-text-field
                                                        v-model="adult.passport_no"
                                                        label="Passport Number"
                                                        class="passport-number" id="dpassport"
                                                        required
                                                ></v-text-field>
                                            </v-flex>
                                            <!-- /Passport for Foreign People -->

                                            <!-- Passport for Iranian -->
                                            <v-flex xs-12 md2 lg2 v-if="adult.nationality=='Iranian' && isDomestic">
                                                <v-text-field
                                                        label="Passport Number" id="dpassport2"
                                                        required
                                                ></v-text-field>
                                            </v-flex>
                                            <v-flex xs-12 md2 lg2 v-if="adult.nationality=='Iranian' && isDomestic">
                                                <v-text-field
                                                        v-model="adult.passport_no"
                                                        label="Melli Code" id="melicod"
                                                        @focus="passportChecker(index)"
                                                        required
                                                ></v-text-field>
                                            </v-flex>
                                            <!-- /Passport for Iranian -->

                                            <v-flex xs12 lg4 md4 class="pr-3">
                                                <v-layout>
                                                    <v-flex xs12 titlesmallr>
                                                        Birth Date:
                                                    </v-flex>
                                                </v-layout>
                                                <v-layout>
                                                    <v-flex xs4>

                                                        <v-autocomplete
                                                                v-model="adult.date_birth.day"
                                                                :items="days"
                                                                label="Day" id="dbday"
                                                        ></v-autocomplete>

                                                    </v-flex>
                                                    <v-flex xs4>
                                                        <v-autocomplete
                                                                v-model="adult.date_birth.month"
                                                                :items="month"
                                                                label="Month" id="dbmonth"
                                                        ></v-autocomplete>

                                                    </v-flex>
                                                    <v-flex xs4>
                                                        <v-autocomplete
                                                                v-model="adult.date_birth.year"
                                                                :items="adult_year"
                                                                label="Year" id="dbyear"
                                                        ></v-autocomplete>

                                                    </v-flex>
                                                </v-layout>
                                            </v-flex>
                                            <v-flex xs12 lg4 md4 class="pr-3">
                                                <v-layout>
                                                    <v-flex xs12 titlesmallr>
                                                        Passport Expiry Date:
                                                    </v-flex>
                                                </v-layout>
                                                <v-layout>
                                                    <v-flex xs4>

                                                        <v-autocomplete
                                                                v-model="adult.passport_exp.day"
                                                                :items="days"
                                                                label="Day" id="dpassexpirday"
                                                        ></v-autocomplete>

                                                    </v-flex>
                                                    <v-flex xs4>
                                                        <v-autocomplete
                                                                v-model="adult.passport_exp.month"
                                                                :items="month"
                                                                label="Month" id="dpassexpirmonth"
                                                        ></v-autocomplete>

                                                    </v-flex>
                                                    <v-flex xs4>
                                                        <v-autocomplete
                                                                v-model="adult.passport_exp.year"
                                                                :items="pass_exp_year"
                                                                label="Year" id="dpassexpiryear"
                                                        ></v-autocomplete>

                                                    </v-flex>
                                                </v-layout>
                                            </v-flex>

                                        </v-layout>

                                    </v-form>
                                </v-card>
                            </v-flex>

                            <LoadingAdultPassenger class="reserve-loading-adult-component" v-if="loading"></LoadingAdultPassenger>



                            <v-flex xs12 class="mt-3" v-if="this.child_info[0]">
                                <v-card class="mt-2" v-for="(child ,index) in this.child_info" :key="index">
                                    <v-toolbar
                                            card
                                            dark
                                            style="background-color:#0c3560de !important;border-color: #0c3560de !important;"
                                    >
                                        <v-icon>account_box</v-icon>
                                        <v-toolbar-title>Child Passenger {{ index + 1 }}</v-toolbar-title>
                                        <v-spacer></v-spacer>
                                    </v-toolbar>

                                    <v-form class="reserveform">
                                        <!-- Name Row -->
                                        <v-flex x12>
                                            <v-layout row wrap>


                                                <v-flex xs12 md1 lg1 class="pr-1">
                                                    <v-select
                                                            v-model="child.gender"
                                                            :items="genders"
                                                            label="Gender"
                                                            required
                                                    ></v-select>
                                                </v-flex>
                                                <v-flex xs12 md3 lg3 class="px-2">
                                                    <v-text-field
                                                            v-model="child.name"
                                                            label="First Name"
                                                            required
                                                    ></v-text-field>
                                                </v-flex>
                                                <v-flex xs12 md4 lg4 class="pl-2">
                                                    <v-text-field
                                                            v-model="child.family"
                                                            label="Last Name"
                                                            required
                                                    ></v-text-field>
                                                </v-flex>
                                                <v-flex xs12 md4 lg4 mb-4>
                                                    <v-autocomplete
                                                            v-model="child.nationality"
                                                            :items="nationalityStates"
                                                            label="Nationality"
                                                            persistent-hint
                                                    ></v-autocomplete>
                                                </v-flex>


                                            </v-layout>
                                        </v-flex>

                                        <!-- /Nationality -->



                                        <v-layout row wrap>
                                            <!--<v-flex xs-12 md4 lg4>-->
                                                <!--<v-text-field-->
                                                        <!--v-model="child.passport_no"-->
                                                        <!--label="Passport Number"-->
                                                        <!--required-->
                                                <!--&gt;</v-text-field>-->
                                            <!--</v-flex>-->


                                            <!-- Passport for Foreign People -->
                                            <v-flex xs-12 md4 lg4 v-if="child.nationality!='Iranian' || isDomestic==false">
                                                <v-text-field
                                                        v-model="child.passport_no"
                                                        label="Passport Number"
                                                        class="passport-number"
                                                        required
                                                ></v-text-field>
                                            </v-flex>
                                            <!-- /Passport for Foreign People -->

                                            <!-- Passport for Iranian -->
                                            <v-flex xs-12 md2 lg2 v-if="child.nationality=='Iranian' && isDomestic">
                                                <v-text-field
                                                        label="Passport Number"
                                                        required
                                                ></v-text-field>
                                            </v-flex>
                                            <v-flex xs-12 md2 lg2 v-if="child.nationality=='Iranian' && isDomestic">
                                                <v-text-field
                                                        v-model="child.passport_no"
                                                        label="Melli Code"
                                                        @focus="passportChecker(index)"
                                                        required
                                                ></v-text-field>
                                            </v-flex>
                                            <!-- /Passport for Iranian -->

                                            <v-flex xs12 lg4 md4 class="pr-3">
                                                <v-layout>
                                                    <v-flex xs12 titlesmallr>
                                                        Birth Date:
                                                    </v-flex>
                                                </v-layout>
                                                <v-layout>
                                                    <v-flex xs4>

                                                        <v-autocomplete
                                                                v-model="child.date_birth.day"
                                                                :items="days"
                                                                label="Day"
                                                        ></v-autocomplete>

                                                    </v-flex>
                                                    <v-flex xs4>
                                                        <v-autocomplete
                                                                v-model="child.date_birth.month"
                                                                :items="month"
                                                                label="Month"
                                                        ></v-autocomplete>

                                                    </v-flex>
                                                    <v-flex xs4>
                                                        <v-autocomplete
                                                                v-model="child.date_birth.year"
                                                                :items="child_year"
                                                                label="Year"
                                                        ></v-autocomplete>

                                                    </v-flex>
                                                </v-layout>
                                            </v-flex>
                                            <v-flex xs12 lg4 md4 class="pr-3">
                                                <v-layout>
                                                    <v-flex xs12 titlesmallr>
                                                        Passport Expiry Date:
                                                    </v-flex>
                                                </v-layout>
                                                <v-layout>
                                                    <v-flex xs4>

                                                        <v-autocomplete
                                                                v-model="child.passport_exp.day"
                                                                :items="days"
                                                                label="Day"
                                                        ></v-autocomplete>

                                                    </v-flex>
                                                    <v-flex xs4>
                                                        <v-autocomplete
                                                                v-model="child.passport_exp.month"
                                                                :items="month"
                                                                label="Month"
                                                        ></v-autocomplete>

                                                    </v-flex>
                                                    <v-flex xs4>
                                                        <v-autocomplete
                                                                v-model="child.passport_exp.year"
                                                                :items="pass_exp_year"
                                                                label="Year"
                                                        ></v-autocomplete>

                                                    </v-flex>
                                                </v-layout>
                                            </v-flex>

                                        </v-layout>

                                    </v-form>
                                </v-card>
                            </v-flex>
                            <v-flex xs12 class="mt-3" v-if="this.infant_info[0]">
                                <v-card class="mt-2" v-for="(infant ,index) in this.infant_info" :key="index">
                                    <v-toolbar
                                            card
                                            dark
                                            style="background-color: #304f75ba !important;border-color: #304f75ba !important;"
                                    >
                                        <v-icon>account_box</v-icon>
                                        <v-toolbar-title>Infant Passenger {{ index + 1 }}</v-toolbar-title>
                                        <v-spacer></v-spacer>
                                    </v-toolbar>

                                    <v-form class="reserveform">
                                        <!-- Name Row -->
                                        <v-flex x12>
                                            <v-layout row wrap>


                                                <v-flex xs12 md1 lg1 class="pr-1">
                                                    <v-select
                                                            v-model="infant.gender"
                                                            :items="genders"
                                                            label="Gender"
                                                            required
                                                    ></v-select>
                                                </v-flex>
                                                <v-flex xs12 md3 lg3 class="px-2">
                                                    <v-text-field
                                                            v-model="infant.name"
                                                            label="First Name"
                                                            required
                                                    ></v-text-field>
                                                </v-flex>
                                                <v-flex xs12 md4 lg4 class="pl-2">
                                                    <v-text-field
                                                            v-model="infant.family"
                                                            label="Last Name"
                                                            required
                                                    ></v-text-field>
                                                </v-flex>
                                                <v-flex xs12 md4 lg4 mb-4>
                                                    <v-autocomplete
                                                            v-model="infant.nationality"
                                                            :items="nationalityStates"
                                                            label="Nationality"
                                                            persistent-hint
                                                    ></v-autocomplete>
                                                </v-flex>


                                            </v-layout>
                                        </v-flex>

                                        <!-- /Nationality -->



                                        <v-layout row wrap>
                                            <!-- Passport for Foreign People -->
                                            <v-flex xs-12 md4 lg4 v-if="infant.nationality!='Iranian' || isDomestic==false">
                                                <v-text-field
                                                        v-model="infant.passport_no"
                                                        label="Passport Number"
                                                        class="passport-number"
                                                        required
                                                ></v-text-field>
                                            </v-flex>
                                            <!-- /Passport for Foreign People -->

                                            <!-- Passport for Iranian -->
                                            <v-flex xs-12 md2 lg2 v-if="infant.nationality=='Iranian' && isDomestic">
                                                <v-text-field
                                                        label="Passport Number"
                                                        required
                                                ></v-text-field>
                                            </v-flex>
                                            <v-flex xs-12 md2 lg2 v-if="infant.nationality=='Iranian' && isDomestic">
                                                <v-text-field
                                                        v-model="infant.passport_no"
                                                        label="Melli Code"
                                                        @focus="passportChecker(index)"
                                                        required
                                                ></v-text-field>
                                            </v-flex>
                                            <!-- /Passport for Iranian -->


                                            <v-flex xs12 lg4 md4 class="pr-3">
                                                <v-layout>
                                                    <v-flex xs12 titlesmallr>
                                                        Birth Date:
                                                    </v-flex>
                                                </v-layout>
                                                <v-layout>
                                                    <v-flex xs4>

                                                        <v-autocomplete
                                                                v-model="infant.date_birth.day"
                                                                :items="days"
                                                                label="Day"
                                                        ></v-autocomplete>

                                                    </v-flex>
                                                    <v-flex xs4>
                                                        <v-autocomplete
                                                                v-model="infant.date_birth.month"
                                                                :items="month"
                                                                label="Month"
                                                        ></v-autocomplete>

                                                    </v-flex>
                                                    <v-flex xs4>
                                                        <v-autocomplete
                                                                v-model="infant.date_birth.year"
                                                                :items="infant_year"
                                                                label="Year"
                                                        ></v-autocomplete>

                                                    </v-flex>
                                                </v-layout>
                                            </v-flex>
                                            <v-flex xs12 lg4 md4 class="pr-3">
                                                <v-layout>
                                                    <v-flex xs12 titlesmallr>
                                                        Passport Expiry Date:
                                                    </v-flex>
                                                </v-layout>
                                                <v-layout>
                                                    <v-flex xs4>

                                                        <v-autocomplete
                                                                v-model="infant.passport_exp.day"
                                                                :items="days"
                                                                label="Day"
                                                        ></v-autocomplete>

                                                    </v-flex>
                                                    <v-flex xs4>
                                                        <v-autocomplete
                                                                v-model="infant.passport_exp.month"
                                                                :items="month"
                                                                label="Month"
                                                        ></v-autocomplete>

                                                    </v-flex>
                                                    <v-flex xs4>
                                                        <v-autocomplete
                                                                v-model="infant.passport_exp.year"
                                                                :items="pass_exp_year"
                                                                label="Year"
                                                        ></v-autocomplete>

                                                    </v-flex>
                                                </v-layout>
                                            </v-flex>

                                        </v-layout>

                                    </v-form>
                                </v-card>
                            </v-flex>

                            <v-flex xs12 class="mt-3">
                                <v-layout row wrap>
                                    <v-flex xs12 md4 v-if="!loading">
                                        <v-card>
                                            <v-card-title primary-title>
                                                <v-flex xs12>
                                                    <v-layout>
                                                        <v-flex xs9 text-xs-left>

                                                            <v-layout class="row wrap suppliment-reservepage">
                                                                <v-flex x12>
                                                                    <v-checkbox
                                                                            :label="this.mediacl_insurance_label_origin"
                                                                            v-model="departure_from_health"
                                                                    ></v-checkbox>
                                                                </v-flex>
                                                            </v-layout>

                                                        </v-flex>
                                                        <v-flex xs3><v-icon class="supiconsreser">healing</v-icon></v-flex>

                                                    </v-layout>
                                                </v-flex>
                                                <v-flex class="xs12">
                                                    <span class="apnnerinurance"></span>
                                                    Health insurance is insurance against the risk of incurring medical expenses among individuals. By estimating the overall risk of health care and health system we insurance your health.
                                                </v-flex>
                                            </v-card-title>
                                        </v-card>
                                    </v-flex>
                                    <v-flex xs12 md4 v-if="!loading">
                                        <v-card>
                                            <v-card-title primary-title>
                                                <v-flex xs12>
                                                    <v-layout>
                                                        <v-flex xs9 text-xs-left>
                                                            <v-menu
                                                                    bottom
                                                                    origin="center center"
                                                                    transition="scale-transition"
                                                                    :close-on-content-click="false"
                                                                    v-if="this.return_flight !== null"
                                                            >
                                                                <v-btn
                                                                        slot="activator"
                                                                        color="orange darken-1"
                                                                        dark
                                                                >
                                                                    Choose
                                                                </v-btn>
                                                                <v-list class="reservepage">
                                                                    <v-list-tile class="waywrapper">
                                                                        <v-list-tile-title class="waywrapperinner">
                                                                            Departure: {{ flightInfo.from_city_label }} to {{ flightInfo.to_city_label }}
                                                                        </v-list-tile-title>
                                                                    </v-list-tile>
                                                                    <v-list-tile  >
                                                                        <v-list-tile-title>
                                                                            <v-checkbox
                                                                                    :label="this.airport_pickup_label_origin"
                                                                                    v-model="departure_from_pickup"
                                                                            ></v-checkbox>
                                                                        </v-list-tile-title>
                                                                    </v-list-tile>
                                                                    <v-list-tile>
                                                                        <v-list-tile-title>
                                                                            <v-checkbox
                                                                                    :label="this.airport_pickup_label_destination"
                                                                                    v-model="departure_to_pickup"
                                                                            ></v-checkbox>
                                                                        </v-list-tile-title>
                                                                    </v-list-tile>
                                                                    <v-list-tile class="waywrapper">
                                                                        <v-list-tile-title class="waywrapperinner">
                                                                            Returning: {{ flightInfo.to_city_label }} to {{ flightInfo.from_city_label }}
                                                                        </v-list-tile-title>
                                                                    </v-list-tile>
                                                                    <v-list-tile  >
                                                                        <v-list-tile-title>
                                                                            <v-checkbox
                                                                                    :label="this.airport_pickup_label_destination"
                                                                                    v-model="returning_from_pickup"
                                                                            ></v-checkbox>
                                                                        </v-list-tile-title>
                                                                    </v-list-tile>
                                                                    <v-list-tile>
                                                                        <v-list-tile-title>
                                                                            <v-checkbox
                                                                                    :label="this.airport_pickup_label_origin"
                                                                                    v-model="returning_to_pickup"
                                                                            ></v-checkbox>
                                                                        </v-list-tile-title>
                                                                    </v-list-tile>
                                                                </v-list>
                                                            </v-menu>
                                                            <v-layout class="row wrap suppliment-reservepage" v-if="this.return_flight == null">
                                                                <v-flex x12>
                                                                    <v-checkbox
                                                                            :label="this.airport_pickup_label_origin"
                                                                            v-model="departure_from_pickup"
                                                                    ></v-checkbox>
                                                                </v-flex>
                                                                <v-flex x12>
                                                                    <v-checkbox
                                                                            :label="this.airport_pickup_label_destination"
                                                                            v-model="departure_to_pickup"
                                                                    ></v-checkbox>
                                                                </v-flex>
                                                            </v-layout>

                                                        </v-flex>
                                                        <v-flex xs3><v-icon class="supiconsreser">local_taxi</v-icon></v-flex>

                                                    </v-layout>
                                                </v-flex>
                                                <v-flex xs12>
                                                    <span class="apnnerinurance" v-if="this.return_flight !== null"></span>
                                                    Avoid the hassle of getting to and from the airport. Our airport fleets are ready to provide you with convenient, stress-free transportation. Each car can carry 3 persons with their luggages</v-flex>
                                            </v-card-title>
                                        </v-card>
                                    </v-flex>
                                    <v-flex xs12 md4 v-if="!loading">
                                        <v-card>
                                            <v-card-title primary-title>
                                                <v-flex xs12>
                                                    <v-layout>
                                                        <v-flex xs9 text-xs-left>
                                                            <!--<v-menu-->
                                                                    <!--bottom-->
                                                                    <!--origin="center center"-->
                                                                    <!--transition="scale-transition"-->
                                                                    <!--:close-on-content-click="false"-->
                                                                    <!--v-if="this.return_flight !== null"-->
                                                            <!--&gt;-->
                                                                <!--<v-btn-->
                                                                        <!--slot="activator"-->
                                                                        <!--color="orange darken-1"-->
                                                                        <!--dark-->
                                                                <!--&gt;-->
                                                                    <!--Choose-->
                                                                <!--</v-btn>-->
                                                                <!--<v-list class="reservepage">-->
                                                                    <!--<v-list-tile class="waywrapper">-->
                                                                        <!--<v-list-tile-title class="waywrapperinner">-->
                                                                            <!--Departure: {{ flightInfo.from_city_label }} to {{ flightInfo.to_city_label }}-->
                                                                        <!--</v-list-tile-title>-->
                                                                    <!--</v-list-tile>-->
                                                                    <!--<v-list-tile  >-->
                                                                        <!--<v-list-tile-title>-->
                                                                            <!--<v-checkbox-->
                                                                                    <!--:label="this.city_tour_label_dep_orogin"-->
                                                                                    <!--v-model="departure_from_tour"-->
                                                                            <!--&gt;</v-checkbox>-->
                                                                        <!--</v-list-tile-title>-->
                                                                    <!--</v-list-tile>-->
                                                                    <!--<v-list-tile>-->
                                                                        <!--<v-list-tile-title>-->
                                                                            <!--<v-checkbox-->
                                                                                    <!--:label="this.city_tour_label_dep_destination"-->
                                                                                    <!--v-model="departure_to_tour"-->
                                                                            <!--&gt;</v-checkbox>-->
                                                                        <!--</v-list-tile-title>-->
                                                                    <!--</v-list-tile>-->
                                                                    <!--<v-list-tile class="waywrapper">-->
                                                                        <!--<v-list-tile-title class="waywrapperinner">-->
                                                                            <!--Returning: {{ flightInfo.to_city_label }} to {{ flightInfo.from_city_label }}-->
                                                                        <!--</v-list-tile-title>-->
                                                                    <!--</v-list-tile>-->
                                                                    <!--<v-list-tile  >-->
                                                                        <!--<v-list-tile-title>-->
                                                                            <!--<v-checkbox-->
                                                                                    <!--:label="this.city_tour_label_dep_destination"-->
                                                                                    <!--v-model="returning_from_tour"-->
                                                                            <!--&gt;</v-checkbox>-->
                                                                        <!--</v-list-tile-title>-->
                                                                    <!--</v-list-tile>-->
                                                                    <!--<v-list-tile>-->
                                                                        <!--<v-list-tile-title>-->
                                                                            <!--<v-checkbox-->
                                                                                    <!--:label="this.city_tour_label_dep_orogin"-->
                                                                                    <!--v-model="returning_to_tour"-->
                                                                            <!--&gt;</v-checkbox>-->
                                                                        <!--</v-list-tile-title>-->
                                                                    <!--</v-list-tile>-->
                                                                <!--</v-list>-->
                                                            <!--</v-menu>-->
                                                            <v-layout class="row wrap suppliment-reservepage" >
                                                                <v-flex x12>
                                                                    <v-checkbox
                                                                            :label="this.city_tour_label_dep_orogin"
                                                                            v-model="departure_from_tour"
                                                                    ></v-checkbox>
                                                                </v-flex>
                                                                <v-flex x12>
                                                                    <v-checkbox
                                                                            :label="this.city_tour_label_dep_destination"
                                                                            v-model="departure_to_tour"
                                                                    ></v-checkbox>
                                                                </v-flex>
                                                            </v-layout>

                                                        </v-flex>
                                                        <v-flex xs3><v-icon class="supiconsreser">directions_bus</v-icon></v-flex>

                                                    </v-layout>

                                                </v-flex>
                                                <v-flex xs12>Offers all types of services to tourists visiting Persian land including Iraninan foods, Culture, people, convenients, Iran tour guides and tour packages to make familiar with Iran.</v-flex>
                                            </v-card-title>
                                        </v-card>
                                    </v-flex>
                                    <v-flex xs12 md12 v-if="!loading">
                                        <v-card>
                                            <v-card-title primary-title>
                                                <v-flex xs12>
                                                    <v-layout row wrap>
                                                        <v-flex md3 xs12>
                                                            <img src="https://img.rezdy.com/EXTRA_IMAGE/Child_education_tb.jpg" alt="" style="max-width: 170px">
                                                        </v-flex>
                                                        <v-flex md9 xs12 text-xs-left>
                                                            <v-layout class="row wrap">
                                                                <v-flex class="xs12 edutitle">
                                                                    Give every child chance to succeed in life.
                                                                </v-flex>
                                                                <v-flex class="xs12 edutxt">
                                                                    Education is a child’s best chance to pass the poverty & reach to the top. Your small donation will make their future. More info:
                                                                    <a href="https://apochi.com/education" target="_blank">www.apochi.com/education</a>
                                                                </v-flex>
                                                                <v-flex class="xs12">
                                                                    <v-layout class="row wrap">
                                                                        <v-flex xs6>
                                                                            <v-checkbox
                                                                                    :label="this.education_label"
                                                                                    v-model="education_donation"
                                                                            ></v-checkbox>
                                                                        </v-flex>
                                                                        <v-flex xs3 v-if="education_donation">
                                                                            <v-select
                                                                                    :items="donation_units"
                                                                                    label="Units"
                                                                                    v-model="education_donation_unit"
                                                                            ></v-select>
                                                                        </v-flex>
                                                                    </v-layout>
                                                                </v-flex>
                                                            </v-layout>
                                                        </v-flex>
                                                    </v-layout>

                                                </v-flex>
                                            </v-card-title>
                                        </v-card>

                                    </v-flex>
                                </v-layout>
                            </v-flex>

                            <v-flex xs12 diswrap v-if="showWholeBox">
                                <v-layout row wrap>
                                    <v-flex xs12 class="havdisin" @click="showDiscountBox">
                                        <img src="data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTkuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgdmlld0JveD0iMCAwIDUxMiA1MTIiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDUxMiA1MTI7IiB4bWw6c3BhY2U9InByZXNlcnZlIiB3aWR0aD0iNTEycHgiIGhlaWdodD0iNTEycHgiPgo8Zz4KCTxnPgoJCTxwYXRoIHN0eWxlPSJmaWxsOiNGRkVFNDM7IiBkPSJNNDgwLDI1MmMtNC40MjIsMC04LDMuNTgyLTgsOEg0MGMwLTQuNDE4LTMuNTc4LTgtOC04cy04LDMuNTgyLTgsOHYyMDhjMCwyMi4wNTUsMTcuOTQ1LDQwLDQwLDQwICAgIGgzODRjMjIuMDU1LDAsNDAtMTcuOTQ1LDQwLTQwVjI2MEM0ODgsMjU1LjU4Miw0ODQuNDIyLDI1Miw0ODAsMjUyeiIvPgoJPC9nPgoJPGc+CgkJPHBhdGggc3R5bGU9ImZpbGw6I0ZGRDEwMDsiIGQ9Ik00ODAsMTY0SDMyYy0xNy42NDgsMC0zMiwxNC4zNTUtMzIsMzJ2NDhjMCwxNy42NDUsMTQuMzUyLDMyLDMyLDMyaDQ0OGMxNy42NDgsMCwzMi0xNC4zNTUsMzItMzIgICAgdi00OEM1MTIsMTc4LjM1NSw0OTcuNjQ4LDE2NCw0ODAsMTY0eiIvPgoJPC9nPgoJPGc+CgkJPGc+CgkJCTxyZWN0IHg9IjIyNCIgeT0iMTU2IiBzdHlsZT0iZmlsbDojRkY0RjE5OyIgd2lkdGg9IjY0IiBoZWlnaHQ9IjM1MiIvPgoJCTwvZz4KCTwvZz4KCTxnPgoJCTxnPgoJCQk8cG9seWdvbiBzdHlsZT0iZmlsbDojRTcwMDFFOyIgcG9pbnRzPSIyMjQsNDA3LjMxMyAyODgsNDcxLjMxMyAyODgsNDQ4LjY4OCAyMjQsMzg0LjY4OCAgICAiLz4KCQk8L2c+CgkJPGc+CgkJCTxwb2x5Z29uIHN0eWxlPSJmaWxsOiNFNzAwMUU7IiBwb2ludHM9IjIyNCwzNjcuMzEzIDI4OCw0MzEuMzEzIDI4OCw0MDguNjg4IDIyNCwzNDQuNjg4ICAgICIvPgoJCTwvZz4KCQk8Zz4KCQkJPHBvbHlnb24gc3R5bGU9ImZpbGw6I0U3MDAxRTsiIHBvaW50cz0iMjg4LDIzMS4zMTMgMjg4LDIwOC42ODggMjM1LjMxMywxNTYgMjI0LDE1NiAyMjQsMTY3LjMxMyAgICAiLz4KCQk8L2c+CgkJPGc+CgkJCTxwb2x5Z29uIHN0eWxlPSJmaWxsOiNFNzAwMUU7IiBwb2ludHM9IjIyNCwzMjcuMzEzIDI4OCwzOTEuMzEzIDI4OCwzNjguNjg4IDIyNCwzMDQuNjg4ICAgICIvPgoJCTwvZz4KCQk8Zz4KCQkJPHBvbHlnb24gc3R5bGU9ImZpbGw6I0U3MDAxRTsiIHBvaW50cz0iMjI0LDQyNC42ODggMjI0LDQ0Ny4zMTMgMjg0LjY4OCw1MDggMjg4LDUwOCAyODgsNDg4LjY4OCAgICAiLz4KCQk8L2c+CgkJPGc+CgkJCTxwb2x5Z29uIHN0eWxlPSJmaWxsOiNFNzAwMUU7IiBwb2ludHM9IjIyNCwyODcuMzEzIDI4OCwzNTEuMzEzIDI4OCwzMjguNjg4IDIyNCwyNjQuNjg4ICAgICIvPgoJCTwvZz4KCQk8Zz4KCQkJPHBvbHlnb24gc3R5bGU9ImZpbGw6I0U3MDAxRTsiIHBvaW50cz0iMjI0LDIwNy4zMTMgMjg4LDI3MS4zMTMgMjg4LDI0OC42ODggMjI0LDE4NC42ODggICAgIi8+CgkJPC9nPgoJCTxnPgoJCQk8cG9seWdvbiBzdHlsZT0iZmlsbDojRTcwMDFFOyIgcG9pbnRzPSIyNjcuMzEzLDUwOCAyMjQsNDY0LjY4OCAyMjQsNDg3LjMxMyAyNDQuNjg4LDUwOCAgICAiLz4KCQk8L2c+CgkJPGc+CgkJCTxwb2x5Z29uIHN0eWxlPSJmaWxsOiNFNzAwMUU7IiBwb2ludHM9IjIyNCwyNDcuMzEzIDI4OCwzMTEuMzEzIDI4OCwyODguNjg4IDIyNCwyMjQuNjg4ICAgICIvPgoJCTwvZz4KCTwvZz4KCTxnPgoJCTxwYXRoIHN0eWxlPSJmaWxsOiNFNzAwMUU7IiBkPSJNNDI0LDI5MS45NjljLTMxLjU4NiwwLTUwLjIwMy0zMi45MzQtNjguMjAzLTY0Ljc4NWMtMTMuMzMzLTIzLjU4NC0yNy4wMjQtNDcuNzQyLTQ2Ljg1NS01OC4wMzkgICAgYzM3LjY0LTE0LjY3MSw4NS4wMDYtMzQuOTU3LDk5LjE0NS00OS4wOTRjMjYuNTE2LTI2LjUxMiwyNi41MTYtNjkuNjUyLDAtOTYuMTY0Yy0yNi41MTYtMjYuNTE2LTY5LjY1Ni0yNi41MTYtOTYuMTcyLDAgICAgQzI5NS40Miw0MC4zNzgsMjcwLjU0NCwxMDIuMTI5LDI1NiwxNDAuODYyYy0xNC41NDQtMzguNzMyLTM5LjQyLTEwMC40ODQtNTUuOTE0LTExNi45NzVjLTI2LjUxNi0yNi41MTYtNjkuNjU2LTI2LjUxNi05Ni4xNzIsMCAgICBjLTI2LjUxNiwyNi41MTItMjYuNTE2LDY5LjY1MiwwLDk2LjE2NGMxNC4xMzksMTQuMTM3LDYxLjUwNCwzNC40MjMsOTkuMTQ1LDQ5LjA5NGMtMTkuODMyLDEwLjI5Ny0zMy41MjIsMzQuNDU1LTQ2Ljg1NSw1OC4wMzkgICAgYy0xOCwzMS44NTItMzYuNjE3LDY0Ljc4NS02OC4yMDMsNjQuNzg1Yy02LjYyNSwwLTEyLDUuMzcxLTEyLDEyczUuMzc1LDEyLDEyLDEyYzQ1LjU4NiwwLDY4LjcwMy00MC44OTUsODkuMDk0LTc2Ljk3NyAgICBjMTQuODM2LTI2LjIzOCwyOC44NDQtNTEuMDIzLDQ2LjkwNi01MS4wMjNWMTg4aDY0di0wLjAzMWMxOC4wNjMsMCwzMi4wNywyNC43ODUsNDYuOTA2LDUxLjAyMyAgICBjMjAuMzkxLDM2LjA4Miw0My41MDgsNzYuOTc3LDg5LjA5NCw3Ni45NzdjNi42MjUsMCwxMi01LjM3MSwxMi0xMlM0MzAuNjI1LDI5MS45NjksNDI0LDI5MS45Njl6IE0zMjguODgzLDQwLjg1NSAgICBjOC41NzgtOC41NzgsMTkuODQ0LTEyLjg2MywzMS4xMTctMTIuODYzYzExLjI2NiwwLDIyLjUzOSw0LjI4OSwzMS4xMTcsMTIuODYzYzE3LjE1NiwxNy4xNTYsMTcuMTU2LDQ1LjA3LDAsNjIuMjI3ICAgIGMtMTIuMjE5LDEyLjIxOS02OS43NzMsMzYuMDc4LTExNS4xNTYsNTIuOTI2QzI5Mi44MDUsMTEwLjYyNSwzMTYuNjY0LDUzLjA3NCwzMjguODgzLDQwLjg1NXogTTEyMC44ODMsNDAuODU1ICAgIGM4LjU3OC04LjU3OCwxOS44NDQtMTIuODYzLDMxLjExNy0xMi44NjNjMTEuMjY2LDAsMjIuNTM5LDQuMjg5LDMxLjExNywxMi44NjNjMTIuMjE5LDEyLjIxOSwzNi4wNzgsNjkuNzcsNTIuOTIyLDExNS4xNTIgICAgYy00NS4zODMtMTYuODQ4LTEwMi45MzgtNDAuNzA3LTExNS4xNTYtNTIuOTI2QzEwMy43MjcsODUuOTI2LDEwMy43MjcsNTguMDEyLDEyMC44ODMsNDAuODU1eiIvPgoJPC9nPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+Cjwvc3ZnPgo=">
                                        Have discount code?
                                    </v-flex>
                                    <v-flex xs12 v-if="showdiss">
                                        <input class="disinput" type="text" v-model="dscode"><v-btn class="dsiappbtn" @click="applyDiscount" color="warning">Apply</v-btn>
                                    </v-flex>
                                </v-layout>
                            </v-flex>

                            <v-flex xs12 class="mt-3">
                                <div class="text-xs-center">
                                    <v-btn
                                            v-if="!(this.discoundisActive == true && this.priceAfterDiscount !== null)"
                                            :loading="loading"
                                            :disabled="loading"
                                            @click="payAndBook"
                                            round
                                            color="amber accent-4"
                                            dark
                                    >
                                        Pay and get ticket(s) &euro;{{ this.returnTotalPrice + this.totalPrice }}
                                    </v-btn>
                                    <v-btn
                                            v-if="this.discoundisActive == true && this.priceAfterDiscount !== null"
                                            :loading="loading"
                                            :disabled="loading"
                                            @click="payAndBook"
                                            round
                                            color="amber accent-4"
                                            dark
                                    >
                                        Pay and get ticket(s) &euro;{{ this.priceAfterDiscount }}
                                    </v-btn>

                                    <!-- Cart Fixed Button -->
                                    <div class="cart-fixed-btn">
                                        <v-badge
                                                color="purple"
                                                right
                                                overlap
                                        >
                                            <span slot="badge">{{ this.additionalSum + 1 }}</span>
                                            <v-icon
                                                    large
                                                    color="white"
                                                    @click="dialog = !dialog"
                                            >
                                                shopping_cart
                                            </v-icon>
                                        </v-badge>
                                    </div>


                                </div>
                            </v-flex>

                        </v-layout>
                    </v-container>




                </v-layout>


            </v-container>

        </v-content>

        <!--<v-btn-->
                <!--fab-->
                <!--bottom-->
                <!--right-->
                <!--color="amber accent-4"-->
                <!--dark-->
                <!--fixed-->
                <!--@click="dialog = !dialog"-->
        <!--&gt;-->

                <!--<v-icon>shopping_cart</v-icon>-->

        <!--</v-btn>-->


        <v-dialog v-model="dialog" max-width="350">
            <v-card>

                <v-container grid-list-sm class="pa-4">
                    <v-layout row wrap basketdetails>
                        <v-flex xs12 align-center justify-space-between>
                        <!--<v-flex v-if="!this.bounded_flights" xs12 align-center justify-space-between>-->
                            <h2>Basket details:</h2>
                            <hr>
                            <!--<h3 v-if="this.return_flight !== null" class="font-weight-bold"> {{ flightInfo.from_city_label }} to {{ flightInfo.to_city_label }}</h3>-->
                            <span v-if="!this.bounded_flights">
                                <h3 class="font-weight-bold"> {{ flightInfo.from_city_label }} to {{ flightInfo.to_city_label }}</h3>
                                <h3>{{ this.adult_number }} X  Adult &euro;{{ this.adult_pack }} </h3>
                                <h3 v-if="this.child_number > 0">{{ this.child_number }} X  Child &euro;{{ this.child_pack }} </h3>
                                <h3 v-if="this.infant_number > 0">{{ this.infant_number }} X  Infant &euro;{{ this.infant_pack }} </h3>
                                <br>
                                <h3 v-if="this.return_flight !== null" class="font-weight-bold"> {{ flightInfo.to_city_label }} to {{ flightInfo.from_city_label }}</h3>
                                <h3 v-if="this.return_flight !== null">{{ this.adult_number }} X  Adult  &euro;{{ this.return_flight_details.adult_pack }}</h3>
                                <h3 v-if="this.child_number > 0 && this.return_flight !== null">{{ this.child_number }} X Child &euro;{{ this.return_flight_details.child_pack }} </h3>
                                <h3 v-if="this.infant_number > 0 && this.return_flight !== null">{{ this.infant_number }} X Infant &euro;{{ this.return_flight_details.infant_pack }} </h3>
                            </span>
                            <span v-if="bounded_flights">
                                <h3 class="font-weight-bold"> {{ flightInfo.from_city_label }} - {{ flightInfo.to_city_label }}</h3>
                                <h3>{{ this.adult_number }} X Adult &euro;{{ this.adult_pack }}</h3>
                                <h3 v-if="this.child_number > 0">{{ this.child_number }} X  Child &euro;{{ this.child_pack }} </h3>
                                <h3 v-if="this.infant_number > 0">{{ this.infant_number }} X Infant &euro;{{ this.infant_pack }} </h3>
                            </span>
                            <br v-if="this.return_flight !== null">
                            <h3 v-if="this.departure_from_pickup">{{ this.car }} X {{ this.airport_pickup_label_origin }}</h3>
                            <h3 v-if="this.departure_to_pickup">{{ this.car }} X {{ this.airport_pickup_label_destination }}</h3>
                            <h3 v-if="this.returning_from_pickup">{{ this.car }} X {{ this.airport_pickup_label_destination }}</h3>
                            <h3 v-if="this.returning_to_pickup">{{ this.car }} X {{ this.airport_pickup_label_origin }}</h3>
                            <h3 v-if="this.departure_from_tour">{{ parseInt(this.child_number) + parseInt(this.adult_number) }} X {{ this.city_tour_label_dep_orogin }}</h3>
                            <h3 v-if="this.departure_to_tour">{{ parseInt(this.child_number) + parseInt(this.adult_number) }} X {{ this.city_tour_label_dep_destination }}</h3>
                            <h3 v-if="this.departure_from_health">{{ parseInt(this.infant_number) + parseInt(this.child_number) + parseInt(this.adult_number) }} X {{ this.mediacl_insurance_label_origin }}</h3>
                            <h3 v-if="this.education_donation">Education donation: &euro;{{ parseInt(this.educationPrice) * parseInt(this.education_donation_unit) }}</h3>
                            <h3 v-if="stepperMode == 'roundtrip' || stepperMode == 'package'">{{ (this.adult_number + this.child_number + this.infant_number) * 2 }} X  Booking Fee €{{this.booking_fee }} </h3>
                            <h3 v-if="stepperMode == 'oneway'">{{ this.adult_number + this.child_number + this.infant_number }} X  Booking Fee €{{this.booking_fee }} </h3>
                            <h3 v-if="this.returning_from_tour">{{ parseInt(this.child_number) + parseInt(this.adult_number) }} X {{ this.city_tour_label_dep_orogin }}</h3>
                            <h3 v-if="this.returning_to_tour">{{ parseInt(this.child_number) + parseInt(this.adult_number) }} X {{ this.city_tour_label_dep_destination }}</h3>
                            <!--<hr v-if="!((this.departure_from_health || this.education_donation) && this.return_flight == null)">-->
                            <hr>
                            <h2>Total: &euro;{{ this.returnTotalPrice + this.totalPrice }}</h2>
                            <h3 v-if="this.priceAfterDiscount !== null && this.discoundisActive == true">Discount: &euro;{{ this.totalPrice - this.priceAfterDiscount }} </h3>
                            <h2 v-if="this.priceAfterDiscount !== null && this.discoundisActive == true">Total After Discount: &euro;{{ this.priceAfterDiscount }} </h2>
                        </v-flex>
                        <!--<v-flex v-if="false" xs12 align-center justify-space-between>-->
                        <!--<v-flex v-if="this.bounded_flights" xs12 align-center justify-space-between>-->
                            <!--<h2>Basket details:</h2>-->
                            <!--<hr>-->
                            <!--<h3>{{ this.adult_number }} X Adult &euro;{{ this.adult_pack }}</h3>-->
                            <!--<h3 v-if="this.child_number > 0">{{ this.child_number }} X  Child &euro;{{ this.child_pack }} </h3>-->
                            <!--<h3 v-if="this.infant_number > 0">{{ this.infant_number }} X Infant &euro;{{ this.infant_pack }} </h3>-->
                            <!--<hr>-->
                            <!--<h3 v-if="this.return_flight !== null"> {{ flightInfo.from_city_label }} to {{ flightInfo.to_city_label }}</h3>-->
                            <!--<h3 v-if="this.departure_from_pickup">{{ this.car }} X {{ this.airport_pickup_label_origin }}</h3>-->
                            <!--<h3 v-if="this.departure_to_pickup">{{ this.car }} X {{ this.airport_pickup_label_destination }}</h3>-->
                            <!--<h3 v-if="this.returning_from_pickup">{{ this.car }} X {{ this.airport_pickup_label_destination }}</h3>-->
                            <!--<h3 v-if="this.returning_to_pickup">{{ this.car }} X {{ this.airport_pickup_label_origin }}</h3>-->
                            <!--<h3 v-if="this.departure_from_tour">{{ parseInt(this.child_number) + parseInt(this.adult_number) }} X {{ this.city_tour_label_dep_orogin }}</h3>-->
                            <!--<h3 v-if="this.departure_to_tour">{{ parseInt(this.child_number) + parseInt(this.adult_number) }} X {{ this.city_tour_label_dep_destination }}</h3>-->
                            <!--<h3>Booking Fee: &euro;{{ (this.adult_number + this.child_number + this.infant_number) * this.booking_fee }}</h3>-->
                            <!--<hr v-if="this.departure_from_health || this.education_donation">-->
                            <!--<h3 v-if="this.departure_from_health">{{ parseInt(this.infant_number) + parseInt(this.child_number) + parseInt(this.adult_number) }} X {{ this.mediacl_insurance_label_origin }}</h3>-->
                            <!--<h3 v-if="this.education_donation">Education donation: &euro;{{ parseInt(this.educationPrice) * parseInt(this.education_donation_unit) }}</h3>-->
                            <!--<hr v-if="(this.departure_from_health || this.education_donation) && this.return_flight == null">-->
                            <!--<hr v-if="this.return_flight !== null">-->
                            <!--<h3 v-if="this.return_flight !== null"> {{ flightInfo.to_city_label }} to {{ flightInfo.from_city_label }}</h3>-->
                            <!--<h3 v-if="this.returning_from_tour">{{ parseInt(this.child_number) + parseInt(this.adult_number) }} X {{ this.city_tour_label_dep_orogin }}</h3>-->
                            <!--<h3 v-if="this.returning_to_tour">{{ parseInt(this.child_number) + parseInt(this.adult_number) }} X {{ this.city_tour_label_dep_destination }}</h3>-->
                            <!--<hr v-if="!((this.departure_from_health || this.education_donation) && this.return_flight == null)">-->
                            <!--<h2>Total: &euro;{{ this.returnTotalPrice + this.totalPrice }} </h2>-->
                            <!--<h2 v-if="this.priceAfterDiscount !== null && this.discoundisActive == true">Discount: &euro;{{ this.totalPrice - this.priceAfterDiscount }} </h2>-->
                            <!--<h2 v-if="this.priceAfterDiscount !== null && this.discoundisActive == true">Total After Discount: &euro;{{ this.priceAfterDiscount }} </h2>-->
                        <!--</v-flex>-->

                    </v-layout>
                </v-container>
            </v-card>
        </v-dialog>
        <!--<button @click="refFunc" style="width: 300px;height: 300px; background: red;position: fixed; top: 0;">Testttt</button>-->
    </div>
</template>

<style>
    .reserveform .v-messages__message{
     margin-top: 10px;
    }
    .disinput{
        border: 1px solid #ccc;
        border-radius: 5px;
        height: 40px;
        background: #fff;
        padding-left: 8px;
    }
    .havdisin:hover{
        cursor: pointer;
    }
    .havdisin img{
        width: 25px;
        margin-top: 10px;
        padding-top: 10px;
        margin-bottom: -4px;
        margin-right: 5px;
    }
    .diswrap{
        text-align: center;
    }
    .boardinghead{
        text-align: left;
    }
    .tktsmlright p{
        margin:0px!important;
    }
    .isonesmltkt{
        padding: 30px 40px!important;
    }
    .theme--dark.v-btn.v-btn--disabled:not(.v-btn--icon):not(.v-btn--flat):not(.v-btn--outline){
        background: #ffab00 !important;
        color: #fff;
    }
    .smalllogoonboard{
        width: 30px;
        padding-top: 2px;
        padding-left: 2px;
        float: left;
        -webkit-filter: drop-shadow(1px 1px 0px #fff );
        filter: drop-shadow(1px 1px 0px #fff);
    }
    .edutitle{
        font-size: 25px;
        font-weight: bold;
    }
    .edutxt{
        font-size: 15px;
    }
    .suppliment-reservepage .flex.x12{
        max-height: 70px;
    }
    @media(min-width: 1265px){
        .suppliment-reservepage .flex.x12{
            max-height: 50px;
        }
    }
    .suppliment-reservepage label.v-label.theme--light{
        font-size: 14px;
    }
    .suppliment-reservepage .flex.x12 .v-input.v-input--selection-controls.v-input--checkbox.theme--light{
        margin: 0px;
    }
    .basketdetails h3{
        font-weight: normal;
    }
    .titlesmallr{
        margin-bottom: -21px;
        margin-top: -15px;
    }
    .reserveform{
        padding-left: 12px;
        padding-right: 12px;
    }
    .supiconsreser{
        font-size: 50px;
    }
    .reservepage .v-list__tile__title{
        height: unset!important;
    }
    .apnnerinurance{
        height: 36px;
        display: block;
    }
    .waywrapper{
        background: #e0e0e0;
        margin-top: -8px;
    }
    .boardinghead{
        background:#00355f;
    }
    .smlbrdtxt{
        font-size: 18px;
        font-weight: bold;
        color: #ffffff;
        margin-left: 10px;
        margin-top: 10px;
        line-height: 33px;
    }
    .flex.xs12.flbl1 {
        font-size: 15px;
        font-weight: bold;
    }
    .flex.xs12.flbl2 {
        font-size: 40px;
        font-weight: bold;
    }

    .flex.xs12.flbl3 {
        font-size: 14px;
        font-weight: bold;
    }
    .dvdsmlpic{
        padding-top: 35px;
    }
    .mdldvdsml{
        text-align: center;
    }
    .lbl2{
        height: 70px;
        font-size: 11px;
    }
    .lastsmltkt{
        padding-left: 30px!important;
    }
    .leftdashed{
        border-left: 1px dashed #ccc!important;
    }
    .tktflico {
        color: #fff!important;
        margin-top: 2px;
        float: right;
    }

    .qrsmltkt img{
        height: 75px!important;
    }

    @media (max-width: 1024px) {
        .onewaysmltkt .hiddenunder1024 {
            display: none !important;
        }
    }
    @media(max-width: 601px){
        .onewaysmltkt .isonesmltkt{
            padding: 0px!important;
        }
        .onewaysmltkt .hiddenunder600{
            display: none!important;
        }
    }
    @media(max-width: 401px){
        .onewaysmltkt .hiddenunder400{
            display: none!important;
        }
    }
    @media(max-width:350px){
        .onewaysmltkt .hiddenunder350{
            display: none!important;
        }
        .onewaysmltkt .flex.xs12.flbl2{
            font-size: 23px;
        }
        .onewaysmltkt img.dvdsmlpic {
            width: 53px;
        }
        .onewaysmltkt .flex.xs12.flbl3{
            font-size: 10px!important;
        }
        .onewaysmltkt .flex.xs12.flbl4{
            font-size: 11px!important;
        }
        .onewaysmltkt .firstxxsm{
            max-width: 100%!important;
        }
    }
    @media (max-width: 1263px) {
        .roundtripsmltkt .flex.xs12.llbl1{
            font-size: 10px;
        }
        .roundtripsmltkt .flex.xs12.lbl2{
            height: 74px;
        }
    }
    @media (max-width: 960px) {
        .roundtripsmltkt .hiddenunder9600{
            display: none!important;
        }
    }
    @media (max-width:700px) {
        .roundtripsmltkt img.dvdsmlpic{
            max-width: 110px;
            height: 65px;
        }
    }
    .dsiappbtn{
        margin-top: -1px;
    }

    .cart-fixed-btn{
        position: fixed;
        bottom: 15px;
        left: 17px;
        z-index: 9999;
        padding: 9px;
        border-radius: 50%;
        background: #FFB51F;
    }

    .v-badge--overlap .v-badge__badge{
        top: -12px !important;
        bottom: -12px !important;
    }

    @media screen and (max-width: 768px) {
        .flex.xs12.flbl2{
            font-size: 20px;
        }

        .dvdsmlpic{
            width: 80px;
            padding-top: 30px;
        }

        .titlesmallr{
            margin-top: 25px;
            text-align: left;
        }

        .passport-number{
            padding-top: 0;
            margin-top: -5px;
            margin-left: 5px;
            margin-right: 5px;
        }

    }

    .reserve-loading-ticket-component,
    .reserve-loading-contact-component,
    .reserve-loading-adult-component{
        width: 100% !important;
    }

</style>


<script>
var haveerresv = false;
function seeer(){
    haveerresv = true;
    console.log('+++++++ SEE ERROR :(');
    window.parent.postMessage("killsignal();", '*');
}

function getgender(gc){
    if(gc.trim() == "1"){return 'Mr.';}
    if(gc.trim() == "2"){return 'Ms.';}
    return gc;
}
function replaceallstr(ts, tv, rv) {
try {
while (ts.indexOf(tv) > -1) {
ts = ts.replace(tv, rv);
}
} catch (ex) { }
return ts;
}

    import Vue from 'vue'
    import axios from 'axios'
    import Swal from 'sweetalert2'

    Vue.prototype.$axios = axios

    import vSelect from 'vue-select'
    Vue.component('my-select', vSelect)

    import moment from 'moment'
    Vue.prototype.moment = moment

    import lodash from 'lodash'
    var _ = require('lodash')

    // Components
    import Stepper from '../Search/Stepper'
    import LoadingTicketCard from './LoadingTicketCard'
    import LoadingContactDetails from './LoadingContactDetails'
    import LoadingAdultPassenger from './LoadingAdultPassenger'



    export default {
        name: 'ReserveContent',
        components: {
            Stepper,
            LoadingTicketCard,
            LoadingContactDetails,
            LoadingAdultPassenger
        },
        props: {
        },
        data(){
            return{
                rules: {
                    required: value => !!value || 'Required.',
                    email: value => {
                        const pattern = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
                        return pattern.test(value) || 'Invalid e-mail.'
                    },
                    confirmEmail: value => {
                         return this.general_info.emailAddress == value
                    }
                    },
                discoundisActive:false,
                priceAfterDiscount:null,
                dscode:'',
                departuresmallinfo:{
                    'logo':'',
                    'AirLine':''
                },
                returnsmallinfo:{
                    'logo':'',
                    'AirLine':''
                },

                // loader: null,
                loading: false,



                last_unit:1,

                donation_units :[1,2,3,4,5,6,7,8,9,10],
                totalPrice:0,



                departure_from_health:false,

                education_label:'',
                education_donation:false,
                education_donation_unit:1,

                departure_from_pickup:false,
                departure_to_pickup:false,

                returning_from_pickup:false,
                returning_to_pickup:false,

                departure_from_tour:false,
                departure_to_tour:false,

                returning_from_tour:false,
                returning_to_tour:false,



                mediacl_insurance_label_origin:'',
                airport_pickup_label_origin:'',
                city_tour_label_dep_orogin:'',
                airport_pickup_label_destination:'',
                city_tour_label_dep_destination:'',

                cars:'',

                flightInfo:'',
                adult_number:'',
                child_number:'',
                infant_number:'',
                adult_pack:'',
                child_pack:'',
                infant_pack:'',
                adults_info:'',
                child_info:'',
                infant_info:'',
                adult_year:'',
                child_year:'',
                infant_year:'',
                pass_exp_year:'',
                booking_fee:'',
                cityTourPrice:'',
                InsurancePrice:'',
                airportPickupPrice:'',

                days:[
                    1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31
                ],
                month:[
                    'Jan',
                    'Feb',
                    'March',
                    'April',
                    'May',
                    'June',
                    'July',
                    'August',
                    'September',
                    'October',
                    'November',
                    'December',
                ],

                general_info: {
                    emailAddress: null,
                    PhoneNumber: null,
                    MobileNumber: null,
                },

                genders: [
                    'Mr.', 'Ms.'
                ],

                nationalityStates: [
                    'Afghan',
                    'Aland Islands',
                    'Albanian',
                    'Algerian',
                    'American',
                    'Andorra',
                    'Angolan',
                    'Antiguans',
                    'Argentinean',
                    'Armenian',
                    'Australian',
                    'Austrian',
                    'Azerbaijani',
                    'Bahamian',
                    'Bahraini',
                    'Bangladeshi',
                    'Barbadian',
                    'Belarusian',
                    'Belgian',
                    'Belizean',
                    'Beninese',
                    'Bhutanese',
                    'Bolivian',
                    'Bosnian',
                    'Brazilian',
                    'British',
                    'Bruneian',
                    'Bulgarian',
                    'Burkinabe',
                    'Burundian',
                    'Cambodian',
                    'Cameroonian',
                    'Canadian',
                    'Cape Verdean',
                    'Central African',
                    'Chadian',
                    'Chilean',
                    'Chinese',
                    'Colombian',
                    'Comoran',
                    'Costa Rican',
                    'Croatian',
                    'Cuban',
                    'Cypriot',
                    'Czech',
                    'Danish',
                    'Djibouti',
                    'Dominican',
                    'Dutch',
                    'East Timorese',
                    'Ecuadorean',
                    'Egyptian',
                    'Emirian',
                    'Equatorial Guinean',
                    'Eritrean',
                    'Estonian',
                    'Ethiopian',
                    'Fijian',
                    'Filipino',
                    'Finnish',
                    'French',
                    'Gabonese',
                    'Gambian',
                    'Georgian',
                    'German',
                    'Ghanaian',
                    'Greek',
                    'Grenadian',
                    'Guatemalan',
                    'Guinea-Bissauan',
                    'Guinean',
                    'Guyanese',
                    'Haitian',
                    'Herzegovinian',
                    'Honduran',
                    'Hungarian',
                    'Icelander',
                    'Indian',
                    'Indonesian',
                    'Iranian',
                    'Iraqi',
                    'Irish',
                    'Israeli',
                    'Italian',
                    'Ivorian',
                    'Jamaican',
                    'Japanese',
                    'Jordanian',
                    'Kazakhstani',
                    'Kenyan',
                    'Kiribatian',
                    'Kuwaiti',
                    'Kyrgyz',
                    'Laotian',
                    'Latvian',
                    'Lebanese',
                    'Liberian',
                    'Libyan',
                    'Liechtensteiner',
                    'Lithuanian',
                    'Luxembourger',
                    'Macedonian',
                    'Malawian',
                    'Malaysian',
                    'Maldivan',
                    'Malian',
                    'Maltese',
                    'Marshallese',
                    'Mauritanian',
                    'Mauritian',
                    'Mexican',
                    'Micronesian',
                    'Moldovan',
                    'Monacan',
                    'Mongolian',
                    'Moroccan',
                    'Mozambican',
                    'Namibian',
                    'Nauruan',
                    'Nepalese',
                    'Netherland',
                    'New Zealander',
                    'Nigerien',
                    'North Korean',
                    'Northern Irish',
                    'Norwegian',
                    'Omani',
                    'Pakistani',
                    'Palauan',
                    'Panamanian',
                    'Papua New Guinean',
                    'Paraguayan',
                    'Peruvian',
                    'Polish',
                    'Portuguese',
                    'Qatari',
                    'Romanian',
                    'Russian',
                    'Rwandan',
                    'Saint Lucian',
                    'Samoan',
                    'San Marinese',
                    'Sao Tomean',
                    'Saudi',
                    'Senegalese',
                    'Serbian',
                    'Seychellois',
                    'Sierra Leonean',
                    'Singaporean',
                    'Slovakian',
                    'Slovenian',
                    'Solomon Islander',
                    'Somali',
                    'South African',
                    'South Korean',
                    'Spanish',
                    'Sri Lankan',
                    'Sudanese',
                    'Surinamer',
                    'Swazi',
                    'Swedish',
                    'Swiss',
                    'Syrian',
                    'Taiwanese',
                    'Tajik',
                    'Tanzanian',
                    'Thai',
                    'Togolese',
                    'Tongan',
                    'Trinidadian or Tobagonian',
                    'Tunisian',
                    'Turkish',
                    'Tuvaluan',
                    'Ugandan',
                    'Ukrainian',
                    'Uruguayan',
                    'Uzbekistani',
                    'Venezuelan',
                    'Vietnamese',
                    'Welsh',
                    'Yemenite',
                    'Zambian',
                    'Zimbabwean',
                ],
                dialog: false,
                return_flight:null,
                return_flight_details:{},
                returnTotalPrice:0,
                bounded_flights:false,
                showdiss:false,
                dscode:'',
                showWholeBox:true,

                // Stepper
                stepperMode: '',
                stepperState: '',

                // Focus Checker
                passportCheckerFocus: 0,

                // Domestic Status
                isDomestic: false,

                // Additional Number
                additionalSum: 0,






            }
        },
        mounted(){
            this.getFormInfo();

            this.setLoading(true);
            // console.log('Refs: ', this.$refs);
            // this.$refs.akbar.focus();
            window.dis = this
            window.addEventListener('message', function (msg) {
                
                      if(msg.data.indexOf('fillreserv') > -1){
            //fillreserv("kevin@gmail.com","09128116580","MR.","kevin","eyni","Albanian","ABCDEFG1","26","9","1888","false","false","false","false","false","false","0","","26","9","2020");
            //

            var dataar = replaceallstr(msg.data,'"','').split('fillreserv(')[1].split(')')[0].split(',');
            //+email+'","'+mobile+'","'+adults+'","'+childs+'","'+infnants+'","'+supliments+

            var mail = dataar[0]
            var mob = dataar[1]
            var adults = dataar[2].split('nndd')
            var childs = dataar[3].split('nndd')
            var infnants = dataar[4].split('nndd')
            var supliments = dataar[5].split('nnpp')

            /*
            var mob = dataar[5]


            var gender = getgender(dataar[2])
            var name = dataar[3] 
            var famil = dataar[4]
            var national = dataar[5] 
            var passport = dataar[6]
            var bday = dataar[7]
            var bmonth = dataar[8]
            var byear = dataar[9]
*/
            //medicinsur+'nnpp'+pikup1+'nnpp'+pikup2+'nnpp'+citytor1+'nnpp'+citytor2+'nnpp'+edugif+'nnpp'+edugifval+discod;
            var InsurancePrice = supliments[0]
            var airportPickupPrice = supliments[1]
            var pikup2 = supliments[2]
            var cityTourPrice = supliments[3]
            var citytor2 = supliments[4]
            var edugif = supliments[6]
            var discod = dataar[7]

            /*var melicod = dataar[17]
            var passexpirday = dataar[18]
            var passexpirmonth = dataar[19]
            var passexpiryear = dataar[20]
*/

                console.log(msg.data)
                
                window.dis.general_info['emailAddress'] = mail
                window.dis.general_info['PhoneNumber'] = mail
                window.dis.general_info['MobileNumber'] = mob

for(var k=0;k<=adults.length-1;k++){
    if(adults[k].length > 5){
    console.log("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% adult = "+adults[k]);
        var infoar = adults[k].split('nnpp');
        ////gender , first name , lastname, nationality , passport, birth date, passport expire

                window.dis.adults_info[k].gender = getgender(infoar[0])
                window.dis.adults_info[k].name = infoar[1]
                window.dis.adults_info[k].family = infoar[2]
                
                
                window.dis.adults_info[k].nationality = infoar[3]
                window.dis.adults_info[k].passport_no = infoar[4]
                //"2002-06-06T00:00:00"
                window.dis.adults_info[k].date_birth.day  = parseInt(infoar[5].split("T")[0].split('-')[2])
                //console.log(window.dis.adults_info[k].date_birth.day + " < day");
                window.dis.adults_info[k].date_birth.month  = parseInt(infoar[5].split("T")[0].split('-')[1])
                window.dis.adults_info[k].date_birth.year  = parseInt(infoar[5].split("T")[0].split('-')[0])
                

                window.dis.adults_info[k].passport_exp.day  = parseInt(infoar[6].split("T")[0].split('-')[2])
                window.dis.adults_info[k].passport_exp.month  = parseInt(infoar[6].split("T")[0].split('-')[1])
                window.dis.adults_info[k].passport_exp.year  = parseInt(infoar[6].split("T")[0].split('-')[0])


//alert(window.dis.adults_info[k].passport_exp.day + " " + window.dis.adults_info[k].passport_exp.month + " " + window.dis.adults_info[k].passport_exp.year)



    }
}
//child_info , infant_info
for(var k=0;k<=childs.length-1;k++){
    if(childs[k].length > 5){
    console.log("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% childs = "+childs[k]);
        var infoar = childs[k].split('nnpp');
        ////gender , first name , lastname, nationality , passport, birth date, passport expire

                window.dis.child_info[k].gender = getgender(infoar[0])
                window.dis.child_info[k].name = infoar[1]
                window.dis.child_info[k].family = infoar[2]
                
                
                window.dis.child_info[k].nationality = infoar[3]
                window.dis.child_info[k].passport_no = infoar[4]
                //"2002-06-06T00:00:00"
                window.dis.child_info[k].date_birth.day  = infoar[5].split("T")[0].split('-')[2]
                window.dis.child_info[k].date_birth.month  = infoar[5].split("T")[0].split('-')[1]
                window.dis.child_info[k].date_birth.year  = infoar[5].split("T")[0].split('-')[0]
                

                window.dis.child_info[k].passport_exp.day  = infoar[6].split("T")[0].split('-')[2]
                window.dis.child_info[k].passport_exp.month  = infoar[6].split("T")[0].split('-')[1]
                window.dis.child_info[k].passport_exp.year  = infoar[6].split("T")[0].split('-')[0]

    }
}

for(var k=0;k<=infnants.length-1;k++){
    if(infnants[k].length > 5){
    console.log("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% infnants = "+infnants[k]);
        var infoar = infnants[k].split('nnpp');
        ////gender , first name , lastname, nationality , passport, birth date, passport expire

                window.dis.infant_info[k].gender = getgender(infoar[0])
                window.dis.infant_info[k].name = infoar[1]
                window.dis.infant_info[k].family = infoar[2]
                
                
                window.dis.infant_info[k].nationality = infoar[3]
                window.dis.infant_info[k].passport_no = infoar[4]
                //"2002-06-06T00:00:00"
                window.dis.infant_info[k].date_birth.day  = infoar[5].split("T")[0].split('-')[2]
                window.dis.infant_info[k].date_birth.month  = infoar[5].split("T")[0].split('-')[1]
                window.dis.infant_info[k].date_birth.year  = infoar[5].split("T")[0].split('-')[0]
                

                window.dis.infant_info[k].passport_exp.day  = infoar[6].split("T")[0].split('-')[2]
                window.dis.infant_info[k].passport_exp.month  = infoar[6].split("T")[0].split('-')[1]
                window.dis.infant_info[k].passport_exp.year  = infoar[6].split("T")[0].split('-')[0]

    }
}



                window.dis.InsurancePrice = InsurancePrice
                window.dis.airportPickupPrice = airportPickupPrice
                window.dis.cityTourPrice = cityTourPrice
                if(parseInt(edugif) > 0){
                    window.dis.education_donation = true
                }else{
                    window.dis.education_donation = false
                }
                if(haveerresv == false){
                    jQuery('#inspire > div.application--wrap > div > main > div > div > div > div > div > div:nth-child(7) > div > button').click();
                    window.parent.postMessage("reserveclick();", '*');
                }

          }



                                          })


        },
        filters:{
            changetodate:function(val){
                var day = moment(val).format('D MMM')
                return day
            },
            changetodeparture:function(val){
                var day = moment(val).format('H:mm A')
                return day
            },
            changetoboarding:function(val){
                var day = moment(val).subtract(1, 'hour').format('H:mm A')
                return day
            }
        },
        methods:{
            applyDiscount: function(){

                let header = {
                    'Accept': 'application/json',
                    'Authorization': 'Bearer ' + this.$tookenaccess,
                };
                let data =  {
                    code: this.dscode,
                    oldPrice: this.returnTotalPrice + this.totalPrice,
                    uniId: this.$route.params.id

                }

                axios.post(this.$hostname + 'discount-code', data ,{ headers: header})
                    .then(response => {

                        // console.log('SHITTTTTT', response.data.status)
                        // return

                        if(response.data.status === 'correct'){
                            Swal({
                                title: 'Code Applied',
                                text: 'Discount has been applied',
                                type: 'success',
                                confirmButtonText: 'OK'
                            }).then((result) => {
                                if (result.value) {

                                }
                            })


                            this.discoundisActive = true
                            this.priceAfterDiscount = response.data.discountedPrice
                            this.showWholeBox = false



                        }else{
                            Swal({
                                title: 'Wrong Code',
                                text: 'This Code is not valid!',
                                type: 'error',
                                confirmButtonText: 'Try Again'
                            }).then((result) => {

                                if (result.value) {

                                    return

                                }
                            })
                        }


                    })
                    .catch(e => {

                        Swal({
                            title: 'Wrong Code',
                            text: 'This Code is not valid!',
                            type: 'error',
                            confirmButtonText: 'Try Again'
                        }).then((result) => {

                            if (result.value) {

                                return

                            }
                        })

                    })





            },
            showDiscountBox: function(){
                this.showdiss = !this.showdiss
            },
            payAndBook: function () {
                // this.loader = this.loading
                this.loading = true


                // Check Fill Inputs
                if(this.general_info.emailAddress == null){
                    this.$toaster.error('Email address is empty');
                    this.loading = false;seeer();
                    return;
                }

                if(this.general_info.PhoneNumber == null){
                    this.$toaster.error('Mobile number is empty');
                    this.loading = false;seeer();
                    return;
                }

                if(this.general_info.MobileNumber == null){
                    this.$toaster.error('Confirm E-mail is empty');
                    this.loading = false;seeer();
                    return;
                }

                // Adult Validation
                for(var i = 0; i < this.adults_info.length; i++){
                    if(this.adults_info[i].name == ""){
                        this.$toaster.error('Adult' + (i+1) + ': Firstname is empty');
                        this.loading = false;seeer();
                        seeer();
                        return;
                    }

                    if(this.adults_info[i].family == ""){
                        this.$toaster.error('Adult' + (i+1) + ': Lastname is empty');
                        this.loading = false;seeer();
                        seeer();
                        return;
                    }

                    if(this.adults_info[i].gender == ""){
                        this.$toaster.error('Adult' + (i+1) + ': Gender is empty');
                        this.loading = false;seeer();
                        seeer();
                        return;
                    }

                    if(this.adults_info[i].nationality == ""){
                        this.$toaster.error('Adult' + (i+1) + ': Nationality is empty');
                        this.loading = false;seeer();
                        seeer();
                        return;
                    }

                    if(this.adults_info[i].passport_exp == ""){
                        this.$toaster.error('Adult' + (i+1) + ': Passport expiration is empty');
                        this.loading = false;seeer();
                        seeer();
                        return;
                    }

                    if(this.adults_info[i].passport_no == ""){
                        this.$toaster.error('Adult' + (i+1) + ': Passport number is empty');
                        this.loading = false;seeer();
                        seeer();
                        return;
                    }

                    if(this.adults_info[i].date_birth.day == "" || this.adults_info[i].date_birth.month == "" || this.adults_info[i].date_birth.year == ""){
                        this.$toaster.error('Adult' + (i+1) + ': Birth date is empty');
                        this.loading = false;seeer();
                        seeer();
                        return;
                    }

                    if(this.adults_info[i].passport_exp.day == "" || this.adults_info[i].passport_exp.month == "" || this.adults_info[i].passport_exp.year == ""){
                        this.$toaster.error('Adult' + (i+1) + ': Passport Exp. Date is empty');
                        this.loading = false;seeer();
                        seeer();
                        return;
                    }

                }

                // Child Validation
                if(this.child_info.length != 0){
                    for(var i = 0; i < this.child_info.length; i++){
                        if(this.child_info[i].name == ""){
                            this.$toaster.error('Child' + (i+1) + ': Firstname is empty');
                            this.loading = false;seeer();
                            seeer();
                            return;
                        }

                        if(this.child_info[i].family == ""){
                            this.$toaster.error('Child' + (i+1) + ': Lastname is empty');
                            this.loading = false;seeer();;seeer();
                            return;
                        }

                        if(this.child_info[i].gender == ""){
                            this.$toaster.error('Child' + (i+1) + ': Gender is empty');
                            this.loading = false;seeer();
                            return;
                        }

                        if(this.child_info[i].nationality == ""){
                            this.$toaster.error('Child' + (i+1) + ': Nationality is empty');
                            this.loading = false;seeer();
                            return;
                        }

                        if(this.child_info[i].passport_exp == ""){
                            this.$toaster.error('Child' + (i+1) + ': Passport expiration is empty');
                            this.loading = false;seeer();
                            return;
                        }

                        if(this.child_info[i].passport_no == ""){
                            this.$toaster.error('Child' + (i+1) + ': Passport number is empty');
                            this.loading = false;seeer();
                            return;
                        }

                        if(this.child_info[i].date_birth.day == "" || this.child_info[i].date_birth.month == "" || this.child_info[i].date_birth.year == ""){
                            this.$toaster.error('Child' + (i+1) + ': Birth date is empty');
                            this.loading = false;seeer();
                            return;
                        }

                        if(this.child_info[i].passport_exp.day == "" || this.child_info[i].passport_exp.month == "" || this.child_info[i].passport_exp.year == ""){
                            this.$toaster.error('Child' + (i+1) + ': Passport Exp. Date is empty');
                            this.loading = false;seeer();
                            return;
                        }
                    }
                }

                // Infant Validation
                if(this.infant_info.length != 0){
                    for(var i = 0; i < this.infant_info.length; i++){
                        if(this.infant_info[i].name == ""){
                            this.$toaster.error('Infant' + (i+1) + ': Firstname is empty');
                            this.loading = false;seeer();
                            return;
                        }

                        if(this.infant_info[i].family == ""){
                            this.$toaster.error('Infant' + (i+1) + ': Lastname is empty');
                            this.loading = false;seeer();
                            return;
                        }

                        if(this.infant_info[i].gender == ""){
                            this.$toaster.error('Infant' + (i+1) + ': Gender is empty');
                            this.loading = false;seeer();
                            return;
                        }

                        if(this.infant_info[i].nationality == ""){
                            this.$toaster.error('Infant' + (i+1) + ': Nationality is empty');
                            this.loading = false;seeer();
                            return;
                        }

                        if(this.infant_info[i].passport_exp == ""){
                            this.$toaster.error('Infant' + (i+1) + ': Passport expiration is empty');
                            this.loading = false;seeer();
                            return;
                        }

                        if(this.infant_info[i].passport_no == ""){
                            this.$toaster.error('Infant' + (i+1) + ': Passport number is empty');
                            this.loading = false;seeer();
                            return;
                        }

                        if(this.infant_info[i].date_birth.day == "" || this.infant_info[i].date_birth.month == "" || this.infant_info[i].date_birth.year == ""){
                            this.$toaster.error('Infant' + (i+1) + ': Birth date is empty');
                            this.loading = false;seeer();
                            return;
                        }

                        if(this.infant_info[i].passport_exp.day == "" || this.infant_info[i].passport_exp.month == "" || this.infant_info[i].passport_exp.year == ""){
                            this.$toaster.error('Infant' + (i+1) + ': Passport Exp. Date is empty');
                            this.loading = false;seeer();
                            return;
                        }
                    }
                }


                // Check Passport Expire
                var personsPassportDates = [];
                var retPlus6Month = moment(this.flightInfo.arrivalDate).add(6, 'months');
                for(var i = 0; i < this.adults_info.length; i++){
                    personsPassportDates[i] = moment().set({'year': this.adults_info[i].passport_exp.year, 'month': this.adults_info[i].passport_exp.month, 'day' : this.adults_info[i].passport_exp.day});
                    if(personsPassportDates[i].isBefore(retPlus6Month)){
                        this.$toaster.error('Passport is expire (' + this.adults_info[i].name + ')');
                        this.loading = false;seeer();
                    }
                }



                let header = {
                    'Accept': 'application/json',
                    'Authorization': 'Bearer ' + this.$tookenaccess,
                };
                let data =  {

                    general_info: this.general_info,
                    adults: this.adults_info,
                    child: this.child_info,
                    infant: this.infant_info,

                    uni_id: this.flightInfo.uniId,

                    departure_flight_supplements:{
                        'departure_from_health'     :this.departure_from_health,
                        'departure_from_pickup'     :this.departure_from_pickup,
                        'departure_to_pickup'       :this.departure_to_pickup,
                        'departure_from_tour'       :this.departure_from_tour,
                        'departure_to_tour'         :this.departure_to_tour,

                        'education_donation'        :this.education_donation,
                        'education_donation_unit'   :this.education_donation_unit,
                    },

                    returning_flight_supplements:{
                        'returning_from_pickup' :this.returning_from_pickup,
                        'returning_to_pickup'   :this.returning_to_pickup,
                        'returning_from_tour'   :this.returning_from_tour,
                        'returning_to_tour'     :this.returning_to_tour,
                    },


                }

                axios.post( this.$hostname + 'flight/book', data ,{ headers: header})
                    .then(response => {

                        // Show Input Data
                        if(response.data.status === 'OK'){
                            window.parent.postMessage("OKsignal('"+response.data.data+"');", '*');

                            let fromReserveToPayment = this.$hostname+'payment/check/'+response.data.data

                            // return this.$router.push(fromReserveToPayment)
                            // console.log('In if condition before redirect to payment/check');
                            return window.location.replace(fromReserveToPayment);
                        } else{
                            // console.log('In if condition before redirect to payment/check');
                        }


                    })
                    .catch(e => {



 window.parent.postMessage("killsignal();", '*');
console.log("++++++++++++++++++++"+e.response.data.message);

                                                switch (e.response.data.message) {

                                                    // Time is Over
                                                    case 'YellowProviderReservationFailed':
                                                        Swal({
                                                            title: 'Time is over',
                                                            text: 'Time is over, please try again.',
                                                            imageUrl: '/pics/hourglass.png',
                                                            imageWidth: '100',
                                                            confirmButtonText: 'Try Again'
                                                        }).then((result) => {
                                                            if (result.value) {
                                                                this.loading = false;seeer();

                                                                var fromHomeToSearchUrl = "/"
                                                                this.$router.push(fromHomeToSearchUrl)
                                                                this.$router.go()
                                                            }
                                                        })
                                                        break;

                                                    // Time is Over
                                                    case 'AvailableIsExpired':
                                                        Swal({
                                                            title: 'Time is over',
                                                            text: 'Time is over, please try again.',
                                                            imageUrl: '/pics/hourglass.png',
                                                            imageWidth: '100',
                                                            confirmButtonText: 'Try Again'
                                                        }).then((result) => {
                                                            if (result.value) {
                                                                this.loading = false;seeer();

                                                                var fromHomeToSearchUrl = "/"
                                                                this.$router.push(fromHomeToSearchUrl)
                                                                this.$router.go()
                                                            }
                                                        })
                                                        break;



                                                    // Passport Number is Wrong
                                                    case 'InvalidPassportNumber':
                                                        Swal({
                                                            title: 'Passport number is wrong!',
                                                            text: 'Passport number is wrong, please correct it.',
                                                            type: 'error',
                                                            confirmButtonText: 'OK'
                                                        }).then((result) => {
                                                            if (result.value) {
                                                                this.loading = false;seeer();
                                                            }
                                                        })
                                                        break;

                                                    // Child Birthdate is Wrong
                                                    case 'ChildBirthDateIsNotRight':
                                                        Swal({
                                                            title: 'Child age is wrong!',
                                                            text: 'Child age is wrong, please correct it.',
                                                            type: 'error',
                                                            confirmButtonText: 'OK'
                                                        }).then((result) => {
                                                            if (result.value) {
                                                                this.loading = false;seeer();
                                                            }
                                                        })
                                                        break;


                                                    // Time is Over
                                                    case 'EntityNotFound':
                                                        Swal({
                                                            title: 'Time is over',
                                                            text: 'Time is over, please try again.',
                                                            imageUrl: '/pics/hourglass.png',
                                                            imageWidth: '100',
                                                            confirmButtonText: 'Try Again'
                                                        }).then((result) => {
                                                            if (result.value) {
                                                                this.loading = false;seeer();

                                                                var fromHomeToSearchUrl = "/"
                                                                this.$router.push(fromHomeToSearchUrl)
                                                                this.$router.go()
                                                            }
                                                        })
                                                        break;

                                                    // Other Errors
                                                    default:
                                                        Swal({
                                                            title: 'Time is over',
                                                            text: 'Time is over, please try again.',
                                                            imageUrl: '/pics/hourglass.png',
                                                            imageWidth: '100',
                                                            confirmButtonText: 'Try Again'
                                                        }).then((result) => {
                                                            if (result.value) {
                                                                this.loading = false;seeer();

                                                                var fromHomeToSearchUrl = "/"
                                                                this.$router.push(fromHomeToSearchUrl)
                                                                this.$router.go()
                                                            }
                                                        })
                                                        break;
                                                }



                        // console.log('pay and booked clicked catch');
                        // console.log('Pay & Book Error: ', e.message);

                    });



            },

            getFormInfo: function () {

                let header = {
                    'Accept': 'application/json',
                    'Authorization': 'Bearer ' + this.$tookenaccess,
                };
                let data =  {
                    id: this.$route.params.id
                }

                axios.post( this.$hostname + 'flight/select/check', data ,{ headers: header})
                    .then(response => {


                        var smallogobase = ''

                        if(response.data.data.isDomestic){
                            smallogobase = 'https://cdn.alibaba.ir/static/img/airlines/Domestic/'
                            this.isDomestic = true;
                        }else{
                            smallogobase = 'https://cdn.alibaba.ir/static/img/airlines/'
                            this.isDomestic = false;
                        }

                        this.flightInfo = response.data.data.departure_flight

                        this.departuresmallinfo.logo = smallogobase + this.flightInfo.air_line_code + '.png'
                        this.departuresmallinfo.AirLine = this.flightInfo.AirLineNameByUs



                        this.adult_number=parseInt(this.flightInfo.adult)
                        this.child_number=parseInt(this.flightInfo.child)
                        this.infant_number=parseInt(this.flightInfo.infant)

                        this.adult_pack=parseInt(this.flightInfo.adult_Pack)
                        this.child_pack=parseInt(this.flightInfo.child_pack)
                        this.infant_pack=parseInt(this.flightInfo.infant_pack)

                        this.adults_info = this.flightInfo.adults_info
                        this.child_info = this.flightInfo.child_info
                        this.infant_info = this.flightInfo.infant_info


                        this.adult_year = this.flightInfo.adult_year
                        this.child_year = this.flightInfo.child_year
                        this.infant_year = this.flightInfo.infant_year
                        this.pass_exp_year = this.flightInfo.pass_exp_year
                        this.booking_fee = this.flightInfo.booking_fee
                        this.cityTourPrice = this.flightInfo.city_tour_price
                        this.InsurancePrice = this.flightInfo.medical_insurance_price
                        this.airportPickupPrice = this.flightInfo.airportPickup_price
                        this.educationPrice = this.flightInfo.education_price

                        this.car = Math.ceil((parseInt(this.adult_number)+parseInt(this.child_number))/3)

                        this.totalPrice = ((this.adult_pack* this.adult_number) + (this.child_number * this.child_pack ) + ( this.infant_pack * this.infant_number )) + ( (parseInt(this.adult_number) + parseInt(this.infant_number) + parseInt(this.child_number)) * parseInt(this.booking_fee))


                        this.mediacl_insurance_label_origin = 'Medical Insurance €' + this.InsurancePrice
                        this.education_label = '€' + this.educationPrice + ' Per unit'

                        this.airport_pickup_label_origin = 'Airport Pickup €' + this.airportPickupPrice + '/Car' + '(' + this.flightInfo.from_city_label + ')'
                        this.city_tour_label_dep_orogin = 'City Tour €' + this.cityTourPrice + '(' + this.flightInfo.from_city_label + ')'

                        this.airport_pickup_label_destination = 'Airport Pickup €' + this.airportPickupPrice + '/Car' + '(' + this.flightInfo.to_city_label + ')'
                        this.city_tour_label_dep_destination = 'City Tour €' + this.cityTourPrice + '(' + this.flightInfo.to_city_label + ')'

                        this.bounded_flights = response.data.data.bounded_flights

                        //here goes the return if exist
                        this.return_flight = response.data.data.return_flight

                        // Call setStepper Function
                        this.setStepper();





                        if(this.return_flight !== null){
                            this.returnsmallinfo.logo = smallogobase + this.return_flight.air_line_code + '.png'
                            this.returnsmallinfo.AirLine = this.return_flight.AirLineNameByUs
                            this.return_flight_details.adult_pack=parseInt(this.return_flight.adult_Pack)
                            this.return_flight_details.child_pack=parseInt(this.return_flight.child_pack)
                            this.return_flight_details.infant_pack=parseInt(this.return_flight.infant_pack)
                            this.returnTotalPrice = ((this.return_flight_details.adult_pack * this.adult_number) + (this.child_number *this.return_flight_details.child_pack ) + ( this.return_flight_details.infant_pack * this.infant_number )) + ( (parseInt(this.adult_number) + parseInt(this.infant_number) + parseInt(this.child_number)) * parseInt(this.booking_fee))
                            if(this.bounded_flights){
                                this.returnTotalPrice =   (parseInt(this.adult_number) + parseInt(this.infant_number) + parseInt(this.child_number)) * parseInt(this.booking_fee)
                            }
                        }

                        this.setLoading(false);


                        // console.log('response', response.data)
                    })
                    .catch(e => {


                        if(e.response.data.message == 'redirect'){

                            var fromHomeToSearchUrl = "/booking/"+this.$route.params.id
                            this.$router.push(fromHomeToSearchUrl)
                            this.$router.go()

                            this.setLoading(false);
                        }






                        // console.log('catch', e.response.data.message)



                    });



            },

            setStepper(){
                // console.log('Return... ', this.return_flight)
                if(_.isEmpty(this.return_flight))
                    this.stepperMode = 'oneway';
                else
                    this.stepperMode = 'roundtrip';
                this.stepperState = 3;
            },

            refFunc(){
                // console.log('SSSS')
                // console.log('AAAA')

                Swal({
                    title: 'Time is over',
                    text: 'Time is over, please try again.',
                    imageUrl: '/pics/hourglass.png',
                    imageWidth: '100',
                    confirmButtonText: 'Try Again'
                }).then((result) => {
                    if (result.value) {
                        this.$refs='{}'
                       // console.log('OOOO');
                        this.$refs.akbar.focus();

                    }
                })
            },

            passportChecker(i){
                if(this.adults_info[i].nationality == 'Iranian' || this.child_info[i].nationality == 'Iranian' || this.infant_info[i].nationality == 'Iranian'){
                    this.passportCheckerFocus++;
                    if(this.passportCheckerFocus == 1)
                        Swal.fire({
                            title: 'Your nationality is Iraninan',
                            html: "Please enter Melli Code in it's field",
                            type: 'warning',
                        })
                }
            },

            setLoading(val){
                this.loading = val;
            }

        },
        watch:{

            departure_from_health:function () {
                var health_price_her =0
                if(this.departure_from_health == true) {
                    health_price_her = parseInt(this.InsurancePrice) * (parseInt(this.adult_number)+parseInt(this.child_number)+parseInt(this.infant_number))
                    this.totalPrice = this.totalPrice + health_price_her
                    this.additionalSum++;
                }else{
                    health_price_her = -(parseInt(this.InsurancePrice) * (parseInt(this.adult_number)+parseInt(this.child_number)+parseInt(this.infant_number)))
                    this.totalPrice = this.totalPrice + health_price_her
                    this.additionalSum--;
                }
                return
            },
            departure_from_pickup:function () {
                var pickup_price_here = 0
                if(this.departure_from_pickup == true) {
                    pickup_price_here = parseInt(this.airportPickupPrice) * (this.car)
                    this.totalPrice = this.totalPrice + pickup_price_here
                    this.additionalSum++;
                }else{
                    pickup_price_here = -(parseInt(this.airportPickupPrice) * (this.car))
                    this.totalPrice = this.totalPrice + pickup_price_here
                    this.additionalSum--;
                }
                return
            },
            departure_to_pickup:function () {
                var pickup_price_here = 0
                if(this.departure_to_pickup == true) {
                    pickup_price_here = parseInt(this.airportPickupPrice) * (this.car)
                    this.totalPrice = this.totalPrice + pickup_price_here
                    this.additionalSum++;
                }else{
                    pickup_price_here = -(parseInt(this.airportPickupPrice) * (this.car))
                    this.totalPrice = this.totalPrice + pickup_price_here
                    this.additionalSum--;
                }
                return
            },
            departure_from_tour:function () {
                var departure_from_tour = 0
                if(this.departure_from_tour == true) {
                    departure_from_tour = parseInt(this.cityTourPrice) * (parseInt(this.child_number) + parseInt(this.adult_number))
                    this.totalPrice = this.totalPrice + departure_from_tour
                    this.additionalSum++;
                }else{
                    departure_from_tour = -(parseInt(this.cityTourPrice) * (parseInt(this.child_number) + parseInt(this.adult_number)))
                    this.totalPrice = this.totalPrice + departure_from_tour
                    this.additionalSum--;
                }
                return
            },
            departure_to_tour:function () {
                var departure_to_tour = 0
                if(this.departure_to_tour == true) {
                    departure_to_tour = parseInt(this.cityTourPrice) * (parseInt(this.child_number) + parseInt(this.adult_number))
                    this.totalPrice = this.totalPrice + departure_to_tour
                    this.additionalSum++;
                }else{
                    departure_to_tour = -(parseInt(this.cityTourPrice) * (parseInt(this.child_number) + parseInt(this.adult_number)))
                    this.totalPrice = this.totalPrice + departure_to_tour
                    this.additionalSum--;
                }
                return
            },

            returning_from_pickup:function () {
                var pickup_price_here = 0
                if(this.returning_from_pickup == true) {
                    pickup_price_here = parseInt(this.airportPickupPrice) * (this.car)
                    this.totalPrice = this.totalPrice + pickup_price_here
                }else{
                    pickup_price_here = -(parseInt(this.airportPickupPrice) * (this.car))
                    this.totalPrice = this.totalPrice + pickup_price_here
                }
                return
            },
            returning_to_pickup:function () {
                var pickup_price_here = 0
                if(this.returning_to_pickup == true) {
                    pickup_price_here = parseInt(this.airportPickupPrice) * (this.car)
                    this.totalPrice = this.totalPrice + pickup_price_here
                }else{
                    pickup_price_here = -(parseInt(this.airportPickupPrice) * (this.car))
                    this.totalPrice = this.totalPrice + pickup_price_here
                }
                return
            },
            returning_from_tour:function () {
                var departure_from_tour = 0
                if(this.returning_from_tour == true) {
                    departure_from_tour = parseInt(this.cityTourPrice) * (parseInt(this.child_number) + parseInt(this.adult_number))
                    this.totalPrice = this.totalPrice + departure_from_tour
                }else{
                    departure_from_tour = -(parseInt(this.cityTourPrice) * (parseInt(this.child_number) + parseInt(this.adult_number)))
                    this.totalPrice = this.totalPrice + departure_from_tour
                }
                return
            },
            returning_to_tour:function () {
                var departure_from_tour = 0
                if(this.returning_to_tour == true) {
                    departure_from_tour = parseInt(this.cityTourPrice) * (parseInt(this.child_number) + parseInt(this.adult_number))
                    this.totalPrice = this.totalPrice + departure_from_tour
                }else{
                    departure_from_tour = -(parseInt(this.cityTourPrice) * (parseInt(this.child_number) + parseInt(this.adult_number)))
                    this.totalPrice = this.totalPrice + departure_from_tour
                }
                return
            },


            education_donation:function(){
                var education_price = 0
                if(this.education_donation == true){
                    education_price = parseInt(this.educationPrice) * parseInt(this.education_donation_unit)
                    this.totalPrice = this.totalPrice + education_price
                    this.additionalSum++;
                }else{

                    education_price = -(parseInt(this.educationPrice) * parseInt(this.education_donation_unit))
                    this.totalPrice = this.totalPrice + education_price
                    this.additionalSum--;
                }
            },

            education_donation_unit:function(){
                var education_price = 0

                education_price = -(parseInt(this.educationPrice) * parseInt(this.last_unit))
                this.totalPrice = this.totalPrice + education_price


                this.last_unit = parseInt(this.education_donation_unit)


                education_price = parseInt(this.educationPrice) * parseInt(this.education_donation_unit)
                this.totalPrice = this.totalPrice + education_price

            },



            // Nationality Watcher (for Iran Alert)
            adults_info:{
                handler: function (){
                    // if(this.adults_info.length > 0){
                    //     for(let i = 0; i < this.adults_info.length; i++){
                    //         if(this.adults_info[i].nationality == 'Iranian'){
                    //             Swal.fire({
                    //                 title: 'Your nationality is Iraninan',
                    //                 text: "Please enter Melli Code in it's field",
                    //                 type: 'warning',
                    //             }).then((result) => {
                    //                 if (result.value) {
                    //                     console.log('ZZZZZ');
                    //                     this.$refs.akbar.focus();
                    //                 }
                    //             })
                    //         }
                    //     }
                    // }
                },
                deep: true
            },

            adults_info: {
                // Complete nationalities by First Nationality
                handler(newVal, oldVal){

                },
                deep: true
            },




            child_info(){
                // console.log('Child Log Fired! ', this.child_info.length)
            },

            infant_info(){
                // console.log('Infant Log Fired! ', this.infant_info.length)
            },






        },

    }


//window.parent.postMessage("fillreserv4();", '*');
</script>


