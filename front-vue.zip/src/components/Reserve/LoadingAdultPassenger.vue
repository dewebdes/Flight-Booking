<template>
    <v-card class="mb-2 py-3 loading-cart loading-cart-reserved--passenger">
        <vue-content-loading :width="300" :height="140">
            <rect x="10" y="2" rx="4" ry="4" width="80" height="4" />

            <rect x="10" y="11" rx="4" ry="4" width="30" height="4" />
            <rect x="50" y="11" rx="4" ry="4" width="70" height="4" />
            <rect x="130" y="11" rx="4" ry="4" width="70" height="4" />
            <rect x="210" y="11" rx="4" ry="4" width="70" height="4" />


            <rect x="10" y="20" rx="4" ry="4" width="85" height="4" />

            <rect x="105" y="20" rx="4" ry="4" width="28" height="4" />
            <rect x="137" y="20" rx="4" ry="4" width="28" height="4" />
            <rect x="169" y="20" rx="4" ry="4" width="28" height="4" />

            <rect x="210" y="20" rx="4" ry="4" width="28" height="4" />
            <rect x="240" y="20" rx="4" ry="4" width="28" height="4" />
            <rect x="270" y="20" rx="4" ry="4" width="28" height="4" />

        </vue-content-loading>
    </v-card>
</template>


<style>
    .loading-cart{
        border-radius: 10px;
        margin: 10px 0 !important;
        box-shadow: 5px 5px 5px rgba(0, 0, 0, 0.1) !important;
        border: 1px solid rgba(0, 0, 0, .1) !important;
    }

    .loading-cart-reserved--passenger{
        height: 140px !important;
    }
</style>


<script>
    import VueContentLoading from 'vue-content-loading';
    import { VclFacebook, VclInstagram } from 'vue-content-loading'


    export default{
        components:{
            VueContentLoading,
            VclFacebook,
            VclInstagram,
        },
    }
</script>