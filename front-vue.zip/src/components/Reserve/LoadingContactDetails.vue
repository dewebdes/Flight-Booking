<template>
    <v-card class="mb-2 py-3 loading-cart loading-cart-reserved--contact">
        <vue-content-loading :width="300" :height="100">
            <rect x="10" y="2" rx="4" ry="4" width="80" height="4" />

            <rect x="10" y="11" rx="4" ry="4" width="70" height="4" />
            <rect x="110" y="11" rx="4" ry="4" width="70" height="4" />
            <rect x="210" y="11" rx="4" ry="4" width="70" height="4" />
        </vue-content-loading>
    </v-card>
</template>


<style>
    .loading-cart{
        border-radius: 10px;
        margin: 10px 0 !important;
        box-shadow: 5px 5px 5px rgba(0, 0, 0, 0.1) !important;
        border: 1px solid rgba(0, 0, 0, .1) !important;
    }

    .loading-cart-reserved--contact{
        height: 100px !important;
    }
</style>


<script>
    import VueContentLoading from 'vue-content-loading';
    import { VclFacebook, VclInstagram } from 'vue-content-loading'


    export default{
        components:{
            VueContentLoading,
            VclFacebook,
            VclInstagram,
        },
    }
</script>