<template>
    <v-card class="mb-2 py-3 loading-cart loading-cart-reserved--ticket">
        <vue-content-loading :width="300" :height="250">
            <rect x="10" y="10" rx="4" ry="4" width="50" height="4" />
            <rect x="10" y="20" rx="4" ry="4" width="40" height="4" />
            <rect x="10" y="30" rx="4" ry="4" width="60" height="4" />

            <rect x="90" y="10" rx="4" ry="4" width="50" height="4" />
            <rect x="90" y="20" rx="4" ry="4" width="40" height="4" />
            <rect x="90" y="30" rx="4" ry="4" width="60" height="4" />

            <rect x="170" y="10" rx="4" ry="4" width="50" height="4" />
            <rect x="170" y="20" rx="4" ry="4" width="40" height="4" />
            <rect x="170" y="30" rx="4" ry="4" width="60" height="4" />

            <rect x="250" y="7" rx="1" ry="1" width="30" height="30" />
        </vue-content-loading>
    </v-card>
</template>


<style>
    .loading-cart{
        border-radius: 10px;
        margin: 10px 0 !important;
        box-shadow: 5px 5px 5px rgba(0, 0, 0, 0.1) !important;
        border: 1px solid rgba(0, 0, 0, .1) !important;
    }

    .loading-cart-reserved--ticket{
        height: 200px !important;
    }
</style>


<script>
    import VueContentLoading from 'vue-content-loading';
    import { VclFacebook, VclInstagram } from 'vue-content-loading'


    export default{
        components:{
            VueContentLoading,
            VclFacebook,
            VclInstagram,
        },
    }
</script>