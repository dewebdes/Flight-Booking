<template>
    <div>
        <v-layout row wrap>

            <LoadingChineseBox v-if="loading"></LoadingChineseBox>

            <v-flex v-if="this.success && !loading" xs12 bookingheaderwrapper dosuccess>
                <v-layout row wrap>
                    <v-flex xs12>
                        <div class="flaticon-checked-1"></div>
                    </v-flex>
                </v-layout>
            </v-flex>
            <v-flex v-if="this.success && !loading" xs12 bookinghederbelowsection dosuccess>
                <v-layout row wrap>
                    <v-flex xs12>
                        <v-container grid-list-md text-xs-center chinesstxt>
                            您的機票已經確認
                        </v-container>
                    </v-flex>
                    <v-flex xs12>
                        <v-container grid-list-md text-xs-center chinesstxtsub>
                            No worries it means
                        </v-container>
                    </v-flex>
                    <v-flex xs12 text-xs-center tktcnfr>
                            Your ticket has been confirmed
                    </v-flex>
                    <v-flex xs12 text-xs-center bkingid>
                            {{ this.$route.params.id }}
                    </v-flex>
                    <v-flex xs12  text-xs-center dnltkt>
                        <a :href="this.link_to_dl" rel="nofollow" :download="this.$route.params.id" class="dl_lnk">
                           <v-icon>cloud_download</v-icon> Download Your e-Ticket
                        </a>
                    </v-flex>
                </v-layout>
            </v-flex>

            <v-flex v-if="!this.success && !loading" xs12 bookingheaderwrapper notsuccess>
                <v-layout row wrap>
                    <v-flex xs12>
                        <div class="flaticon-warning"></div>
                    </v-flex>
                </v-layout>
            </v-flex>
            <v-flex v-if="!this.success && !loading" xs12 bookinghederbelowsection notsuccess>
                <v-layout row wrap>
                    <v-flex xs12>
                        <v-container grid-list-md text-xs-center chinesstxt>
                            有些不對勁
                        </v-container>
                    </v-flex>
                    <v-flex xs12>
                        <v-container grid-list-md text-xs-center chinesstxtsub>
                            Oppps ... it means
                        </v-container>
                    </v-flex>
                    <v-flex xs12 text-xs-center tktcnfr>
                        Something went wrong
                    </v-flex>
                    <v-flex xs12 text-xs-center bkingid>
                        Apply Again
                    </v-flex>
                </v-layout>
            </v-flex>

            <v-flex>
                <v-layout row wrap>
                    <v-flex xs12 text-xs-center>
                        <v-container grid-list-md v-if="loading">
                            <v-layout row wrap>
                                <LoadingBookingCart></LoadingBookingCart>

                                <LoadingBookingCart></LoadingBookingCart>
                            </v-layout>
                        </v-container>

                        <v-container grid-list-md v-if="!loading">
                            <v-layout row wrap firstlinebooking>
                                <v-flex sm4 xs12 sideimgbooking>
                                    <img src="https://www.espinashotels.com/images/main/random3.jpg" alt="">
                                </v-flex>
                                <v-flex sm8 xs12>
                                    <v-layout row wrap>
                                        <v-flex xs12 bookingslidetxtone text-xs-left>
                                            Act now and save more
                                        </v-flex>
                                        <v-flex xs12 bookingslidetxttwo text-xs-left>
                                            Rooms are filling up quick. Check out popular hotels in
                                            Iran and book your room before they sell out. Over 1200
                                            luxury to budget accommodations are listed in all cities
                                        </v-flex>
                                        <v-flex xs12 bookingslidetxtthree text-xs-left>
                                            Explore the best hotels in Iran
                                        </v-flex>
                                    </v-layout>
                                </v-flex>
                            </v-layout>
                        </v-container>
                    </v-flex>
                    <v-flex xs12 text-xs-center v-if="!loading">
                        <v-flex xs12 text-xs-center>
                            <v-container grid-list-md>
                                <v-layout row wrap firstlinebooking sec>
                                    <v-flex xs12 bigimgbooking>
                                        <img src="https://www.persiaadvisor.travel/wp-content/uploads/2017/11/Persepolis-Marvdasht-Fars-Province-Iran-Persia-Advisor-Travel-2.jpg" alt="">
                                    </v-flex>
                                    <v-flex xs12 bigimgbookingnext text-xs-left>
                                        <h2>
                                            Inspiration for your next trip
                                        </h2>
                                        <h3>
                                            Travel articles and inspiration to make the most of your trip to Iran
                                        </h3>
                                    </v-flex>
                                    <v-flex xs12 text-xs-right seemorenook>
                                        Explore the articles &#187;
                                    </v-flex>
                                </v-layout>
                            </v-container>
                        </v-flex>
                    </v-flex>
                </v-layout>
            </v-flex>



        </v-layout>
    </div>
</template>


<style>
    .dl_lnk {
        color: #fff;
        text-decoration: none;
    }
.notsuccess .flex.xs12.text-xs-center.bkingid{
font-size: 15px;
line-height: 60px;
}
.flex.xs12.bookingheaderwrapper.notsuccess{
background: #990000;
}
.firstlinebooking.sec{
    padding-bottom: 0px!important;
}
.flex.xs12.text-xs-right.seemorenook{
        background: #04365e!important;
        color: #fff!important;
        font-weight: bold!important;
        padding-top: 20px!important;
        padding-bottom: 20px!important;
        padding-right: 20px!important;
}
.flex.xs12.bigimgbookingnext.text-xs-left {
        margin-top: -68px;
        background: #0535679e;
        color: #fff;
        padding-left: 40px;
}
.flex.xs12.bigimgbooking{
    padding: 0px!important;
}
.layout.row.wrap.firstlinebooking.sec{
    margin-bottom: 40px;
}
.bigimgbooking img{
    width: 100%;
    height: auto;
}
.bigimgbooking{
    max-height: 650px;
    overflow: hidden;
}
.firstlinebooking{
    box-shadow: 1px 1px 6px 2px #ccc;
    padding-bottom: 4px;
}
.bookingslidetxttwo{
    font-size: 18px;
    margin-top: 80px;
    margin-bottom: 45px;
}
.bookingslidetxtone{
    color: #216190;
    font-size: 25px;
    font-weight: bold;
}
.bookingslidetxtthree{
    text-decoration: underline;
    font-size: 18px;
}
.bookingheaderwrapper{
    padding-top: 15px;
    background: #0d618e;
    max-height: 69vh;
    overflow: hidden;
}
.bookinghederbelowsection{
    margin-top: -60vh;
}
.chinesstxt{
    font-size: 4.5vw;
    color: #fff;
    font-weight: bold;
}
.chinesstxtsub{
    color: #cccccc;
    font-size: 17px;
}
.tktcnfr{
    font-size: 22px;
    color: #fff;
}
.bkingid {
    color: #ffcc33;
    font-size: 4vw;
    font-weight: 800;
}
.dnltkt{
    color: #b7d0dd;
}

.dnltkt .v-icon, .dnltkt{
    color: #b7d0dd;
}

.dnltkt .v-icon{
    margin-bottom: -2px;
}
.sideimgbooking{
    max-height: 300px;
    overflow: hidden;
}.sideimgbooking img{
    max-width: 100%;
}

[class^="flaticon-"]:before, [class*=" flaticon-"]:before, [class^="flaticon-"]:after, [class*=" flaticon-"]:after {
    font-family: bookingicons;
    font-size: 34vw;
    font-style: normal;
    margin-left: 20px;
    color: rgba(255,255,255,0.12);
    margin-top: 20px;
    margin-left: 10%;

}
@media (max-width: 479px) {
    .flex.xs12.bookinghederbelowsection.notsuccess {
        margin-top: -40vh;
    }

    .flex.xs12.bookingheaderwrapper.notsuccess {
        background: #990000;
        padding-bottom: 60px;
    }
}
@media (min-width: 599px) and (max-width: 767px) {
    .flex.xs12.bookinghederbelowsection.notsuccess{
        margin-top: -31vh;
    }
}

@media (min-width: 768px) and (max-width: 799px) {
    .flex.xs12.bookinghederbelowsection.notsuccess {
        margin-top: -30vh;
    }
}

@media (max-width: 479px) {

    .flex.xs12.bookingheaderwrapper.dosuccess{
        height: 54vh!important;
    }
    .flex.xs12.bookinghederbelowsection.dosuccess{
        margin-top: -44vh;
    }

}
    
@media (min-width: 480px) and (max-width: 599px) {
    .flex.xs12.bookingheaderwrapper.dosuccess{
        max-height: 80vh;
    }
    .flex.xs12.bookinghederbelowsection.dosuccess{
        margin-top: -68vh;
    }
}

@media (min-width: 600px) and (max-width: 799px) {
    .flex.xs12.bookingheaderwrapper.dosuccess{
        max-height: 80vh;
    }
    .flex.xs12.bookinghederbelowsection.dosuccess{
        margin-top: -32vh;
    }
}
@media (min-width: 767px) and (max-width: 799px) {
    .flex.xs12.bookinghederbelowsection.dosuccess{
        margin-top: -31vh;
    }
}

</style>

<script>

    import Vue from 'vue'

    import axios from 'axios'
    Vue.prototype.$axios = axios

    import LoadingChineseBox from './LoadingChineseBox'
    import LoadingBookingCart from './LoadingBookingCart'


    export default {
        name: 'BookingContent',
        components:{
            LoadingChineseBox,
            LoadingBookingCart
        },
        mounted(){
            // console.log('this.$route', this.$route)
            this.checkThebooking()
        },
        data(){
            return{
                success:false,
                link_to_dl:this.$hostwebname+'/pdfs/tickets/'+ this.$route.params.id+'.pdf',
                loading: true,
            }
        },
        methods:{

            checkThebooking: function () {

                let header = {
                    'Accept': 'application/json',
                    'Authorization': 'Bearer ' + this.$tookenaccess,
                };
                let data =  {

                    bookingId: this.$route.params.id

                }

                axios.post( this.$hostname + 'flight/check/book', data ,{ headers: header})
                    .then(response => {

                        this.success = true
                        this.setLoading(false);

                    })
                    .catch(e => {
                        // console.log('Pay & Book Error: ', e.message)
                        this.setLoading(false);
                    });
            },

            setLoading(val){
                this.loading = val;
            },

        }

    }
</script>