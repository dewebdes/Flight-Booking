<template>
    <v-card class="mb-2 py-3 loading-cart loading-cart--booking__attraction">
        <vue-content-loading :width="400" :height="400">
            <rect x="5" y="0" rx="4" ry="4" width="95" height="95" />

            <rect x="110" y="5" rx="4" ry="4" width="120" height="7" />

            <rect x="110" y="30" rx="4" ry="4" width="220" height="5" />
            <rect x="110" y="40" rx="4" ry="4" width="160" height="5" />
            <rect x="110" y="50" rx="4" ry="4" width="210" height="5" />

            <rect x="110" y="80" rx="4" ry="4" width="80" height="5" />
        </vue-content-loading>
    </v-card>
</template>


<style>
    .loading-cart{
        border-radius: 10px;
        margin: 10px 0 !important;
        box-shadow: 5px 5px 5px rgba(0, 0, 0, 0.1) !important;
        border: 1px solid rgba(0, 0, 0, .1) !important;
    }

    .loading-cart--booking__attraction{
        top: 60px;
        width: 100%;
        height: 300px !important;
        margin-top: 50px;
    }
</style>


<script>
    import VueContentLoading from 'vue-content-loading';
    import { VclFacebook, VclInstagram } from 'vue-content-loading'


    export default{
        components:{
            VueContentLoading,
            VclFacebook,
            VclInstagram,
        },
    }
</script>